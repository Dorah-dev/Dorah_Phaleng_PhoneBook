namespace AddressBook
{
    partial class frmNewContact
    {
        System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewContact));
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.AC_Properties_Tab = new System.Windows.Forms.TabControl();
            this.Summary_TB = new System.Windows.Forms.TabPage();
            this.lblDBWP = new System.Windows.Forms.Label();
            this.lblDCompanyName = new System.Windows.Forms.Label();
            this.lblDOffice = new System.Windows.Forms.Label();
            this.lblDDepartment = new System.Windows.Forms.Label();
            this.lblDJobTitle = new System.Windows.Forms.Label();
            this.lblDBusinessFax = new System.Windows.Forms.Label();
            this.lblDBusinessPhone = new System.Windows.Forms.Label();
            this.lblDPWP = new System.Windows.Forms.Label();
            this.lblDPager = new System.Windows.Forms.Label();
            this.lblDMobile = new System.Windows.Forms.Label();
            this.lblDHomePhone = new System.Windows.Forms.Label();
            this.lblDEmailAddress = new System.Windows.Forms.Label();
            this.lblDName = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.S_L_Name = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Name_TB = new System.Windows.Forms.TabPage();
            this.txtlstEmailList = new System.Windows.Forms.RichTextBox();
            this.btnSetDefaultEmail = new System.Windows.Forms.Button();
            this.btnRemoveEmail = new System.Windows.Forms.Button();
            this.btnEditEmail = new System.Windows.Forms.Button();
            this.lstEmailList = new System.Windows.Forms.ListBox();
            this.btnAddEmail = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.Nick_Lable = new System.Windows.Forms.Label();
            this.txtNickName = new System.Windows.Forms.TextBox();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.F_Name_Lable = new System.Windows.Forms.Label();
            this.Title_Lable = new System.Windows.Forms.Label();
            this.M_Name_Lable = new System.Windows.Forms.Label();
            this.Display_Lable = new System.Windows.Forms.Label();
            this.L_Name_Lable = new System.Windows.Forms.Label();
            this.Name_Label = new System.Windows.Forms.Label();
            this.Home_TB = new System.Windows.Forms.TabPage();
            this.txtHomeStreet = new System.Windows.Forms.RichTextBox();
            this.txtHomeMobile = new System.Windows.Forms.TextBox();
            this.txtHomeFax = new System.Windows.Forms.TextBox();
            this.txtHomePhone = new System.Windows.Forms.TextBox();
            this.txtHomeCountry = new System.Windows.Forms.TextBox();
            this.txtHomeZipCode = new System.Windows.Forms.TextBox();
            this.txtHomeState = new System.Windows.Forms.TextBox();
            this.txtHomeCity = new System.Windows.Forms.TextBox();
            this.txtHomeWebPage = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Home_Label = new System.Windows.Forms.Label();
            this.Business_TB = new System.Windows.Forms.TabPage();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.txtBusiPager = new System.Windows.Forms.TextBox();
            this.txtBusiFax = new System.Windows.Forms.TextBox();
            this.txtBusiPhone = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtCompany = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBusiStreetAddress = new System.Windows.Forms.RichTextBox();
            this.txtOffice = new System.Windows.Forms.TextBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtJobtitle = new System.Windows.Forms.TextBox();
            this.txtBusiCountry = new System.Windows.Forms.TextBox();
            this.txtBusiZipCode = new System.Windows.Forms.TextBox();
            this.txtBusiState = new System.Windows.Forms.TextBox();
            this.txtBusiCity = new System.Windows.Forms.TextBox();
            this.txtBusiWebPage = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.Business_Lable = new System.Windows.Forms.Label();
            this.Personal_TB = new System.Windows.Forms.TabPage();
            this.txtlstChildNamesList = new System.Windows.Forms.RichTextBox();
            this.btnRemoveChild = new System.Windows.Forms.Button();
            this.btnEditChild = new System.Windows.Forms.Button();
            this.lstChildNamesList = new System.Windows.Forms.ListBox();
            this.btnAddChild = new System.Windows.Forms.Button();
            this.txtChildName = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtAnniversary = new System.Windows.Forms.DateTimePicker();
            this.txtBirthday = new System.Windows.Forms.DateTimePicker();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.txtSpouse = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.Personal_Lable = new System.Windows.Forms.Label();
            this.Other_TB = new System.Windows.Forms.TabPage();
            this.IsContactShared = new System.Windows.Forms.CheckBox();
            this.txtNotes = new System.Windows.Forms.RichTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Other_Lable = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.AC_Properties_Tab.SuspendLayout();
            this.Summary_TB.SuspendLayout();
            this.Name_TB.SuspendLayout();
            this.Home_TB.SuspendLayout();
            this.Business_TB.SuspendLayout();
            this.Personal_TB.SuspendLayout();
            this.Other_TB.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(450, 374);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 19;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.Cancel);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(369, 374);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 18;
            this.btnOk.Text = "Save";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.SaveChanges);
            // 
            // AC_Properties_Tab
            // 
            this.AC_Properties_Tab.Controls.Add(this.Summary_TB);
            this.AC_Properties_Tab.Controls.Add(this.Name_TB);
            this.AC_Properties_Tab.Controls.Add(this.Home_TB);
            this.AC_Properties_Tab.Controls.Add(this.Business_TB);
            this.AC_Properties_Tab.Controls.Add(this.Personal_TB);
            this.AC_Properties_Tab.Controls.Add(this.Other_TB);
            this.AC_Properties_Tab.Location = new System.Drawing.Point(6, 6);
            this.AC_Properties_Tab.Name = "AC_Properties_Tab";
            this.AC_Properties_Tab.SelectedIndex = 0;
            this.AC_Properties_Tab.Size = new System.Drawing.Size(525, 362);
            this.AC_Properties_Tab.TabIndex = 0;
            // 
            // Summary_TB
            // 
            this.Summary_TB.Controls.Add(this.lblDBWP);
            this.Summary_TB.Controls.Add(this.lblDCompanyName);
            this.Summary_TB.Controls.Add(this.lblDOffice);
            this.Summary_TB.Controls.Add(this.lblDDepartment);
            this.Summary_TB.Controls.Add(this.lblDJobTitle);
            this.Summary_TB.Controls.Add(this.lblDBusinessFax);
            this.Summary_TB.Controls.Add(this.lblDBusinessPhone);
            this.Summary_TB.Controls.Add(this.lblDPWP);
            this.Summary_TB.Controls.Add(this.lblDPager);
            this.Summary_TB.Controls.Add(this.lblDMobile);
            this.Summary_TB.Controls.Add(this.lblDHomePhone);
            this.Summary_TB.Controls.Add(this.lblDEmailAddress);
            this.Summary_TB.Controls.Add(this.lblDName);
            this.Summary_TB.Controls.Add(this.label42);
            this.Summary_TB.Controls.Add(this.label41);
            this.Summary_TB.Controls.Add(this.label40);
            this.Summary_TB.Controls.Add(this.label39);
            this.Summary_TB.Controls.Add(this.label38);
            this.Summary_TB.Controls.Add(this.label37);
            this.Summary_TB.Controls.Add(this.label36);
            this.Summary_TB.Controls.Add(this.label35);
            this.Summary_TB.Controls.Add(this.label34);
            this.Summary_TB.Controls.Add(this.label32);
            this.Summary_TB.Controls.Add(this.label33);
            this.Summary_TB.Controls.Add(this.label31);
            this.Summary_TB.Controls.Add(this.S_L_Name);
            this.Summary_TB.Controls.Add(this.label29);
            this.Summary_TB.Location = new System.Drawing.Point(4, 22);
            this.Summary_TB.Name = "Summary_TB";
            this.Summary_TB.Size = new System.Drawing.Size(517, 336);
            this.Summary_TB.TabIndex = 5;
            this.Summary_TB.Text = "Summary";
            this.Summary_TB.UseVisualStyleBackColor = true;
            // 
            // lblDBWP
            // 
            this.lblDBWP.AutoSize = true;
            this.lblDBWP.Location = new System.Drawing.Point(141, 309);
            this.lblDBWP.Name = "lblDBWP";
            this.lblDBWP.Size = new System.Drawing.Size(99, 13);
            this.lblDBWP.TabIndex = 0;
            this.lblDBWP.Text = "Business Webpage";
            this.lblDBWP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDCompanyName
            // 
            this.lblDCompanyName.AutoSize = true;
            this.lblDCompanyName.Location = new System.Drawing.Point(141, 289);
            this.lblDCompanyName.Name = "lblDCompanyName";
            this.lblDCompanyName.Size = new System.Drawing.Size(82, 13);
            this.lblDCompanyName.TabIndex = 0;
            this.lblDCompanyName.Text = "Company Name";
            // 
            // lblDOffice
            // 
            this.lblDOffice.AutoSize = true;
            this.lblDOffice.Location = new System.Drawing.Point(141, 269);
            this.lblDOffice.Name = "lblDOffice";
            this.lblDOffice.Size = new System.Drawing.Size(35, 13);
            this.lblDOffice.TabIndex = 0;
            this.lblDOffice.Text = "Office";
            // 
            // lblDDepartment
            // 
            this.lblDDepartment.AutoSize = true;
            this.lblDDepartment.Location = new System.Drawing.Point(141, 249);
            this.lblDDepartment.Name = "lblDDepartment";
            this.lblDDepartment.Size = new System.Drawing.Size(62, 13);
            this.lblDDepartment.TabIndex = 0;
            this.lblDDepartment.Text = "Department";
            // 
            // lblDJobTitle
            // 
            this.lblDJobTitle.AutoSize = true;
            this.lblDJobTitle.Location = new System.Drawing.Point(141, 229);
            this.lblDJobTitle.Name = "lblDJobTitle";
            this.lblDJobTitle.Size = new System.Drawing.Size(47, 13);
            this.lblDJobTitle.TabIndex = 0;
            this.lblDJobTitle.Text = "Job Title";
            // 
            // lblDBusinessFax
            // 
            this.lblDBusinessFax.AutoSize = true;
            this.lblDBusinessFax.Location = new System.Drawing.Point(141, 209);
            this.lblDBusinessFax.Name = "lblDBusinessFax";
            this.lblDBusinessFax.Size = new System.Drawing.Size(69, 13);
            this.lblDBusinessFax.TabIndex = 0;
            this.lblDBusinessFax.Text = "Business Fax";
            // 
            // lblDBusinessPhone
            // 
            this.lblDBusinessPhone.AutoSize = true;
            this.lblDBusinessPhone.Location = new System.Drawing.Point(141, 189);
            this.lblDBusinessPhone.Name = "lblDBusinessPhone";
            this.lblDBusinessPhone.Size = new System.Drawing.Size(83, 13);
            this.lblDBusinessPhone.TabIndex = 0;
            this.lblDBusinessPhone.Text = "Business Phone";
            // 
            // lblDPWP
            // 
            this.lblDPWP.AutoSize = true;
            this.lblDPWP.Location = new System.Drawing.Point(141, 169);
            this.lblDPWP.Name = "lblDPWP";
            this.lblDPWP.Size = new System.Drawing.Size(102, 13);
            this.lblDPWP.TabIndex = 0;
            this.lblDPWP.Text = "Personal Web Page";
            // 
            // lblDPager
            // 
            this.lblDPager.AutoSize = true;
            this.lblDPager.Location = new System.Drawing.Point(141, 129);
            this.lblDPager.Name = "lblDPager";
            this.lblDPager.Size = new System.Drawing.Size(35, 13);
            this.lblDPager.TabIndex = 0;
            this.lblDPager.Text = "Pager";
            // 
            // lblDMobile
            // 
            this.lblDMobile.AutoSize = true;
            this.lblDMobile.Location = new System.Drawing.Point(141, 149);
            this.lblDMobile.Name = "lblDMobile";
            this.lblDMobile.Size = new System.Drawing.Size(38, 13);
            this.lblDMobile.TabIndex = 0;
            this.lblDMobile.Text = "Mobile";
            // 
            // lblDHomePhone
            // 
            this.lblDHomePhone.AutoSize = true;
            this.lblDHomePhone.Location = new System.Drawing.Point(141, 109);
            this.lblDHomePhone.Name = "lblDHomePhone";
            this.lblDHomePhone.Size = new System.Drawing.Size(69, 13);
            this.lblDHomePhone.TabIndex = 0;
            this.lblDHomePhone.Text = "Home Phone";
            // 
            // lblDEmailAddress
            // 
            this.lblDEmailAddress.AutoSize = true;
            this.lblDEmailAddress.Location = new System.Drawing.Point(141, 89);
            this.lblDEmailAddress.Name = "lblDEmailAddress";
            this.lblDEmailAddress.Size = new System.Drawing.Size(77, 13);
            this.lblDEmailAddress.TabIndex = 0;
            this.lblDEmailAddress.Text = "E-Mail Address";
            // 
            // lblDName
            // 
            this.lblDName.AutoSize = true;
            this.lblDName.Location = new System.Drawing.Point(141, 69);
            this.lblDName.Name = "lblDName";
            this.lblDName.Size = new System.Drawing.Size(35, 13);
            this.lblDName.TabIndex = 0;
            this.lblDName.Text = "Name";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(26, 309);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(102, 13);
            this.label42.TabIndex = 0;
            this.label42.Text = "Business Webpage:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(43, 289);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 13);
            this.label41.TabIndex = 0;
            this.label41.Text = "Company Name:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(90, 269);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(38, 13);
            this.label40.TabIndex = 0;
            this.label40.Text = "Office:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(63, 249);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "Department:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(78, 229);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(50, 13);
            this.label38.TabIndex = 0;
            this.label38.Text = "Job Title:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(56, 209);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(72, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "Business Fax:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(42, 189);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(86, 13);
            this.label36.TabIndex = 0;
            this.label36.Text = "Business Phone:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(23, 169);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(105, 13);
            this.label35.TabIndex = 0;
            this.label35.Text = "Personal Web Page:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(90, 129);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(38, 13);
            this.label34.TabIndex = 0;
            this.label34.Text = "Pager:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(87, 149);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 13);
            this.label32.TabIndex = 0;
            this.label32.Text = "Mobile:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(56, 109);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(72, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Home Phone:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(48, 89);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(80, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "E-Mail Address:";
            // 
            // S_L_Name
            // 
            this.S_L_Name.AutoSize = true;
            this.S_L_Name.Location = new System.Drawing.Point(90, 69);
            this.S_L_Name.Name = "S_L_Name";
            this.S_L_Name.Size = new System.Drawing.Size(38, 13);
            this.S_L_Name.TabIndex = 0;
            this.S_L_Name.Text = "Name:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(63, 30);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(206, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Summary of information about the contact.";
            // 
            // Name_TB
            // 
            this.Name_TB.Controls.Add(this.txtlstEmailList);
            this.Name_TB.Controls.Add(this.btnSetDefaultEmail);
            this.Name_TB.Controls.Add(this.btnRemoveEmail);
            this.Name_TB.Controls.Add(this.btnEditEmail);
            this.Name_TB.Controls.Add(this.lstEmailList);
            this.Name_TB.Controls.Add(this.btnAddEmail);
            this.Name_TB.Controls.Add(this.txtEmail);
            this.Name_TB.Controls.Add(this.label30);
            this.Name_TB.Controls.Add(this.Nick_Lable);
            this.Name_TB.Controls.Add(this.txtNickName);
            this.Name_TB.Controls.Add(this.txtDisplay);
            this.Name_TB.Controls.Add(this.txtTitle);
            this.Name_TB.Controls.Add(this.txtLastName);
            this.Name_TB.Controls.Add(this.txtMiddleName);
            this.Name_TB.Controls.Add(this.txtFirstName);
            this.Name_TB.Controls.Add(this.F_Name_Lable);
            this.Name_TB.Controls.Add(this.Title_Lable);
            this.Name_TB.Controls.Add(this.M_Name_Lable);
            this.Name_TB.Controls.Add(this.Display_Lable);
            this.Name_TB.Controls.Add(this.L_Name_Lable);
            this.Name_TB.Controls.Add(this.Name_Label);
            this.Name_TB.Location = new System.Drawing.Point(4, 22);
            this.Name_TB.Name = "Name_TB";
            this.Name_TB.Padding = new System.Windows.Forms.Padding(3);
            this.Name_TB.Size = new System.Drawing.Size(517, 336);
            this.Name_TB.TabIndex = 0;
            this.Name_TB.Text = "Name";
            this.Name_TB.UseVisualStyleBackColor = true;
            // 
            // txtlstEmailList
            // 
            this.txtlstEmailList.Location = new System.Drawing.Point(480, 18);
            this.txtlstEmailList.Name = "txtlstEmailList";
            this.txtlstEmailList.Size = new System.Drawing.Size(10, 29);
            this.txtlstEmailList.TabIndex = 0;
            this.txtlstEmailList.Text = "";
            this.txtlstEmailList.Visible = false;
            // 
            // btnSetDefaultEmail
            // 
            this.btnSetDefaultEmail.Enabled = false;
            this.btnSetDefaultEmail.Location = new System.Drawing.Point(391, 268);
            this.btnSetDefaultEmail.Name = "btnSetDefaultEmail";
            this.btnSetDefaultEmail.Size = new System.Drawing.Size(116, 23);
            this.btnSetDefaultEmail.TabIndex = 11;
            this.btnSetDefaultEmail.Text = "&Set as Default";
            this.btnSetDefaultEmail.UseVisualStyleBackColor = true;
            this.btnSetDefaultEmail.Click += new System.EventHandler(this.SetAsDefaultEmail);
            // 
            // btnRemoveEmail
            // 
            this.btnRemoveEmail.Enabled = false;
            this.btnRemoveEmail.Location = new System.Drawing.Point(391, 239);
            this.btnRemoveEmail.Name = "btnRemoveEmail";
            this.btnRemoveEmail.Size = new System.Drawing.Size(116, 23);
            this.btnRemoveEmail.TabIndex = 10;
            this.btnRemoveEmail.Text = "&Remove";
            this.btnRemoveEmail.UseVisualStyleBackColor = true;
            this.btnRemoveEmail.Click += new System.EventHandler(this.RemoveSelectedEmail);
            // 
            // btnEditEmail
            // 
            this.btnEditEmail.Enabled = false;
            this.btnEditEmail.Location = new System.Drawing.Point(391, 210);
            this.btnEditEmail.Name = "btnEditEmail";
            this.btnEditEmail.Size = new System.Drawing.Size(116, 23);
            this.btnEditEmail.TabIndex = 9;
            this.btnEditEmail.Text = "&Edit";
            this.btnEditEmail.UseVisualStyleBackColor = true;
            this.btnEditEmail.Click += new System.EventHandler(this.EditSelectedEmail);
            // 
            // lstEmailList
            // 
            this.lstEmailList.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstEmailList.ForeColor = System.Drawing.Color.Blue;
            this.lstEmailList.FormattingEnabled = true;
            this.lstEmailList.ItemHeight = 14;
            this.lstEmailList.Location = new System.Drawing.Point(18, 210);
            this.lstEmailList.Name = "lstEmailList";
            this.lstEmailList.Size = new System.Drawing.Size(366, 102);
            this.lstEmailList.TabIndex = 8;
            this.lstEmailList.SelectedIndexChanged += new System.EventHandler(this.CheckEmailItemSelection);
            // 
            // btnAddEmail
            // 
            this.btnAddEmail.Location = new System.Drawing.Point(391, 174);
            this.btnAddEmail.Name = "btnAddEmail";
            this.btnAddEmail.Size = new System.Drawing.Size(116, 23);
            this.btnAddEmail.TabIndex = 7;
            this.btnAddEmail.Text = "&Add";
            this.btnAddEmail.UseVisualStyleBackColor = true;
            this.btnAddEmail.Click += new System.EventHandler(this.AddEmail);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(101, 177);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(283, 20);
            this.txtEmail.TabIndex = 6;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(15, 180);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 13);
            this.label30.TabIndex = 0;
            this.label30.Text = "E-Mail Address:";
            // 
            // Nick_Lable
            // 
            this.Nick_Lable.AutoSize = true;
            this.Nick_Lable.Location = new System.Drawing.Point(354, 116);
            this.Nick_Lable.Name = "Nick_Lable";
            this.Nick_Lable.Size = new System.Drawing.Size(35, 13);
            this.Nick_Lable.TabIndex = 0;
            this.Nick_Lable.Text = "Nick :";
            // 
            // txtNickName
            // 
            this.txtNickName.Location = new System.Drawing.Point(391, 113);
            this.txtNickName.Name = "txtNickName";
            this.txtNickName.Size = new System.Drawing.Size(116, 20);
            this.txtNickName.TabIndex = 5;
            // 
            // txtDisplay
            // 
            this.txtDisplay.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDisplay.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtDisplay.Location = new System.Drawing.Point(187, 113);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(158, 20);
            this.txtDisplay.TabIndex = 4;
            this.txtDisplay.TextChanged += new System.EventHandler(this.SetTitleName);
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(58, 113);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(66, 20);
            this.txtTitle.TabIndex = 3;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(391, 77);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(116, 20);
            this.txtLastName.TabIndex = 2;
            this.txtLastName.TextChanged += new System.EventHandler(this.ShowDisplayName);
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(229, 77);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(116, 20);
            this.txtMiddleName.TabIndex = 1;
            this.txtMiddleName.TextChanged += new System.EventHandler(this.ShowDisplayName);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(58, 77);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(116, 20);
            this.txtFirstName.TabIndex = 0;
            this.txtFirstName.TextChanged += new System.EventHandler(this.ShowDisplayName);
            // 
            // F_Name_Lable
            // 
            this.F_Name_Lable.AutoSize = true;
            this.F_Name_Lable.Location = new System.Drawing.Point(15, 80);
            this.F_Name_Lable.Name = "F_Name_Lable";
            this.F_Name_Lable.Size = new System.Drawing.Size(29, 13);
            this.F_Name_Lable.TabIndex = 0;
            this.F_Name_Lable.Text = "First:";
            // 
            // Title_Lable
            // 
            this.Title_Lable.AutoSize = true;
            this.Title_Lable.Location = new System.Drawing.Point(15, 116);
            this.Title_Lable.Name = "Title_Lable";
            this.Title_Lable.Size = new System.Drawing.Size(30, 13);
            this.Title_Lable.TabIndex = 0;
            this.Title_Lable.Text = "Title:";
            // 
            // M_Name_Lable
            // 
            this.M_Name_Lable.AutoSize = true;
            this.M_Name_Lable.Location = new System.Drawing.Point(184, 80);
            this.M_Name_Lable.Name = "M_Name_Lable";
            this.M_Name_Lable.Size = new System.Drawing.Size(41, 13);
            this.M_Name_Lable.TabIndex = 0;
            this.M_Name_Lable.Text = "Middle:";
            // 
            // Display_Lable
            // 
            this.Display_Lable.AutoSize = true;
            this.Display_Lable.Location = new System.Drawing.Point(130, 116);
            this.Display_Lable.Name = "Display_Lable";
            this.Display_Lable.Size = new System.Drawing.Size(44, 13);
            this.Display_Lable.TabIndex = 0;
            this.Display_Lable.Text = "Display:";
            // 
            // L_Name_Lable
            // 
            this.L_Name_Lable.AutoSize = true;
            this.L_Name_Lable.Location = new System.Drawing.Point(354, 80);
            this.L_Name_Lable.Name = "L_Name_Lable";
            this.L_Name_Lable.Size = new System.Drawing.Size(30, 13);
            this.L_Name_Lable.TabIndex = 0;
            this.L_Name_Lable.Text = "Last:";
            // 
            // Name_Label
            // 
            this.Name_Label.AutoSize = true;
            this.Name_Label.Location = new System.Drawing.Point(63, 30);
            this.Name_Label.Name = "Name_Label";
            this.Name_Label.Size = new System.Drawing.Size(281, 13);
            this.Name_Label.TabIndex = 0;
            this.Name_Label.Text = "Enter name and e-mail information about this contact here.";
            // 
            // Home_TB
            // 
            this.Home_TB.Controls.Add(this.txtHomeStreet);
            this.Home_TB.Controls.Add(this.txtHomeMobile);
            this.Home_TB.Controls.Add(this.txtHomeFax);
            this.Home_TB.Controls.Add(this.txtHomePhone);
            this.Home_TB.Controls.Add(this.txtHomeCountry);
            this.Home_TB.Controls.Add(this.txtHomeZipCode);
            this.Home_TB.Controls.Add(this.txtHomeState);
            this.Home_TB.Controls.Add(this.txtHomeCity);
            this.Home_TB.Controls.Add(this.txtHomeWebPage);
            this.Home_TB.Controls.Add(this.label9);
            this.Home_TB.Controls.Add(this.label8);
            this.Home_TB.Controls.Add(this.label7);
            this.Home_TB.Controls.Add(this.label6);
            this.Home_TB.Controls.Add(this.label5);
            this.Home_TB.Controls.Add(this.label4);
            this.Home_TB.Controls.Add(this.label3);
            this.Home_TB.Controls.Add(this.label2);
            this.Home_TB.Controls.Add(this.label1);
            this.Home_TB.Controls.Add(this.Home_Label);
            this.Home_TB.Location = new System.Drawing.Point(4, 22);
            this.Home_TB.Name = "Home_TB";
            this.Home_TB.Size = new System.Drawing.Size(517, 336);
            this.Home_TB.TabIndex = 1;
            this.Home_TB.Text = "Home";
            this.Home_TB.UseVisualStyleBackColor = true;
            // 
            // txtHomeStreet
            // 
            this.txtHomeStreet.Location = new System.Drawing.Point(106, 77);
            this.txtHomeStreet.Name = "txtHomeStreet";
            this.txtHomeStreet.Size = new System.Drawing.Size(155, 63);
            this.txtHomeStreet.TabIndex = 1;
            this.txtHomeStreet.Text = "";
            // 
            // txtHomeMobile
            // 
            this.txtHomeMobile.Location = new System.Drawing.Point(353, 157);
            this.txtHomeMobile.Name = "txtHomeMobile";
            this.txtHomeMobile.Size = new System.Drawing.Size(155, 20);
            this.txtHomeMobile.TabIndex = 8;
            // 
            // txtHomeFax
            // 
            this.txtHomeFax.Location = new System.Drawing.Point(353, 120);
            this.txtHomeFax.Name = "txtHomeFax";
            this.txtHomeFax.Size = new System.Drawing.Size(155, 20);
            this.txtHomeFax.TabIndex = 7;
            // 
            // txtHomePhone
            // 
            this.txtHomePhone.Location = new System.Drawing.Point(353, 77);
            this.txtHomePhone.Name = "txtHomePhone";
            this.txtHomePhone.Size = new System.Drawing.Size(155, 20);
            this.txtHomePhone.TabIndex = 6;
            // 
            // txtHomeCountry
            // 
            this.txtHomeCountry.Location = new System.Drawing.Point(106, 257);
            this.txtHomeCountry.Name = "txtHomeCountry";
            this.txtHomeCountry.Size = new System.Drawing.Size(155, 20);
            this.txtHomeCountry.TabIndex = 5;
            // 
            // txtHomeZipCode
            // 
            this.txtHomeZipCode.Location = new System.Drawing.Point(106, 223);
            this.txtHomeZipCode.Name = "txtHomeZipCode";
            this.txtHomeZipCode.Size = new System.Drawing.Size(155, 20);
            this.txtHomeZipCode.TabIndex = 4;
            // 
            // txtHomeState
            // 
            this.txtHomeState.Location = new System.Drawing.Point(106, 190);
            this.txtHomeState.Name = "txtHomeState";
            this.txtHomeState.Size = new System.Drawing.Size(155, 20);
            this.txtHomeState.TabIndex = 3;
            // 
            // txtHomeCity
            // 
            this.txtHomeCity.Location = new System.Drawing.Point(106, 157);
            this.txtHomeCity.Name = "txtHomeCity";
            this.txtHomeCity.Size = new System.Drawing.Size(155, 20);
            this.txtHomeCity.TabIndex = 2;
            // 
            // txtHomeWebPage
            // 
            this.txtHomeWebPage.Location = new System.Drawing.Point(106, 296);
            this.txtHomeWebPage.Name = "txtHomeWebPage";
            this.txtHomeWebPage.Size = new System.Drawing.Size(402, 20);
            this.txtHomeWebPage.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(287, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Mobile:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(287, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Fax:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(287, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Phone:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Web Page:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 260);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Country/Region:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Zip Code:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "State/Province:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "City:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Street Address:";
            // 
            // Home_Label
            // 
            this.Home_Label.AutoSize = true;
            this.Home_Label.Location = new System.Drawing.Point(63, 30);
            this.Home_Label.Name = "Home_Label";
            this.Home_Label.Size = new System.Drawing.Size(265, 13);
            this.Home_Label.TabIndex = 0;
            this.Home_Label.Text = "Enter home-related information about this contact here.";
            // 
            // Business_TB
            // 
            this.Business_TB.Controls.Add(this.txtIP);
            this.Business_TB.Controls.Add(this.txtBusiPager);
            this.Business_TB.Controls.Add(this.txtBusiFax);
            this.Business_TB.Controls.Add(this.txtBusiPhone);
            this.Business_TB.Controls.Add(this.label20);
            this.Business_TB.Controls.Add(this.label21);
            this.Business_TB.Controls.Add(this.label22);
            this.Business_TB.Controls.Add(this.label23);
            this.Business_TB.Controls.Add(this.label19);
            this.Business_TB.Controls.Add(this.txtCompany);
            this.Business_TB.Controls.Add(this.label17);
            this.Business_TB.Controls.Add(this.label18);
            this.Business_TB.Controls.Add(this.txtBusiStreetAddress);
            this.Business_TB.Controls.Add(this.txtOffice);
            this.Business_TB.Controls.Add(this.txtDepartment);
            this.Business_TB.Controls.Add(this.txtJobtitle);
            this.Business_TB.Controls.Add(this.txtBusiCountry);
            this.Business_TB.Controls.Add(this.txtBusiZipCode);
            this.Business_TB.Controls.Add(this.txtBusiState);
            this.Business_TB.Controls.Add(this.txtBusiCity);
            this.Business_TB.Controls.Add(this.txtBusiWebPage);
            this.Business_TB.Controls.Add(this.label10);
            this.Business_TB.Controls.Add(this.label11);
            this.Business_TB.Controls.Add(this.label12);
            this.Business_TB.Controls.Add(this.label13);
            this.Business_TB.Controls.Add(this.label14);
            this.Business_TB.Controls.Add(this.label15);
            this.Business_TB.Controls.Add(this.label16);
            this.Business_TB.Controls.Add(this.Business_Lable);
            this.Business_TB.Location = new System.Drawing.Point(4, 22);
            this.Business_TB.Name = "Business_TB";
            this.Business_TB.Size = new System.Drawing.Size(517, 336);
            this.Business_TB.TabIndex = 2;
            this.Business_TB.Text = "Business";
            this.Business_TB.UseVisualStyleBackColor = true;
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(353, 270);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(155, 20);
            this.txtIP.TabIndex = 13;
            // 
            // txtBusiPager
            // 
            this.txtBusiPager.Location = new System.Drawing.Point(353, 240);
            this.txtBusiPager.Name = "txtBusiPager";
            this.txtBusiPager.Size = new System.Drawing.Size(155, 20);
            this.txtBusiPager.TabIndex = 12;
            // 
            // txtBusiFax
            // 
            this.txtBusiFax.Location = new System.Drawing.Point(353, 211);
            this.txtBusiFax.Name = "txtBusiFax";
            this.txtBusiFax.Size = new System.Drawing.Size(155, 20);
            this.txtBusiFax.TabIndex = 11;
            // 
            // txtBusiPhone
            // 
            this.txtBusiPhone.Location = new System.Drawing.Point(353, 180);
            this.txtBusiPhone.Name = "txtBusiPhone";
            this.txtBusiPhone.Size = new System.Drawing.Size(155, 20);
            this.txtBusiPhone.TabIndex = 10;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(287, 273);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "IP Phone:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(287, 243);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "Pager:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(287, 214);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Fax:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(287, 183);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Phone:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 83);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Company:";
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(106, 80);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Size = new System.Drawing.Size(155, 20);
            this.txtCompany.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(287, 117);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Department:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(287, 83);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Job Title:";
            // 
            // txtBusiStreetAddress
            // 
            this.txtBusiStreetAddress.Location = new System.Drawing.Point(106, 109);
            this.txtBusiStreetAddress.Name = "txtBusiStreetAddress";
            this.txtBusiStreetAddress.Size = new System.Drawing.Size(155, 63);
            this.txtBusiStreetAddress.TabIndex = 2;
            this.txtBusiStreetAddress.Text = "";
            // 
            // txtOffice
            // 
            this.txtOffice.Location = new System.Drawing.Point(353, 149);
            this.txtOffice.Name = "txtOffice";
            this.txtOffice.Size = new System.Drawing.Size(155, 20);
            this.txtOffice.TabIndex = 9;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(353, 114);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(155, 20);
            this.txtDepartment.TabIndex = 8;
            // 
            // txtJobtitle
            // 
            this.txtJobtitle.Location = new System.Drawing.Point(353, 80);
            this.txtJobtitle.Name = "txtJobtitle";
            this.txtJobtitle.Size = new System.Drawing.Size(155, 20);
            this.txtJobtitle.TabIndex = 7;
            // 
            // txtBusiCountry
            // 
            this.txtBusiCountry.Location = new System.Drawing.Point(106, 270);
            this.txtBusiCountry.Name = "txtBusiCountry";
            this.txtBusiCountry.Size = new System.Drawing.Size(155, 20);
            this.txtBusiCountry.TabIndex = 6;
            // 
            // txtBusiZipCode
            // 
            this.txtBusiZipCode.Location = new System.Drawing.Point(106, 240);
            this.txtBusiZipCode.Name = "txtBusiZipCode";
            this.txtBusiZipCode.Size = new System.Drawing.Size(155, 20);
            this.txtBusiZipCode.TabIndex = 5;
            // 
            // txtBusiState
            // 
            this.txtBusiState.Location = new System.Drawing.Point(106, 211);
            this.txtBusiState.Name = "txtBusiState";
            this.txtBusiState.Size = new System.Drawing.Size(155, 20);
            this.txtBusiState.TabIndex = 4;
            // 
            // txtBusiCity
            // 
            this.txtBusiCity.Location = new System.Drawing.Point(106, 180);
            this.txtBusiCity.Name = "txtBusiCity";
            this.txtBusiCity.Size = new System.Drawing.Size(155, 20);
            this.txtBusiCity.TabIndex = 3;
            // 
            // txtBusiWebPage
            // 
            this.txtBusiWebPage.Location = new System.Drawing.Point(106, 299);
            this.txtBusiWebPage.Name = "txtBusiWebPage";
            this.txtBusiWebPage.Size = new System.Drawing.Size(402, 20);
            this.txtBusiWebPage.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(287, 152);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Office:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Web Page:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 273);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Country/Region:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 243);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Zip Code:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 214);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "State/Province:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 183);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "City:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Street Address:";
            // 
            // Business_Lable
            // 
            this.Business_Lable.AutoSize = true;
            this.Business_Lable.Location = new System.Drawing.Point(63, 30);
            this.Business_Lable.Name = "Business_Lable";
            this.Business_Lable.Size = new System.Drawing.Size(280, 13);
            this.Business_Lable.TabIndex = 0;
            this.Business_Lable.Text = "Enter business-related information about this contact here.";
            // 
            // Personal_TB
            // 
            this.Personal_TB.Controls.Add(this.txtlstChildNamesList);
            this.Personal_TB.Controls.Add(this.btnRemoveChild);
            this.Personal_TB.Controls.Add(this.btnEditChild);
            this.Personal_TB.Controls.Add(this.lstChildNamesList);
            this.Personal_TB.Controls.Add(this.btnAddChild);
            this.Personal_TB.Controls.Add(this.txtChildName);
            this.Personal_TB.Controls.Add(this.label43);
            this.Personal_TB.Controls.Add(this.txtAnniversary);
            this.Personal_TB.Controls.Add(this.txtBirthday);
            this.Personal_TB.Controls.Add(this.txtGender);
            this.Personal_TB.Controls.Add(this.txtSpouse);
            this.Personal_TB.Controls.Add(this.label25);
            this.Personal_TB.Controls.Add(this.label26);
            this.Personal_TB.Controls.Add(this.label27);
            this.Personal_TB.Controls.Add(this.label28);
            this.Personal_TB.Controls.Add(this.Personal_Lable);
            this.Personal_TB.Location = new System.Drawing.Point(4, 22);
            this.Personal_TB.Name = "Personal_TB";
            this.Personal_TB.Size = new System.Drawing.Size(517, 336);
            this.Personal_TB.TabIndex = 3;
            this.Personal_TB.Text = "Personal";
            this.Personal_TB.UseVisualStyleBackColor = true;
            // 
            // txtlstChildNamesList
            // 
            this.txtlstChildNamesList.Location = new System.Drawing.Point(493, 3);
            this.txtlstChildNamesList.Name = "txtlstChildNamesList";
            this.txtlstChildNamesList.Size = new System.Drawing.Size(11, 29);
            this.txtlstChildNamesList.TabIndex = 0;
            this.txtlstChildNamesList.Text = "";
            this.txtlstChildNamesList.Visible = false;
            // 
            // btnRemoveChild
            // 
            this.btnRemoveChild.Enabled = false;
            this.btnRemoveChild.Location = new System.Drawing.Point(388, 174);
            this.btnRemoveChild.Name = "btnRemoveChild";
            this.btnRemoveChild.Size = new System.Drawing.Size(116, 23);
            this.btnRemoveChild.TabIndex = 4;
            this.btnRemoveChild.Text = "&Remove";
            this.btnRemoveChild.UseVisualStyleBackColor = true;
            this.btnRemoveChild.Click += new System.EventHandler(this.RemoveSelectedChild);
            // 
            // btnEditChild
            // 
            this.btnEditChild.Enabled = false;
            this.btnEditChild.Location = new System.Drawing.Point(388, 145);
            this.btnEditChild.Name = "btnEditChild";
            this.btnEditChild.Size = new System.Drawing.Size(116, 23);
            this.btnEditChild.TabIndex = 3;
            this.btnEditChild.Text = "&Edit";
            this.btnEditChild.UseVisualStyleBackColor = true;
            this.btnEditChild.Click += new System.EventHandler(this.EditSelectedChild);
            // 
            // lstChildNamesList
            // 
            this.lstChildNamesList.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstChildNamesList.ForeColor = System.Drawing.Color.Blue;
            this.lstChildNamesList.FormattingEnabled = true;
            this.lstChildNamesList.ItemHeight = 14;
            this.lstChildNamesList.Location = new System.Drawing.Point(98, 145);
            this.lstChildNamesList.Name = "lstChildNamesList";
            this.lstChildNamesList.Size = new System.Drawing.Size(283, 88);
            this.lstChildNamesList.TabIndex = 5;
            this.lstChildNamesList.SelectedIndexChanged += new System.EventHandler(this.CheckChildItemSelection);
            // 
            // btnAddChild
            // 
            this.btnAddChild.Location = new System.Drawing.Point(388, 112);
            this.btnAddChild.Name = "btnAddChild";
            this.btnAddChild.Size = new System.Drawing.Size(116, 23);
            this.btnAddChild.TabIndex = 2;
            this.btnAddChild.Text = "&Add";
            this.btnAddChild.UseVisualStyleBackColor = true;
            this.btnAddChild.Click += new System.EventHandler(this.AddChild);
            // 
            // txtChildName
            // 
            this.txtChildName.Location = new System.Drawing.Point(98, 114);
            this.txtChildName.Name = "txtChildName";
            this.txtChildName.Size = new System.Drawing.Size(283, 20);
            this.txtChildName.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(15, 117);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 13);
            this.label43.TabIndex = 0;
            this.label43.Text = "Child Name";
            // 
            // txtAnniversary
            // 
            this.txtAnniversary.Checked = false;
            this.txtAnniversary.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtAnniversary.Location = new System.Drawing.Point(98, 305);
            this.txtAnniversary.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtAnniversary.Name = "txtAnniversary";
            this.txtAnniversary.ShowCheckBox = true;
            this.txtAnniversary.Size = new System.Drawing.Size(163, 20);
            this.txtAnniversary.TabIndex = 8;
            this.txtAnniversary.Value = new System.DateTime(2007, 11, 12, 0, 0, 0, 0);
            // 
            // txtBirthday
            // 
            this.txtBirthday.Checked = false;
            this.txtBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtBirthday.Location = new System.Drawing.Point(98, 276);
            this.txtBirthday.Name = "txtBirthday";
            this.txtBirthday.ShowCheckBox = true;
            this.txtBirthday.Size = new System.Drawing.Size(163, 20);
            this.txtBirthday.TabIndex = 7;
            // 
            // txtGender
            // 
            this.txtGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Un Specified",
            "Male",
            "Female"});
            this.txtGender.Location = new System.Drawing.Point(98, 246);
            this.txtGender.MaxDropDownItems = 3;
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(163, 21);
            this.txtGender.TabIndex = 6;
            // 
            // txtSpouse
            // 
            this.txtSpouse.Location = new System.Drawing.Point(98, 80);
            this.txtSpouse.Name = "txtSpouse";
            this.txtSpouse.Size = new System.Drawing.Size(283, 20);
            this.txtSpouse.TabIndex = 0;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 309);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Anniversary:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 249);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "Gender:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 83);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Spouse:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(15, 280);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Birthday:";
            // 
            // Personal_Lable
            // 
            this.Personal_Lable.AutoSize = true;
            this.Personal_Lable.Location = new System.Drawing.Point(63, 30);
            this.Personal_Lable.Name = "Personal_Lable";
            this.Personal_Lable.Size = new System.Drawing.Size(244, 13);
            this.Personal_Lable.TabIndex = 0;
            this.Personal_Lable.Text = "Enter personal information about this contact here.";
            // 
            // Other_TB
            // 
            this.Other_TB.Controls.Add(this.IsContactShared);
            this.Other_TB.Controls.Add(this.txtNotes);
            this.Other_TB.Controls.Add(this.label24);
            this.Other_TB.Controls.Add(this.Other_Lable);
            this.Other_TB.Location = new System.Drawing.Point(4, 22);
            this.Other_TB.Name = "Other_TB";
            this.Other_TB.Size = new System.Drawing.Size(517, 336);
            this.Other_TB.TabIndex = 4;
            this.Other_TB.Text = "Other";
            this.Other_TB.UseVisualStyleBackColor = true;
            // 
            // IsContactShared
            // 
            this.IsContactShared.AutoSize = true;
            this.IsContactShared.Location = new System.Drawing.Point(18, 305);
            this.IsContactShared.Name = "IsContactShared";
            this.IsContactShared.Size = new System.Drawing.Size(169, 17);
            this.IsContactShared.TabIndex = 2;
            this.IsContactShared.Text = "Add this Contact to shared list.";
            this.IsContactShared.UseVisualStyleBackColor = true;
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(18, 101);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(447, 196);
            this.txtNotes.TabIndex = 0;
            this.txtNotes.Text = "";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 78);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(38, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Notes:";
            // 
            // Other_Lable
            // 
            this.Other_Lable.AutoSize = true;
            this.Other_Lable.Location = new System.Drawing.Point(63, 30);
            this.Other_Lable.Name = "Other_Lable";
            this.Other_Lable.Size = new System.Drawing.Size(198, 13);
            this.Other_Lable.TabIndex = 0;
            this.Other_Lable.Text = "Additional information about this contact.";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(9, 374);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.DeleteContact);
            // 
            // frmNewContact
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(536, 405);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.AC_Properties_Tab);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNewContact";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Properties";
            this.AC_Properties_Tab.ResumeLayout(false);
            this.Summary_TB.ResumeLayout(false);
            this.Summary_TB.PerformLayout();
            this.Name_TB.ResumeLayout(false);
            this.Name_TB.PerformLayout();
            this.Home_TB.ResumeLayout(false);
            this.Home_TB.PerformLayout();
            this.Business_TB.ResumeLayout(false);
            this.Business_TB.PerformLayout();
            this.Personal_TB.ResumeLayout(false);
            this.Personal_TB.PerformLayout();
            this.Other_TB.ResumeLayout(false);
            this.Other_TB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        System.Windows.Forms.Button btnCancel;
        System.Windows.Forms.Button btnOk;
        System.Windows.Forms.TabControl AC_Properties_Tab;
        System.Windows.Forms.TabPage Name_TB;
        System.Windows.Forms.Label Nick_Lable;
        System.Windows.Forms.TextBox txtNickName;
        System.Windows.Forms.TextBox txtDisplay;
        System.Windows.Forms.TextBox txtTitle;
        System.Windows.Forms.TextBox txtLastName;
        System.Windows.Forms.TextBox txtMiddleName;
        System.Windows.Forms.TextBox txtFirstName;
        System.Windows.Forms.Label F_Name_Lable;
        System.Windows.Forms.Label Title_Lable;
        System.Windows.Forms.Label M_Name_Lable;
        System.Windows.Forms.Label Display_Lable;
        System.Windows.Forms.Label L_Name_Lable;
        System.Windows.Forms.Label Name_Label;
        System.Windows.Forms.TabPage Home_TB;
        System.Windows.Forms.RichTextBox txtHomeStreet;
        System.Windows.Forms.TextBox txtHomeMobile;
        System.Windows.Forms.TextBox txtHomeFax;
        System.Windows.Forms.TextBox txtHomePhone;
        System.Windows.Forms.TextBox txtHomeCountry;
        System.Windows.Forms.TextBox txtHomeZipCode;
        System.Windows.Forms.TextBox txtHomeState;
        System.Windows.Forms.TextBox txtHomeCity;
        System.Windows.Forms.TextBox txtHomeWebPage;
        System.Windows.Forms.Label label9;
        System.Windows.Forms.Label label8;
        System.Windows.Forms.Label label7;
        System.Windows.Forms.Label label6;
        System.Windows.Forms.Label label5;
        System.Windows.Forms.Label label4;
        System.Windows.Forms.Label label3;
        System.Windows.Forms.Label label2;
        System.Windows.Forms.Label label1;
        System.Windows.Forms.Label Home_Label;
        System.Windows.Forms.TabPage Business_TB;
        System.Windows.Forms.TextBox txtIP;
        System.Windows.Forms.TextBox txtBusiPager;
        System.Windows.Forms.TextBox txtBusiFax;
        System.Windows.Forms.TextBox txtBusiPhone;
        System.Windows.Forms.Label label20;
        System.Windows.Forms.Label label21;
        System.Windows.Forms.Label label22;
        System.Windows.Forms.Label label23;
        System.Windows.Forms.Label label19;
        System.Windows.Forms.TextBox txtCompany;
        System.Windows.Forms.Label label17;
        System.Windows.Forms.Label label18;
        System.Windows.Forms.RichTextBox txtBusiStreetAddress;
        System.Windows.Forms.TextBox txtOffice;
        System.Windows.Forms.TextBox txtDepartment;
        System.Windows.Forms.TextBox txtJobtitle;
        System.Windows.Forms.TextBox txtBusiCountry;
        System.Windows.Forms.TextBox txtBusiZipCode;
        System.Windows.Forms.TextBox txtBusiState;
        System.Windows.Forms.TextBox txtBusiCity;
        System.Windows.Forms.TextBox txtBusiWebPage;
        System.Windows.Forms.Label label10;
        System.Windows.Forms.Label label11;
        System.Windows.Forms.Label label12;
        System.Windows.Forms.Label label13;
        System.Windows.Forms.Label label14;
        System.Windows.Forms.Label label15;
        System.Windows.Forms.Label label16;
        System.Windows.Forms.Label Business_Lable;
        System.Windows.Forms.TabPage Personal_TB;
        System.Windows.Forms.TextBox txtSpouse;
        System.Windows.Forms.Label label25;
        System.Windows.Forms.Label label26;
        System.Windows.Forms.Label label27;
        System.Windows.Forms.Label label28;
        System.Windows.Forms.Label Personal_Lable;
        System.Windows.Forms.TabPage Other_TB;
        System.Windows.Forms.RichTextBox txtNotes;
        System.Windows.Forms.Label label24;
        System.Windows.Forms.Label Other_Lable;
        System.Windows.Forms.Button btnDelete;
        System.Windows.Forms.DateTimePicker txtBirthday;
        System.Windows.Forms.ComboBox txtGender;
        System.Windows.Forms.DateTimePicker txtAnniversary;
        System.Windows.Forms.TabPage Summary_TB;
        System.Windows.Forms.Label label29;
        System.Windows.Forms.Label label42;
        System.Windows.Forms.Label label41;
        System.Windows.Forms.Label label40;
        System.Windows.Forms.Label label39;
        System.Windows.Forms.Label label38;
        System.Windows.Forms.Label label37;
        System.Windows.Forms.Label label36;
        System.Windows.Forms.Label label35;
        System.Windows.Forms.Label label34;
        System.Windows.Forms.Label label32;
        System.Windows.Forms.Label label33;
        System.Windows.Forms.Label label31;
        System.Windows.Forms.Label S_L_Name;
        System.Windows.Forms.Label lblDBWP;
        System.Windows.Forms.Label lblDCompanyName;
        System.Windows.Forms.Label lblDOffice;
        System.Windows.Forms.Label lblDDepartment;
        System.Windows.Forms.Label lblDJobTitle;
        System.Windows.Forms.Label lblDBusinessFax;
        System.Windows.Forms.Label lblDBusinessPhone;
        System.Windows.Forms.Label lblDPWP;
        System.Windows.Forms.Label lblDPager;
        System.Windows.Forms.Label lblDMobile;
        System.Windows.Forms.Label lblDHomePhone;
        System.Windows.Forms.Label lblDEmailAddress;
        System.Windows.Forms.Label lblDName;
        System.Windows.Forms.Button btnAddEmail;
        System.Windows.Forms.TextBox txtEmail;
        System.Windows.Forms.Label label30;
        System.Windows.Forms.Button btnSetDefaultEmail;
        System.Windows.Forms.Button btnRemoveEmail;
        System.Windows.Forms.Button btnEditEmail;
        System.Windows.Forms.ListBox lstEmailList;
        System.Windows.Forms.Button btnRemoveChild;
        System.Windows.Forms.Button btnEditChild;
        System.Windows.Forms.ListBox lstChildNamesList;
        System.Windows.Forms.Button btnAddChild;
        System.Windows.Forms.TextBox txtChildName;
        System.Windows.Forms.Label label43;
        private System.Windows.Forms.RichTextBox txtlstEmailList;
        private System.Windows.Forms.RichTextBox txtlstChildNamesList;
        private System.Windows.Forms.CheckBox IsContactShared;
    }
}
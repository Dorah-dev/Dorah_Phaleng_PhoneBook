using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmNewContact : Form
    {
        #region Declerations
        bool AddNewContact;
        string ContactId, UserID, DisplayName, DefaultEMail = "";
        int DefaultEMailIndex;
        string CategoryID = "UC";

        public frmNewContact(bool AddNewContact, string ContactId, string CategoryID)
        {
            InitializeComponent();
            this.AddNewContact = AddNewContact;
            this.ContactId = ContactId;
            this.UserID = UserPolicies.UserID;
            btnDelete.Enabled = !AddNewContact;
            txtGender.SelectedIndex = 0;
            if (CategoryID != null) this.CategoryID = CategoryID;
            if (AddNewContact) AC_Properties_Tab.TabPages.Remove(Summary_TB);
            else
            {
                GetContactDetails();
                RetriveSummary();
            }
        }

        #endregion

        #region Other Methods
        void ShowDisplayName(object sender, EventArgs e)
        {
            DisplayName = txtFirstName.Text.Trim() + " " + txtMiddleName.Text.Trim();
            DisplayName = DisplayName.Trim() + " " + txtLastName.Text.Trim();

            txtDisplay.Text = DisplayName.Trim();
            this.Text = DisplayName.Trim() + " Properties";
        }

        void SetTitleName(object sender, EventArgs e)
        {
            DisplayName = txtDisplay.Text;
            this.Text = DisplayName + " Properties";
        }

        void RetriveSummary()
        {
            lblDName.Text = DisplayName;
            lblDEmailAddress.Text = DefaultEMail;
            lblDHomePhone.Text = txtHomePhone.Text;
            lblDPager.Text = txtBusiPager.Text;
            lblDMobile.Text = txtHomeMobile.Text;
            lblDPWP.Text = txtHomeWebPage.Text;
            lblDBusinessPhone.Text = txtBusiPhone.Text;
            lblDBusinessFax.Text = txtBusiFax.Text;
            lblDJobTitle.Text = txtJobtitle.Text;
            lblDDepartment.Text = txtDepartment.Text;
            lblDOffice.Text = txtOffice.Text;
            lblDCompanyName.Text = txtCompany.Text;
            lblDBWP.Text = txtBusiWebPage.Text;
        }
        #endregion

        #region Miscellaneous

        #region Email
        void AddEmail(object sender, EventArgs e)
        {
            if (!ValidateEmail(txtEmail.Text))
            {
                DialogResult DR = MessageBox.Show("This Email Address dose not seem to be valid. However do you want to add it to the list.", "Invalid E-mail Id", MessageBoxButtons.YesNo);
                if (DR == DialogResult.No) return;
            }

            if (DefaultEMail.Length == 0)
            {
                DefaultEMail = txtEmail.Text;
                lstEmailList.Items.Add(txtEmail.Text + " (Default E-mail)");
                DefaultEMailIndex = 0;
            }
            else lstEmailList.Items.Add(txtEmail.Text);
        }

        void EditSelectedEmail(object sender, EventArgs e)
        {
            if (txtEmail.Text.Length == 0)
            {
                MessageBox.Show("First type the new Email Id to be changed.", "Edit Failed");
                return;
            }
            else if (!ValidateEmail(txtEmail.Text))
            {
                DialogResult DR = MessageBox.Show("The new Email Id dose not seem to be valid. How ever do you want to proceed?", "Edit Failed", MessageBoxButtons.YesNo);
                if (DR == DialogResult.No) return;
            }

            DialogResult DR1 = MessageBox.Show("Are you sure to replace the mail id \"" + lstEmailList.SelectedItem.ToString() + "\" with \"" + txtEmail.Text + "\"", "Confirm Edit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR1 == DialogResult.No) return;

            int tempindex = lstEmailList.SelectedIndex;
            lstEmailList.Items.RemoveAt(tempindex);
            if (tempindex == DefaultEMailIndex)
            {
                lstEmailList.Items.Insert(tempindex, txtEmail.Text + " (Default E-Mail)");
                DefaultEMail = txtEmail.Text;
            }
            else lstEmailList.Items.Insert(tempindex, txtEmail.Text);
        }

        void RemoveSelectedEmail(object sender, EventArgs e)
        {
            DialogResult DR = MessageBox.Show("Are you sure to remove the selected Email Address?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR == DialogResult.Yes)
            {
                if (lstEmailList.SelectedIndex == DefaultEMailIndex)
                {
                    lstEmailList.Items.RemoveAt(lstEmailList.SelectedIndex);
                    if (lstEmailList.Items.Count > 0)
                    {
                        lstEmailList.Items[0] = lstEmailList.Items[0] + " (Default E-Mail)";
                        DefaultEMail = lstEmailList.Items[0].ToString();
                        DefaultEMailIndex = 0;
                    }
                    else
                    {
                        DefaultEMail = "";
                        DefaultEMailIndex = 0;
                    }
                }
                else lstEmailList.Items.RemoveAt(lstEmailList.SelectedIndex);
            }
        }

        void SetAsDefaultEmail(object sender, EventArgs e)
        {
            if (lstEmailList.SelectedIndex != DefaultEMailIndex)
            {
                lstEmailList.Items[DefaultEMailIndex] = DefaultEMail;
                DefaultEMail = lstEmailList.Items[lstEmailList.SelectedIndex].ToString();
                DefaultEMailIndex = lstEmailList.SelectedIndex;
                lstEmailList.Items[lstEmailList.SelectedIndex] = lstEmailList.Items[lstEmailList.SelectedIndex] + " (Default E-Mail)";
            }
        }

        void CheckEmailItemSelection(object sender, EventArgs e)
        {
            if (lstEmailList.SelectedIndex == -1)
                btnEditEmail.Enabled = btnRemoveEmail.Enabled = btnSetDefaultEmail.Enabled = false;
            else
                btnEditEmail.Enabled = btnRemoveEmail.Enabled = btnSetDefaultEmail.Enabled = true;
        }

        bool ValidateEmail(string Email)
        {
            if ((Email.IndexOf('@') != Email.LastIndexOf('@')) || Email.IndexOf('@') == -1) return false;

            if (Email[Email.IndexOf('@') + 1] == '.') return false;

            if ((Email.LastIndexOf(".") == Email.Length - 1) || Email.LastIndexOf(".") == -1) return false;

            if (Email.Contains(" ") || Email.Contains("\\") || Email.Contains("/") || Email.Contains("*") || Email.Contains(";")) return false;

            return true;
        }

        #endregion

        #region Child

        private void AddChild(object sender, EventArgs e)
        {
            if (txtChildName.Text.Length == 0)
            {
                MessageBox.Show("Enter the name of the child to be added.");
                return;
            }
            lstChildNamesList.Items.Add(txtChildName.Text);
        }

        private void EditSelectedChild(object sender, EventArgs e)
        {
            if (txtChildName.Text.Length == 0)
            {
                MessageBox.Show("First type the new name for the Child to be changed.", "Edit Failed");
                return;
            }

            DialogResult DR = MessageBox.Show("Are you sure to replace the child '" + lstChildNamesList.SelectedItem.ToString() + "' with '" + txtChildName.Text + "'", "Confirm Edit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR == DialogResult.Yes)
            {
                int tempindex = lstChildNamesList.SelectedIndex;
                lstChildNamesList.Items.RemoveAt(tempindex);
                lstChildNamesList.Items.Insert(tempindex, txtChildName.Text);
            }
        }

        private void RemoveSelectedChild(object sender, EventArgs e)
        {
            DialogResult DR = MessageBox.Show("Are you sure to remove the selected child?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR == DialogResult.Yes)
            {
                lstChildNamesList.Items.RemoveAt(lstChildNamesList.SelectedIndex);
            }
        }

        private void CheckChildItemSelection(object sender, EventArgs e)
        {
            if (lstChildNamesList.SelectedIndex == -1)
                btnEditChild.Enabled = btnRemoveChild.Enabled = false;
            else
                btnEditChild.Enabled = btnRemoveChild.Enabled = true;
        }

        #endregion

        #endregion

        #region Button Functions

        void DeleteContact(object sender, EventArgs e)
        {
            DialogResult DR = MessageBox.Show("Are you sure to delete the selected contact permenantly?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR == DialogResult.No) return;

            Program.Connection.CommandText = "delete from ContactsData where CIdentity=" + ContactId;
            MessageBox.Show(Program.Connection.ExecuteNonQuery().ToString() + " Contact had been deleted.");
            this.Close();
        }

        void SaveChanges(object sender, EventArgs e)
        {
            if (DisplayName == null) { MessageBox.Show("Display Name cannot be left blank", "Invalid Data"); return; }

            if (Program.HasChars(txtBusiFax.Text.Trim()) || Program.HasChars(txtBusiPager.Text.Trim()) || Program.HasChars(txtBusiPhone.Text.Trim()) || Program.HasChars(txtHomeFax.Text.Trim()) || Program.HasChars(txtHomeMobile.Text.Trim()) || Program.HasChars(txtHomePhone.Text.Trim()) || Program.HasChars(txtIP.Text.Trim()))
            {
                MessageBox.Show("Any of the phone numbers cannot contain charactors.", "Invalid Data");
                return;
            }

            if (Program.HasChars(txtBusiZipCode.Text.Trim()) || Program.HasChars(txtHomeZipCode.Text.Trim()))
            {
                MessageBox.Show("Home or office zip code cannot contain charactors.", "Invalid Data");
                return;
            }

            //if (txtCategory.SelectedIndex == -1) { MessageBox.Show("Select a Category in which this contact had to be added.", "Invalid Category"); return; }
            txtlstChildNamesList.Text = txtlstEmailList.Text = "";

            for (int i = 0; i < lstEmailList.Items.Count; i++)
            {
                if (i == 0)
                    if (i != DefaultEMailIndex)
                        txtlstEmailList.Text = lstEmailList.Items[i].ToString();
                    else txtlstEmailList.Text = DefaultEMail;
                else
                    if (i != DefaultEMailIndex)
                        txtlstEmailList.Text += "\n" + lstEmailList.Items[i].ToString();
                    else txtlstEmailList.Text += "\n" + DefaultEMail;
            }

            for (int i = 0; i < lstChildNamesList.Items.Count; i++)
            {
                if (i == 0) txtlstChildNamesList.Text = lstChildNamesList.Items[i].ToString();
                else txtlstChildNamesList.Text += "\n" + lstChildNamesList.Items[i].ToString();
            }

            string tmpBirthday = "", tmpAnniversary = "";
            if (txtBirthday.Checked) tmpBirthday = txtBirthday.Text;
            if (txtAnniversary.Checked) tmpAnniversary = txtAnniversary.Text;

            if (AddNewContact)
            {
                string PhoneCheck = null;
                if (txtHomePhone.Text.Trim().Length != 0)
                    PhoneCheck = "'" + Converter.Encrypt(txtHomePhone.Text.Trim()) + "'";

                if (PhoneCheck != null && txtHomeFax.Text.Trim().Length != 0) PhoneCheck += ",";
                if (txtHomeFax.Text.Trim().Length != 0) PhoneCheck += "'" + Converter.Encrypt(txtHomeFax.Text.Trim()) + "'";

                if (PhoneCheck != null && txtHomeMobile.Text.Trim().Length != 0) PhoneCheck += ",";
                if (txtHomeMobile.Text.Trim().Length != 0) PhoneCheck += "'" + Converter.Encrypt(txtHomeMobile.Text.Trim()) + "'";

                if (PhoneCheck != null && txtBusiPhone.Text.Trim().Length != 0) PhoneCheck += ",";
                if (txtBusiPhone.Text.Trim().Length != 0) PhoneCheck += "'" + Converter.Encrypt(txtBusiPhone.Text.Trim()) + "'";

                if (PhoneCheck != null)
                {
                    PhoneCheck = "(" + PhoneCheck + ")";
                    string Command = "select * from ContactsData where (HomePhone in " + PhoneCheck + " or HomeFax in " + PhoneCheck + " or Mobile in " + PhoneCheck + " or OfficePhone in " + PhoneCheck + ")";
                    if (!UserPolicies.IsAdministrator) Command += " and UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";

                    Program.Connection.CommandText = Command;
                    System.Data.DataTable Table = new System.Data.DataTable();
                    Program.Connection.FillDataTable(Table, false);
                    if (Table.Rows.Count != 0)
                        if (MessageBox.Show("Already '" + Table.Rows.Count.ToString() + "' contact contains same details as that of this contact.\n\nAre you sure to add these contacts to your list?", "Address Book", MessageBoxButtons.YesNo) == DialogResult.No) return;
                }
            }
            else
            {
                Program.Connection.CommandText = "delete from ContactsData where CIdentity=" + ContactId;
                Program.Connection.ExecuteNonQuery();
            }
            Program.Connection.CommandText = "insert into ContactsData(UserID,Category,SDisplay,SEmailList,FirstName,MiddleName,LastName,Display,"
                + "Title,NickName,DefaultEmail,EmailList,HomeAddress,HomeCity,HomeState,HomeZipCode,HomeCountry,HomePhone,HomeFax,Mobile,"
                + "HomeWebPage,Company,OfficeAddress,OfficeCity,OfficeState,OfficeZipCode,OfficeCountry,JobTitle,Department,Office,OfficePhone,OfficeFax,"
                + "Pager,IP,OfficeWebPage,Spouse,ChildNames,Gender,Birthday,Anniversary,OtherNotes, Shared) values (@UserID,@Category,@SDisplay,"
                + "@SEmailList,@FirstName,@MiddleName,@LastName,@Display,@Title,@NickName,@DefaultEmail,@EmailList,@HomeAddress,@HomeCity,"
                + "@HomeState,@HomeZipCode,@HomeCountry,@HomePhone,@HomeFax,@Mobile,@HomeWebPage,@Company,@OfficeAddress,@OfficeCity,@OfficeState,"
                + "@OfficeZipCode,@OfficeCountry,@JobTitle,@Department,@Office,@OfficePhone,@OfficeFax,@Pager,@IP,@OfficeWebPage,@Spouse,"
                + "@ChildNames,@Gender,@Birthday,@Anniversary,@OtherNotes, @Shared)";

            #region Add Parameters
            Program.Connection.AddParameter("@UserID", UserID);
            Program.Connection.AddParameter("@Category", CategoryID);
            Program.Connection.AddParameter("@SDisplay", DisplayName.ToUpper());
            Program.Connection.AddParameter("@SEmailList", txtlstEmailList.Text.ToUpper());
            Program.Connection.AddParameter("@FirstName", txtFirstName.Text);
            Program.Connection.AddParameter("@MiddleName", txtMiddleName.Text);
            Program.Connection.AddParameter("@LastName", txtLastName.Text);
            Program.Connection.AddParameter("@Display", txtDisplay.Text);
            Program.Connection.AddParameter("@Title", txtTitle.Text);
            Program.Connection.AddParameter("@NickName", txtNickName.Text);
            Program.Connection.AddParameter("@DefaultEmail", DefaultEMail);
            Program.Connection.AddParameter("@EmailList", txtlstEmailList.Text);
            Program.Connection.AddParameter("@HomeAddress", txtHomeStreet.Text);
            Program.Connection.AddParameter("@HomeCity", txtHomeCity.Text);
            Program.Connection.AddParameter("@HomeState", txtHomeState.Text);
            Program.Connection.AddParameter("@HomeZipCode", txtHomeZipCode.Text);
            Program.Connection.AddParameter("@HomeCountry", txtHomeCountry.Text);
            Program.Connection.AddParameter("@HomePhone", txtHomePhone.Text);
            Program.Connection.AddParameter("@HomeFax", txtHomeFax.Text);
            Program.Connection.AddParameter("@Mobile", txtHomeMobile.Text);
            Program.Connection.AddParameter("@HomeWebPage", txtHomeWebPage.Text);
            Program.Connection.AddParameter("@Company", txtCompany.Text);
            Program.Connection.AddParameter("@OfficeAddress", txtBusiStreetAddress.Text);
            Program.Connection.AddParameter("@OfficeCity", txtBusiCity.Text);
            Program.Connection.AddParameter("@OfficeState", txtBusiState.Text);
            Program.Connection.AddParameter("@OfficeZipCode", txtBusiZipCode.Text);
            Program.Connection.AddParameter("@OfficeCountry", txtBusiCountry.Text);
            Program.Connection.AddParameter("@JobTitle", txtJobtitle.Text);
            Program.Connection.AddParameter("@Department", txtDepartment.Text);
            Program.Connection.AddParameter("@Office", txtOffice.Text);
            Program.Connection.AddParameter("@OfficePhone", txtBusiPhone.Text);
            Program.Connection.AddParameter("@OfficeFax", txtBusiFax.Text);
            Program.Connection.AddParameter("@Pager", txtBusiPager.Text);
            Program.Connection.AddParameter("@IP", txtIP.Text);
            Program.Connection.AddParameter("@OfficeWebPage", txtBusiWebPage.Text);
            Program.Connection.AddParameter("@Spouse", txtSpouse.Text);
            Program.Connection.AddParameter("@ChildNames", txtlstChildNamesList.Text);
            Program.Connection.AddParameter("@Gender", txtGender.Text);
            Program.Connection.AddParameter("@Birthday", tmpBirthday);
            Program.Connection.AddParameter("@Anniversary", tmpAnniversary);
            Program.Connection.AddParameter("@OtherNotes", txtNotes.Text);
            Program.Connection.AddParameter("@Shared", Convert.ToInt32(IsContactShared.Checked));
            #endregion

            Program.Connection.ExecuteNonQuery();
            this.Close();
        }

        void Cancel(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Database Functions

        void GetContactDetails()
        {
            Program.Connection.CommandText = "select * from ContactsData where CIdentity=" + ContactId;
            System.Data.DataTable tmpTable = new System.Data.DataTable();
            Program.Connection.FillDataTable(tmpTable, true);
            System.Data.DataRow Row = tmpTable.Rows[0];

            #region Show Data in textbox
            btnDelete.Enabled = btnOk.Enabled = (Row["UserId"].ToString() == UserPolicies.UserID);
            CategoryID = Row["Category"].ToString();
            //txtCategory.SelectedItem = Row["Category"].ToString();
            txtFirstName.Text = Row["FirstName"].ToString();
            txtMiddleName.Text = Row[6].ToString();
            txtLastName.Text = Row[7].ToString();
            txtDisplay.Text = Row[8].ToString();
            txtTitle.Text = Row[9].ToString();
            txtNickName.Text = Row[10].ToString();
            DefaultEMail = Row[11].ToString();
            txtlstEmailList.Text = Row[12].ToString();

            for (int a = 0; a < txtlstEmailList.Lines.Length; a++)
            {
                if (txtlstEmailList.Lines[a] == DefaultEMail)
                {
                    DefaultEMailIndex = a;
                    lstEmailList.Items.Add(DefaultEMail + " (Default E-Mail)");
                }
                else lstEmailList.Items.Add(txtlstEmailList.Lines[a]);
            }
            txtHomeStreet.Text = Row[13].ToString();
            txtHomeCity.Text = Row[14].ToString();
            txtHomeState.Text = Row[15].ToString();
            txtHomeZipCode.Text = Row[16].ToString();
            txtHomeCountry.Text = Row[17].ToString();
            txtHomePhone.Text = Row[18].ToString();
            txtHomeFax.Text = Row[19].ToString();
            txtHomeMobile.Text = Row[20].ToString();
            txtHomeWebPage.Text = Row[21].ToString();
            txtCompany.Text = Row[22].ToString();
            txtBusiStreetAddress.Text = Row[23].ToString();
            txtBusiCity.Text = Row[24].ToString();
            txtBusiState.Text = Row[25].ToString();
            txtBusiZipCode.Text = Row[26].ToString();
            txtBusiCountry.Text = Row[27].ToString();
            txtJobtitle.Text = Row[28].ToString();
            txtDepartment.Text = Row[29].ToString();
            txtOffice.Text = Row[30].ToString();
            txtBusiPhone.Text = Row[31].ToString();
            txtBusiFax.Text = Row[32].ToString();
            txtBusiPager.Text = Row[33].ToString();
            txtIP.Text = Row[34].ToString();
            txtBusiWebPage.Text = Row[35].ToString();
            txtSpouse.Text = Row[36].ToString();
            txtlstChildNamesList.Text = Row[37].ToString();

            for (int b = 0; b < txtlstChildNamesList.Lines.Length; b++)
            {
                lstChildNamesList.Items.Add(txtlstChildNamesList.Lines[b]);
            }

            txtGender.Text = Row[38].ToString();

            if (Row[39].ToString().Trim() == "") txtBirthday.Checked = false;
            else
            {
                txtBirthday.Text = Row[39].ToString();
                txtBirthday.Checked = true;
            }

            if (Row[40].ToString().Trim() == "") txtAnniversary.Checked = false;
            else
            {
                txtAnniversary.Checked = true;
                txtAnniversary.Text = Row[40].ToString();
            }

            txtNotes.Text = Row[41].ToString();
            IsContactShared.Checked = Row[42].ToString() == "1";

            #endregion
        }

        #endregion
    }
}
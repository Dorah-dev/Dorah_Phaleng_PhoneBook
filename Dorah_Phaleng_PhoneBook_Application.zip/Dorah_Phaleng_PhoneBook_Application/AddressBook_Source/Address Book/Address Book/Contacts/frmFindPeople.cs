using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmFindPeople : Form
    {
        string ContactId;
        public int ContFound = 0;
        public frmFindPeople()
        {
            InitializeComponent();
        }

        void FindNow(object sender, EventArgs e) { FindNow(); }

        void ClearAll(object sender, EventArgs e)
        {
            txtName.Text = txtEmail.Text = txtResPhone.Text = txtMobilePhone.Text = txtOffPhone.Text = "";
        }

        void CloseForm(object sender, EventArgs e)
        {
            this.Close();
        }

        void FindNow()
        {
            string Comp = "AND";
            if (CheckWithOne.Checked) Comp = "OR";
            string SNAME = "SDisplay LIKE '%' ", SEMAIL = "", SRPHONE = "", SMOBILE = "", SOPHONE = "";

            if (txtName.Text.Trim() != "") SNAME = "SDisplay LIKE \'%" + Converter.Encrypt(txtName.Text.ToUpper()) + "%\' ";
            if (txtEmail.Text.Trim() != "") SEMAIL = Comp + " SEmailList LIKE \'%" + Converter.Encrypt(txtEmail.Text.ToUpper()) + "%\' ";
            if (txtResPhone.Text.Trim() != "") SRPHONE = Comp + " HomePhone LIKE \'%" + Converter.Encrypt(txtResPhone.Text) + "%\' ";
            if (txtMobilePhone.Text.Trim() != "") SMOBILE = Comp + " Mobile LIKE \'%" + Converter.Encrypt(txtMobilePhone.Text) + "%\' ";
            if (txtOffPhone.Text.Trim() != "") SOPHONE = Comp + " OfficePhone LIKE \'%" + Converter.Encrypt(txtOffPhone.Text) + "%\'";

            string CommandText = null;

            if (UserPolicies.IsAdministrator)
                CommandText = "SELECT CIdentity FROM ContactsData WHERE " + SNAME + SEMAIL + SRPHONE + SMOBILE + SOPHONE;
            else
                CommandText = "SELECT CIdentity FROM ContactsData WHERE (UserID=" + UserPolicies.UserID + ") AND (" + SNAME + SEMAIL + SRPHONE + SMOBILE + SOPHONE + ")";

            Program.Connection.CommandText = CommandText;

            System.Data.DataTable Table = new System.Data.DataTable();

            try
            {
                Program.Connection.FillDataTable(Table, true);
            }
            catch
            {
                MessageBox.Show("Fill at least one detail of the contact to be searched.");
                return;
            }
            string TotalId = "";

            for (int i = 0; i < Table.Rows.Count; i++)// Get data related to user search.
            {
                ContactId = Table.Rows[i][0].ToString(); // Get id of searched data.

                if (ContFound == 0) TotalId = ContactId;
                else TotalId += "," + ContactId;
                ContFound++;
            }

            if (ContFound == 0)
            {
                MessageBox.Show("No Contact found with specified details.", "No Record Found");
                return;
            }
            this.Close();
            Program.Connection.CommandText = "select CIdentity,UserID,Category,Display,DefaultEmail,HomePhone,OfficePhone,Mobile,Shared from ContactsData where CIdentity IN(" + TotalId + ")";
            MessageBox.Show(ContFound.ToString() + " contacts found with specified details.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
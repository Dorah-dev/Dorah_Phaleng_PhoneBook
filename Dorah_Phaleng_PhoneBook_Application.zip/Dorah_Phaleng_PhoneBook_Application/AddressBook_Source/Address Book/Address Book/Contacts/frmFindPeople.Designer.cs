namespace AddressBook
{
    partial class frmFindPeople
    {
        System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.btnFindNow = new System.Windows.Forms.Button();
            this.FindPeople_TabControl = new System.Windows.Forms.TabControl();
            this.PeopleTab = new System.Windows.Forms.TabPage();
            this.CheckWithOne = new System.Windows.Forms.CheckBox();
            this.txtMobilePhone = new System.Windows.Forms.TextBox();
            this.O_Phone_Lable = new System.Windows.Forms.Label();
            this.txtOffPhone = new System.Windows.Forms.TextBox();
            this.txtResPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.Mobile_Label = new System.Windows.Forms.Label();
            this.R_Phone_Label = new System.Windows.Forms.Label();
            this.Email_Label = new System.Windows.Forms.Label();
            this.Name_Label = new System.Windows.Forms.Label();
            this.FindPeople_TabControl.SuspendLayout();
            this.PeopleTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(315, 141);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 21);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.CloseForm);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(315, 60);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(86, 21);
            this.btnClearAll.TabIndex = 9;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.ClearAll);
            // 
            // btnFindNow
            // 
            this.btnFindNow.Location = new System.Drawing.Point(315, 33);
            this.btnFindNow.Name = "btnFindNow";
            this.btnFindNow.Size = new System.Drawing.Size(86, 21);
            this.btnFindNow.TabIndex = 8;
            this.btnFindNow.Text = "Find Now";
            this.btnFindNow.UseVisualStyleBackColor = true;
            this.btnFindNow.Click += new System.EventHandler(this.FindNow);
            // 
            // FindPeople_TabControl
            // 
            this.FindPeople_TabControl.Controls.Add(this.PeopleTab);
            this.FindPeople_TabControl.Location = new System.Drawing.Point(4, 4);
            this.FindPeople_TabControl.Name = "FindPeople_TabControl";
            this.FindPeople_TabControl.SelectedIndex = 0;
            this.FindPeople_TabControl.Size = new System.Drawing.Size(308, 195);
            this.FindPeople_TabControl.TabIndex = 0;
            // 
            // PeopleTab
            // 
            this.PeopleTab.Controls.Add(this.CheckWithOne);
            this.PeopleTab.Controls.Add(this.txtMobilePhone);
            this.PeopleTab.Controls.Add(this.O_Phone_Lable);
            this.PeopleTab.Controls.Add(this.txtOffPhone);
            this.PeopleTab.Controls.Add(this.txtResPhone);
            this.PeopleTab.Controls.Add(this.txtEmail);
            this.PeopleTab.Controls.Add(this.txtName);
            this.PeopleTab.Controls.Add(this.Mobile_Label);
            this.PeopleTab.Controls.Add(this.R_Phone_Label);
            this.PeopleTab.Controls.Add(this.Email_Label);
            this.PeopleTab.Controls.Add(this.Name_Label);
            this.PeopleTab.Location = new System.Drawing.Point(4, 22);
            this.PeopleTab.Name = "PeopleTab";
            this.PeopleTab.Padding = new System.Windows.Forms.Padding(3);
            this.PeopleTab.Size = new System.Drawing.Size(300, 169);
            this.PeopleTab.TabIndex = 1;
            this.PeopleTab.Text = "People";
            this.PeopleTab.UseVisualStyleBackColor = true;
            // 
            // CheckWithOne
            // 
            this.CheckWithOne.AutoSize = true;
            this.CheckWithOne.Location = new System.Drawing.Point(5, 145);
            this.CheckWithOne.Name = "CheckWithOne";
            this.CheckWithOne.Size = new System.Drawing.Size(284, 17);
            this.CheckWithOne.TabIndex = 7;
            this.CheckWithOne.Text = "Show even if any one of the above condition matches.";
            this.CheckWithOne.UseVisualStyleBackColor = true;
            // 
            // txtMobilePhone
            // 
            this.txtMobilePhone.Location = new System.Drawing.Point(66, 89);
            this.txtMobilePhone.Name = "txtMobilePhone";
            this.txtMobilePhone.Size = new System.Drawing.Size(227, 20);
            this.txtMobilePhone.TabIndex = 4;
            // 
            // O_Phone_Lable
            // 
            this.O_Phone_Lable.AutoSize = true;
            this.O_Phone_Lable.Location = new System.Drawing.Point(2, 119);
            this.O_Phone_Lable.Name = "O_Phone_Lable";
            this.O_Phone_Lable.Size = new System.Drawing.Size(58, 13);
            this.O_Phone_Lable.TabIndex = 0;
            this.O_Phone_Lable.Text = "Off Phone:";
            // 
            // txtOffPhone
            // 
            this.txtOffPhone.Location = new System.Drawing.Point(66, 116);
            this.txtOffPhone.Name = "txtOffPhone";
            this.txtOffPhone.Size = new System.Drawing.Size(227, 20);
            this.txtOffPhone.TabIndex = 5;
            // 
            // txtResPhone
            // 
            this.txtResPhone.Location = new System.Drawing.Point(66, 62);
            this.txtResPhone.Name = "txtResPhone";
            this.txtResPhone.Size = new System.Drawing.Size(227, 20);
            this.txtResPhone.TabIndex = 3;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(66, 35);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(227, 20);
            this.txtEmail.TabIndex = 2;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(66, 8);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(227, 20);
            this.txtName.TabIndex = 1;
            // 
            // Mobile_Label
            // 
            this.Mobile_Label.AutoSize = true;
            this.Mobile_Label.Location = new System.Drawing.Point(2, 92);
            this.Mobile_Label.Name = "Mobile_Label";
            this.Mobile_Label.Size = new System.Drawing.Size(44, 13);
            this.Mobile_Label.TabIndex = 0;
            this.Mobile_Label.Text = "Mobile :";
            // 
            // R_Phone_Label
            // 
            this.R_Phone_Label.AutoSize = true;
            this.R_Phone_Label.Location = new System.Drawing.Point(2, 65);
            this.R_Phone_Label.Name = "R_Phone_Label";
            this.R_Phone_Label.Size = new System.Drawing.Size(63, 13);
            this.R_Phone_Label.TabIndex = 0;
            this.R_Phone_Label.Text = "Res Phone:";
            // 
            // Email_Label
            // 
            this.Email_Label.AutoSize = true;
            this.Email_Label.Location = new System.Drawing.Point(2, 38);
            this.Email_Label.Name = "Email_Label";
            this.Email_Label.Size = new System.Drawing.Size(38, 13);
            this.Email_Label.TabIndex = 0;
            this.Email_Label.Text = "E-mail:";
            // 
            // Name_Label
            // 
            this.Name_Label.AutoSize = true;
            this.Name_Label.Location = new System.Drawing.Point(2, 11);
            this.Name_Label.Name = "Name_Label";
            this.Name_Label.Size = new System.Drawing.Size(38, 13);
            this.Name_Label.TabIndex = 0;
            this.Name_Label.Text = "Name:";
            // 
            // frmFindPeople
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(406, 202);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.btnFindNow);
            this.Controls.Add(this.FindPeople_TabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFindPeople";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Find People";
            this.FindPeople_TabControl.ResumeLayout(false);
            this.PeopleTab.ResumeLayout(false);
            this.PeopleTab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        System.Windows.Forms.Button btnClose;
        System.Windows.Forms.Button btnClearAll;
        System.Windows.Forms.Button btnFindNow;
        System.Windows.Forms.TabControl FindPeople_TabControl;
        System.Windows.Forms.TabPage PeopleTab;
        System.Windows.Forms.TextBox txtOffPhone;
        System.Windows.Forms.TextBox txtResPhone;
        System.Windows.Forms.TextBox txtEmail;
        System.Windows.Forms.TextBox txtName;
        System.Windows.Forms.Label Mobile_Label;
        System.Windows.Forms.Label R_Phone_Label;
        System.Windows.Forms.Label Email_Label;
        System.Windows.Forms.Label Name_Label;
        System.Windows.Forms.TextBox txtMobilePhone;
        System.Windows.Forms.Label O_Phone_Lable;
        System.Windows.Forms.CheckBox CheckWithOne;
    }
}
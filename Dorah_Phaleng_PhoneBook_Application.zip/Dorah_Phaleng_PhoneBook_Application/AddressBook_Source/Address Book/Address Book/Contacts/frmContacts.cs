#region Import Namespace
using System;
using System.Data;
using System.Windows.Forms;
#endregion

namespace AddressBook
{
    public partial class frmContacts : Form
    {
        #region Declarations

        DataTable dtContactDetails;
        frmLogin Login;
        bool NodeEditing = false;
        bool SelectedContactShared = false;
        ListBox SelectedCategory = new ListBox();
        ListBox SelectedContacts = new ListBox();
        Timer Updater = new Timer();
        Timer SignoutTimer = new Timer();
        ListBox CID = new ListBox();

        public frmContacts()
        {
            InitializeComponent();
            UpdateCategory();            
            dtContactDetails = new DataTable("ContactsData");
            //Microsoft.Win32.SystemEvents.SessionEnded += new Microsoft.Win32.SessionEndedEventHandler(ShutDown_Started);
            Program.Connection.ConnectionDistructor.Elapsed += new System.Timers.ElapsedEventHandler(CloseDBConnection);
            DataConnection.Status.TextChanged += new EventHandler(ConnectionStateChanged);

            Updater.Tick += new EventHandler(Updater_Tick);
            SignoutTimer.Interval = 300000;
            SignoutTimer.Tick += new EventHandler(SignOut_this);
            SignoutTimer.Enabled = false;
        }

        void Updater_Tick(object sender, EventArgs e)
        {
            UpdateCategory();
            Updater.Enabled = false;
            Updater.Stop();
        }

        void ConnectionStateChanged(object sender, EventArgs e)
        {
            lblConnectionStatus.Text = "Connected  -  " + UserPolicies.UserName;
        }

        void CloseDBConnection(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                DataConnection.Status.Text = "";
                lblConnectionStatus.Text = "Disconnected  -  " + UserPolicies.UserName;
                Program.Connection.Close();
            }
            catch { }
            Program.Connection.ConnectionDistructor.Enabled = false;
        }

        void LoadDatas(object sender, EventArgs e)
        {
            string CommandText = "select CIdentity, UserID, Category, Display, DefaultEmail, HomePhone, OfficePhone, Mobile, Shared from ContactsData";
            if (!UserPolicies.IsAdministrator) CommandText += " where Shared='" + Converter.Encrypt("1") + "' or UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";
            Program.Connection.CommandText = CommandText;
            Program.Connection.FillDataTable(dtContactDetails, true);
            DisplayReminderDetails();
        }

        void UpdateCategory()
        {
            Program.Connection.CommandText = "select * from ContactsCategorys";
            System.Data.DataTable Table = new System.Data.DataTable();
            Program.Connection.FillDataTable(Table, true);

            txtCategory.Nodes.Clear();
            int a = txtCategory.Nodes.Count;
            txtCategory.Nodes.Add("CA", "Categorized");
            txtCategory.Nodes.Add("UC", "Uncategorized");

            for (int i = 0; i < Table.Rows.Count; i++)
            {
                TreeNode Node = txtCategory.Nodes.Find(Table.Rows[i][2].ToString(), true)[0];
                if (Node == null) continue;
                Node.Nodes.Add(Table.Rows[i][0].ToString(), Table.Rows[i][1].ToString());

                Table.Rows.RemoveAt(i);
                i--;
            }
        }
        #endregion

        #region Options

        void NewContact_Click(object sender, EventArgs e)
        {
            frmNewContact AddNewContact = new frmNewContact(true, null, null);
            AddNewContact.ShowDialog();
            LoadDatas(sender, e);
            ShowUserRelatedContacts(sender, e);
        }

        void EditContact_Click(object sender, EventArgs e)
        {
            try
            {
                if (ContactDetails.SelectedItems.Count > 1) { MessageBox.Show("More than one contact cannot be edited at a time.", "Invalid Action"); return; }
                frmNewContact EditContact = new frmNewContact(false, CID.Items[ContactDetails.SelectedIndices[0]].ToString(), null);
                EditContact.ShowDialog();
                LoadDatas(sender, e);
                ShowUserRelatedContacts(sender, e);
            }
            catch { MessageBox.Show("First select the contact to be edited.", "Edit Contact Failed"); }
        }

        void FindPeople_Click(object sender, EventArgs e)
        {
            frmFindPeople FindPeople = new frmFindPeople();
            FindPeople.ShowDialog();
            if (FindPeople.ContFound != 0)
            {
                Program.Connection.FillDataTable(dtContactDetails, true);
                DisplayContactDetails(false, null);
            }
        }

        void DeleteContact_Click(object sender, EventArgs e)
        {
            try
            {
                string tempCID = "";
                DialogResult DR = DialogResult.No;
                if (ContactDetails.SelectedItems.Count > 1) DR = MessageBox.Show("You had selected multiple contacts. Are you sure to delete all the selected contacts?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                else DR = MessageBox.Show("Are you sure to delete the selected contact permenantly?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.No) return;

                foreach (ListViewItem Item in ContactDetails.SelectedItems)
                {
                    tempCID += ", " + CID.Items[Item.Index];
                }

                Program.Connection.CommandText = "delete from ContactsData where CIdentity in (" + tempCID.Remove(0, 2) + ") and UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";
                MessageBox.Show(Program.Connection.ExecuteNonQuery().ToString() + " of " + ContactDetails.SelectedItems.Count.ToString() + " contact had been deleted.");
                LoadDatas(sender, e);
                ShowUserRelatedContacts(sender, e);
            }
            catch { }
        }

        void SignOut_Click(object sender, EventArgs e)
        {
            if (!UserPolicies.IsLoggedIn) return;
            DialogResult DR = MessageBox.Show("Are you sure to signout from the appliation?", "Signing Out", MessageBoxButtons.YesNo);
            if (DR == DialogResult.No) return;
            SignOut_this(sender, e);
        }

        void SignOut_this(object sender, EventArgs e)
        {
            UserPolicies.IsLoggedIn = false;
            ContactDetails.Items.Clear();
            UserList.Nodes.Clear();
            dtContactDetails = new DataTable();
            Program.Connection.CommandText = "update ContactsUserAccount set Status='' where UserID=" + UserPolicies.UserID;
            Program.Connection.ExecuteNonQuery();
            UserPolicies.IsAdministrator = false;
            UserPolicies.UserID = null;
            UserPolicies.UserName = null;
            panelReminder.Visible = itmViewRemainder.Checked = false;
            Hide();

            SignoutTimer.Enabled = false;
            SignoutTimer.Stop();

            TrayIcon.ShowBalloonTip(3000, "Information", "You had been signed out from the application", ToolTipIcon.Info);

            //Microsoft.Win32.SystemEvents.SessionEnded -= ShutDown_Started;
        }

        void TransferData(object sender, EventArgs e)
        {
            new frmBackup().Show();
        }

        void PrintContacts(object sender, EventArgs e)
        {
            new frmPrinter().ShowDialog();
        }

        #region Remainder Menu

        void AddReminder(object sender, EventArgs e)
        {
            frmAddReminder AddRemainder = new frmAddReminder();
            AddRemainder.ShowDialog();
        }

        void DeleteReminder(object sender, EventArgs e)
        {
            if (ReminderDetails.SelectedItems.Count == 0) return;
            if (MessageBox.Show("Are you sure to delete the selected event?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.No) return;
            Program.Connection.CommandText = "delete from ContactsReminder where ReminderID=" + ReminderDetails.SelectedItems[0].SubItems[0].Text;
            MessageBox.Show(Program.Connection.ExecuteNonQuery().ToString() + " entry had been removed.", "Entry Removed");
            ReminderDetails.Items.RemoveAt(ReminderDetails.SelectedIndices[0]);
        }

        #endregion

        #endregion

        #region View

        void ShowHideStatus_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = itmStatusBar.Checked;
        }

        void ViewAsSmallIcons(object sender, EventArgs e)
        {
            itmSmallIcons.Checked = true;
            itmTile.Checked = itmList.Checked = itmDetails.Checked = false;
            ContactDetails.View = View.SmallIcon;
        }

        void ViewAsTile(object sender, EventArgs e)
        {
            itmTile.Checked = true;
            itmSmallIcons.Checked = itmList.Checked = itmDetails.Checked = false;
            ContactDetails.View = View.Tile;
        }

        void ViewAsList(object sender, EventArgs e)
        {
            itmList.Checked = true;
            itmSmallIcons.Checked = itmTile.Checked = itmDetails.Checked = false;
            ContactDetails.View = View.List;
        }

        void ViewAsDetails(object sender, EventArgs e)
        {
            itmDetails.Checked = true;
            itmSmallIcons.Checked = itmTile.Checked = itmList.Checked = false;
            ContactDetails.View = View.Details;
        }

        void ViewRemainder(object sender, EventArgs e)
        {
            itmViewRemainder.Checked = !itmViewRemainder.Checked;
            panelReminder.Visible = itmViewRemainder.Checked;
            if (panelReminder.Visible) DisplayReminderDetails();
        }

        void ShowHideUsersPanel(object sender, EventArgs e)
        {
            itmUserPanel.Checked = !itmUserPanel.Checked;
            if ((panelLeft.Visible = itmUserPanel.Checked)) ShowUserLists();
        }

        void RefreshGrid(object sender, EventArgs e)
        {
            LoadDatas(sender, e);
            if (itmViewRemainder.Checked) DisplayReminderDetails();
        }

        #endregion

        #region Tools

        void UserAccount_Clicked(object sender, EventArgs e)
        {
            if (!UserPolicies.IsAdministrator) { MessageBox.Show("You do not have sufficient rights to view or edit User Account.", "Access Denied"); return; }
            frmUserAccount UserAccount = new frmUserAccount();
            UserAccount.ShowDialog();
        }

        void UpdatePassword(object sender, EventArgs e)
        {
            frmChangePassword ChangePassword = new frmChangePassword();
            ChangePassword.ShowDialog();
        }

        void UpdateSettings(object sender, EventArgs e)
        {
            if (!UserPolicies.IsAdministrator) { MessageBox.Show("You do not have sufficient rights to view or change the settings.", "Access Denied"); return; }
            frmSettings UpdateSettings = new frmSettings();
            UpdateSettings.ShowDialog();
        }
        #endregion

        #region Help
        void AboutAddressBook(object sender, EventArgs e)
        {
            frmAboutAddressBook AboutAddressBook = new frmAboutAddressBook();
            AboutAddressBook.ShowDialog();
        }
        #endregion

        #region Display Functions
        void DisplayContactDetails(bool Shared, string UserID)
        {
            CID.Items.Clear();            
            ContactDetails.Items.Clear();
            if (Shared)
                for (int i = 0; i < dtContactDetails.Rows.Count; i++)
                {
                    if (dtContactDetails.Rows[i]["Shared"].ToString() == "0") continue;
                    if (UserID != null && dtContactDetails.Rows[i]["UserID"].ToString() != UserID) continue;
                    if (SelectedCategory.Items.IndexOf(dtContactDetails.Rows[i]["Category"].ToString()) == -1) continue;
                    CID.Items.Add(dtContactDetails.Rows[i]["CIdentity"]);
                    ContactDetails.Items.Add(new ListViewItem(new string[] { dtContactDetails.Rows[i]["Display"].ToString(), dtContactDetails.Rows[i]["Mobile"].ToString(), dtContactDetails.Rows[i]["OfficePhone"].ToString(), dtContactDetails.Rows[i]["HomePhone"].ToString(), dtContactDetails.Rows[i]["DefaultEmail"].ToString() }));
                }
            else
                for (int i = 0; i < dtContactDetails.Rows.Count; i++)
                {
                    if (UserID != null && dtContactDetails.Rows[i]["UserID"].ToString() != UserID) continue;
                    if (SelectedCategory.Items.IndexOf(dtContactDetails.Rows[i]["Category"].ToString()) == -1) continue;
                    CID.Items.Add(dtContactDetails.Rows[i]["CIdentity"]);
                    ContactDetails.Items.Add(new ListViewItem(new string[] { dtContactDetails.Rows[i]["Display"].ToString(), dtContactDetails.Rows[i]["Mobile"].ToString(), dtContactDetails.Rows[i]["OfficePhone"].ToString(), dtContactDetails.Rows[i]["HomePhone"].ToString(), dtContactDetails.Rows[i]["DefaultEmail"].ToString() }));
                }
        }

        void DisplayReminderDetails()
        {
            ReminderDetails.Items.Clear();
            Program.Connection.CommandText = "select * from ContactsReminder where UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";
            DataTable Table = new DataTable();
            Program.Connection.FillDataTable(Table, true);
            if (Table.Rows.Count > 0) panelReminder.Visible = itmViewRemainder.Checked = true;
            foreach (DataRow Row in Table.Rows)
            {
                ReminderDetails.Items.Add(new ListViewItem(new string[] { Row["ReminderID"].ToString(), Row["ReminderName"].ToString(), Row["RemindOn"].ToString(), Row["Descripption"].ToString() }));
            }
        }
        #endregion

        #region Tray Context Menu Methods

        void ShowLoginForm(object sender, EventArgs e)
        {
            if (Login != null || UserPolicies.IsLoggedIn) return;
            Login = new frmLogin();
            Login.ShowDialog();
            if (UserPolicies.IsLoggedIn)
            {
                Show();
                lblConnectionStatus.Text = "Connected  -  " + UserPolicies.UserName;
                ShowUserLists();
                LoadDatas(sender, e);
                FormClosing += new FormClosingEventHandler(frmContacts_FormClosing);
                if (itmViewRemainder.Checked) DisplayReminderDetails();
            }
            Login = null;
        }

        void ExitApplication(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to exit AddressBook?", "Exiting..", MessageBoxButtons.YesNo) == DialogResult.No) return;
            FormClosing -= new FormClosingEventHandler(frmContacts_FormClosing);
            if (UserPolicies.IsLoggedIn)
            {
                Program.Connection.CommandText = "update ContactsUserAccount set Status='' where UserID=" + UserPolicies.UserID;
                Program.Connection.ExecuteNonQuery();
            }
            this.Close();
            Application.Exit();
        }

        void frmContacts_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
            SignoutTimer.Enabled = true;
            SignoutTimer.Start();
            TrayIcon.ShowBalloonTip(3000, "Information", "You will be signed out from the application within 5 minutes.", ToolTipIcon.Info);
            FormClosing -= frmContacts_FormClosing;
        }

        void Shown_Raised(object sender, EventArgs e)
        {
            Hide();
            Shown -= Shown_Raised;
            Opacity = 10;
        }

        void ShowContacts(object sender, EventArgs e)
        {
            if (UserPolicies.IsLoggedIn)
            { Show();
            SignoutTimer.Enabled = false;
            SignoutTimer.Stop();
                FormClosing +=new FormClosingEventHandler(frmContacts_FormClosing);
            }
            else { ShowLoginForm(sender, e); }
        }

        #endregion

        #region Miscellaneous

        void ShowUserLists()
        {
            Program.Connection.CommandText = "select * from ContactsUserAccount";
            DataTable Table = new DataTable();
            Program.Connection.FillDataTable(Table, false);

            // Decrypt the datas leaving only user id
            for (int i = 1; i < Table.Columns.Count; i++) for (int j = 0; j < Table.Rows.Count; j++)
                    Table.Rows[j][i] = Converter.Decrypt(Table.Rows[j][i].ToString());

            UserList.Nodes.Clear();
            TreeNode[] SharedChild = new TreeNode[Table.Rows.Count];
            TreeNode[] MainChild = new TreeNode[Table.Rows.Count];

            for (int i = 0; i < Table.Rows.Count; i++)
            {
                SharedChild[i] = new TreeNode(Table.Rows[i][2].ToString());
                SharedChild[i].Name = Table.Rows[i][0].ToString();
                string LoggedIn = Table.Rows[i][8].ToString();
                if (LoggedIn.Trim() != "") LoggedIn = "  - " + LoggedIn;
                MainChild[i] = new TreeNode(Table.Rows[i][2].ToString() + LoggedIn);
                MainChild[i].Name = Table.Rows[i][0].ToString();
            }

            UserList.Nodes.Add(new TreeNode("Shared Contacts", SharedChild));

            if (UserPolicies.IsAdministrator) UserList.Nodes.Add(new TreeNode("Main Contacts", MainChild));
            else UserList.Nodes.Add("Main Contacts");
        }

        void ShowUserRelatedContacts(object sender, EventArgs e)
        {
            ShowUserRelatedContacts();
        }

        void ShowUserRelatedContacts()
        {
            try
            {
                string SelectedId = null;
                if (UserList.SelectedNode.Text != "Main Contacts" && UserList.SelectedNode.Text != "Shared Contacts") SelectedId = UserList.SelectedNode.Name;
                if (UserList.SelectedNode.Text == "Main Contacts" && !UserPolicies.IsAdministrator) SelectedId = UserPolicies.UserID;
                
                try
                {
                    SelectedContactShared = (UserList.SelectedNode.Text == "Shared Contacts") || (UserList.SelectedNode.Parent.Text == "Shared Contacts");
                }
                catch { SelectedContactShared = UserList.SelectedNode.Text == "Shared Contacts"; }

                DisplayContactDetails(SelectedContactShared, SelectedId);
            }
            catch { }
        }

        void MakeCall(object sender, EventArgs e)
        {
            frmDialer Dialer = new frmDialer(CID.Items[ContactDetails.SelectedIndices[0]].ToString());
            Dialer.ShowDialog();
        }

        void ShareContacts(object sender, EventArgs e)
        {
            try
            {
                string tempCID = CID.Items[ContactDetails.SelectedIndices[0]].ToString();
                foreach (DataRow Row in dtContactDetails.Rows)
                {
                    if (Row[0].ToString() != tempCID) continue;
                    if (Row[1].ToString() == UserPolicies.UserID) break;
                    else { MessageBox.Show("You do not have sufficient rights to perform this action on contacts of other users.", "Access Denied"); return; }
                }
                if (SelectedContactShared) { if (MessageBox.Show("Are you sure to un share the selected contact with other users.", "Confirm Sharing", MessageBoxButtons.YesNo) == DialogResult.No) return; }
                else if (MessageBox.Show("Are you sure to share the selected contact.", "Confirm Sharing", MessageBoxButtons.YesNo) == DialogResult.No) return;

                Program.Connection.CommandText = "update ContactsData set Shared='" + Converter.Encrypt(Convert.ToString(Convert.ToInt32(!SelectedContactShared))) + "' where CIdentity=" + tempCID;
                Program.Connection.ExecuteNonQuery();
                RefreshGrid(sender, e);
            }
            catch (Exception Ex) { MessageBox.Show("Could not perform this action on selected contact.\n\nError Message:\n" + Ex.Message, "Error Sharing"); }
        }

        void FastSearch(object sender, EventArgs e)
        {
            foreach (ListViewItem Item in ContactDetails.Items)
            {
                if (Item.SubItems[0].Text.ToLower().StartsWith(txtFastSearch.Text.Trim().ToLower())) Item.Selected = true;
                else Item.Selected = false;
            }
        }

        void ShutDown_Started(object sender, Microsoft.Win32.SessionEndedEventArgs e)
        {
            Program.Connection.CommandText = "update ContactsUserAccount set Status='' where UserID=" + UserPolicies.UserID;
            Program.Connection.ExecuteNonQuery();
            Microsoft.Win32.SystemEvents.SessionEnded -= ShutDown_Started;
        }

        void ContactsContextShown(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (SelectedContactShared) shareContactToolStripMenuItem.Text = "Un Share Contact";
            else shareContactToolStripMenuItem.Text = "Share Contact";
        }

        void Help_Requested(object sender, EventArgs e)
        {
            MessageBox.Show("The help file AddressBook.cpl could not be found.", "Address Book");
        }
        #endregion

        #region Category Editing Methods
        void AddCategory_Clicked(object sender, EventArgs e)
        {
            if (txtCategory.SelectedNode == null) return;
            if (txtCategory.SelectedNode.Name == "UC") { MessageBox.Show("You cannot add new Category in this category.", "Invalid Action"); return; }

            TreeNode ParentNode = txtCategory.SelectedNode;
            TreeNode NewNode = new TreeNode();
            NewNode.Name = "NewCate";
            NewNode.Text = "New Category";
            ParentNode.Nodes.Add(NewNode);
            EditableNode = NewNode;
            NodeEditing = false;
        }

        TreeNode EditableNode
        {
            set
            {
                if (value == null) return;
                if (value.Parent != null)
                {
                    value.TreeView.SelectedNode = value;
                    value.TreeView.LabelEdit = true;
                    if (!value.IsEditing)
                    {
                        value.BeginEdit();
                    }
                }
                else MessageBox.Show("Invalid selection for editing.", "Invalid Action");
            }
        }

        bool CheckNodeUnique(TreeNode Node, string NodeText)
        {
            foreach (TreeNode N in Node.Parent.Nodes) if (N.Text.ToLower() == NodeText && Node != N) return true;
            return false;
        }

        void NameChanged(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Label == null)
            {
                if(NodeEditing) return;
                if (!e.Node.IsEditing) { txtCategory.LabelEdit = true; e.Node.BeginEdit(); return; }
            }

            if(CheckNodeUnique(e.Node, e.Label.ToLower()))
            {
                e.CancelEdit = true;
                MessageBox.Show("Their is already a category with same name.", "Invalid Name");
                txtCategory.LabelEdit = true;
                e.Node.BeginEdit();
                return;
            }
            
            if (e.Label.Length > 0)
                if (e.Label.IndexOfAny(new char[] { '\\' }) == -1) { e.Node.EndEdit(false); e.Node.TreeView.LabelEdit = false; e.Node.Text = e.Label; UpdateNodes(e.Node); }
                else MessageBox.Show("A category name cannot contain '\\'", "Invalid Name");
            else
            {
                e.CancelEdit = true;
                MessageBox.Show("A category name cannot be blank.", "Invalid Name");
                e.Node.BeginEdit();
            }
        }

        void UpdateNodes(TreeNode Node)
        {
            if (NodeEditing)
                Program.Connection.CommandText = "update ContactsCategorys set CategoryName='" + Converter.Encrypt(Node.Text) + "' where CategoryID=" + Node.Name;
            else Program.Connection.CommandText = "insert into ContactsCategorys(CategoryName, CategoryLocation) values('" + Converter.Encrypt(Node.Text) + "', '" + Converter.Encrypt(Node.Parent.Name) + "')";

            Program.Connection.ExecuteNonQuery();
            Updater.Interval = 800;
            Updater.Enabled = false;
            Updater.Start();
        }

        void EditCategory_Click(object sender, EventArgs e)
        {
            if (txtCategory.SelectedNode.Name == "UC" || txtCategory.SelectedNode.Name == "CA") { MessageBox.Show("You cannot edit this category.", "Invalid Action"); return; }

            NodeEditing = true;
            EditableNode = txtCategory.SelectedNode;
        }

        void txtCategory_DoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (txtCategory.SelectedNode == null) return;
            SelectedCategory.Items.Clear();
            if (itmShowAllContacts.Checked) GetNodeNames(txtCategory.SelectedNode);
            else SelectedCategory.Items.Add(txtCategory.SelectedNode.Name);
            ShowUserRelatedContacts();
        }

        void GetNodeNames(TreeNode Node)
        {            
            SelectedCategory.Items.Add(Node.Name);

            foreach (TreeNode N in Node.Nodes)
            {
                GetNodeNames(N);
            }
        }

        void NewContactByCategory(object sender, EventArgs e)
        {
            new frmNewContact(true, null, txtCategory.SelectedNode.Name).ShowDialog();
            LoadDatas(sender, e);
            ShowUserRelatedContacts(sender, e);
        }

        void ShowAllContacts_Clicked(object sender, EventArgs e)
        {
            itmShowAllContacts.Checked = !itmShowAllContacts.Checked;
        }

        void CategoryContext_Showing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            categoryContext.Hide();
        }

        #endregion

        #region Transfer Contact
        void CutContacts_Clicked(object sender, EventArgs e)
        {
            SelectedContacts.Items.Clear();
            foreach (ListViewItem Item in ContactDetails.SelectedItems) SelectedContacts.Items.Add(CID.Items[Item.Index]);
        }

        void PasteContact_Clicked(object sender, EventArgs e)
        {
            try
            {
                string IDS = "";
                foreach (object Item in SelectedContacts.Items) IDS += ", " + Item.ToString();
                Program.Connection.CommandText = "update ContactsData set Category='" + Converter.Encrypt(txtCategory.SelectedNode.Name) + "' where CIdentity in (" + IDS.Remove(0, 2) + ") and UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";
                if (MessageBox.Show("Are you sure to move selected " + SelectedContacts.Items.Count.ToString() + " contacts to the category " + txtCategory.SelectedNode.FullPath, "Confirm Move", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) return;
                MessageBox.Show(Program.Connection.ExecuteNonQuery().ToString() + " of " + SelectedContacts.Items.Count.ToString() + " contacts moved.", "Address Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SelectedContacts.Items.Clear();
                LoadDatas(sender, e);
            }
            catch (ArgumentOutOfRangeException) { MessageBox.Show("No Contacts had been selected to paste here."); }
            catch (Exception Ex) { MessageBox.Show("Due to some problems the selected operations cannot be performed.\n\nError Message:\n" + Ex.Message, "Unknown Error"); }
        }

        void RemoveCategory_Click(object sender, EventArgs e)
        {
            SelectedCategory.Items.Clear();
            DialogResult DR = DialogResult.No;
            if (txtCategory.SelectedNode.Name == "CA" || txtCategory.SelectedNode.Name == "UC") { MessageBox.Show("You cannot remove this items. You can remove subcategories under these category.", "Invalid Selection"); return; }
            if (txtCategory.SelectedNode.Nodes.Count > 0) DR = MessageBox.Show("Are you sure to delete selected category and all its subcategories?", "Address Book", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            else DR = MessageBox.Show("Are you sure to delete selected category?", "Address Book", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (DR == DialogResult.No) return;

            GetNodeNames(txtCategory.SelectedNode);

            string IDS = "";
            foreach (object Item in SelectedCategory.Items) IDS += ", " + Item.ToString();
            Program.Connection.CommandText = "delete from ContactsCategorys where CategoryID in (" + IDS.Remove(0, 2) + ")";
            MessageBox.Show(Program.Connection.ExecuteNonQuery() + " categories had been removed.", "Address Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Updater.Enabled = true;
            Updater.Start();

            IDS = "";
            foreach (object Item in SelectedCategory.Items) IDS += ", '" + Converter.Encrypt(Item.ToString()) + "'";
            Program.Connection.CommandText = "update ContactsData set Category='" + Converter.Encrypt("UC") + "' where Category in (" + IDS.Remove(0, 2) + ")";
            MessageBox.Show(Program.Connection.ExecuteNonQuery() + " contacts from those category had been moved to Uncategorized List.");
            SelectedCategory.Items.Clear();
        }

        #endregion
    }
}
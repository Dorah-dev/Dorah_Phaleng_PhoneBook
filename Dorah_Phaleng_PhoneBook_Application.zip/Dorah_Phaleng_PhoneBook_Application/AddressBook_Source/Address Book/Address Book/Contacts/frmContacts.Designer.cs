namespace AddressBook
{
    partial class frmContacts
    {
        System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContacts));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.menuOptions = new System.Windows.Forms.ToolStripMenuItem();
            this.itmNewContact = new System.Windows.Forms.ToolStripMenuItem();
            this.itmViewEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.findPeopleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.itmTransferData = new System.Windows.Forms.ToolStripMenuItem();
            this.printContactsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.reminderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itmAddEvent = new System.Windows.Forms.ToolStripMenuItem();
            this.itmDeleteEvent = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.signOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.itmStatusBar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.itmSmallIcons = new System.Windows.Forms.ToolStripMenuItem();
            this.itmTile = new System.Windows.Forms.ToolStripMenuItem();
            this.itmList = new System.Windows.Forms.ToolStripMenuItem();
            this.itmDetails = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.itmViewRemainder = new System.Windows.Forms.ToolStripMenuItem();
            this.itmUserPanel = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.itmRefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.userAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.itmSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lblConnectionStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.ToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.trayContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.itmContacts = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.itmLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.itmLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.itmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TrayIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.panelLeft = new System.Windows.Forms.Panel();
            this.UserList = new System.Windows.Forms.TreeView();
            this.ImageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txtCategory = new System.Windows.Forms.TreeView();
            this.categoryContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.itmShowAllContacts = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnHeader = new System.Windows.Forms.Label();
            this.panelDock = new System.Windows.Forms.Panel();
            this.ContactDetails = new System.Windows.Forms.ListView();
            this.FulLastName = new System.Windows.Forms.ColumnHeader();
            this.Mobile = new System.Windows.Forms.ColumnHeader();
            this.colOfficePhone = new System.Windows.Forms.ColumnHeader();
            this.HomePhone = new System.Windows.Forms.ColumnHeader();
            this.DefaultEmail = new System.Windows.Forms.ColumnHeader();
            this.ContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteContactToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.actionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.callToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shareContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelReminder = new System.Windows.Forms.Panel();
            this.ReminderDetails = new System.Windows.Forms.ListView();
            this.colID = new System.Windows.Forms.ColumnHeader();
            this.colName = new System.Windows.Forms.ColumnHeader();
            this.colDate = new System.Windows.Forms.ColumnHeader();
            this.colDescription = new System.Windows.Forms.ColumnHeader();
            this.lblReminderHeader = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtFastSearch = new System.Windows.Forms.TextBox();
            this.lblSearchName = new System.Windows.Forms.Label();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.trayContextMenu.SuspendLayout();
            this.panelLeft.SuspendLayout();
            this.categoryContext.SuspendLayout();
            this.panelDock.SuspendLayout();
            this.ContextMenu.SuspendLayout();
            this.panelReminder.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuOptions,
            this.viewMenu,
            this.toolsMenu,
            this.helpMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(857, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // menuOptions
            // 
            this.menuOptions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmNewContact,
            this.itmViewEdit,
            this.findPeopleToolStripMenuItem,
            this.deleteContactToolStripMenuItem,
            this.toolStripSeparator3,
            this.itmTransferData,
            this.printContactsToolStripMenuItem,
            this.toolStripSeparator5,
            this.reminderToolStripMenuItem,
            this.toolStripSeparator7,
            this.signOutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuOptions.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.menuOptions.Name = "menuOptions";
            this.menuOptions.Size = new System.Drawing.Size(56, 20);
            this.menuOptions.Text = "&Options";
            // 
            // itmNewContact
            // 
            this.itmNewContact.Image = ((System.Drawing.Image)(resources.GetObject("itmNewContact.Image")));
            this.itmNewContact.ImageTransparentColor = System.Drawing.Color.Black;
            this.itmNewContact.Name = "itmNewContact";
            this.itmNewContact.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.itmNewContact.Size = new System.Drawing.Size(186, 22);
            this.itmNewContact.Text = "&New Contact";
            this.itmNewContact.Click += new System.EventHandler(this.NewContact_Click);
            // 
            // itmViewEdit
            // 
            this.itmViewEdit.Image = ((System.Drawing.Image)(resources.GetObject("itmViewEdit.Image")));
            this.itmViewEdit.ImageTransparentColor = System.Drawing.Color.Black;
            this.itmViewEdit.Name = "itmViewEdit";
            this.itmViewEdit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.itmViewEdit.Size = new System.Drawing.Size(186, 22);
            this.itmViewEdit.Text = "&Edit Contact";
            this.itmViewEdit.Click += new System.EventHandler(this.EditContact_Click);
            // 
            // findPeopleToolStripMenuItem
            // 
            this.findPeopleToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("findPeopleToolStripMenuItem.Image")));
            this.findPeopleToolStripMenuItem.Name = "findPeopleToolStripMenuItem";
            this.findPeopleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.findPeopleToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.findPeopleToolStripMenuItem.Text = "Find People";
            this.findPeopleToolStripMenuItem.Click += new System.EventHandler(this.FindPeople_Click);
            // 
            // deleteContactToolStripMenuItem
            // 
            this.deleteContactToolStripMenuItem.Name = "deleteContactToolStripMenuItem";
            this.deleteContactToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.deleteContactToolStripMenuItem.Text = "Delete Contact";
            this.deleteContactToolStripMenuItem.Click += new System.EventHandler(this.DeleteContact_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(183, 6);
            // 
            // itmTransferData
            // 
            this.itmTransferData.Name = "itmTransferData";
            this.itmTransferData.Size = new System.Drawing.Size(186, 22);
            this.itmTransferData.Text = "Transfer Data";
            this.itmTransferData.Click += new System.EventHandler(this.TransferData);
            // 
            // printContactsToolStripMenuItem
            // 
            this.printContactsToolStripMenuItem.Name = "printContactsToolStripMenuItem";
            this.printContactsToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.printContactsToolStripMenuItem.Text = "Print Contacts";
            this.printContactsToolStripMenuItem.Click += new System.EventHandler(this.PrintContacts);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(183, 6);
            // 
            // reminderToolStripMenuItem
            // 
            this.reminderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmAddEvent,
            this.itmDeleteEvent});
            this.reminderToolStripMenuItem.Name = "reminderToolStripMenuItem";
            this.reminderToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.reminderToolStripMenuItem.Text = "Reminder";
            // 
            // itmAddEvent
            // 
            this.itmAddEvent.Name = "itmAddEvent";
            this.itmAddEvent.Size = new System.Drawing.Size(147, 22);
            this.itmAddEvent.Text = "Add Event";
            this.itmAddEvent.Click += new System.EventHandler(this.AddReminder);
            // 
            // itmDeleteEvent
            // 
            this.itmDeleteEvent.Name = "itmDeleteEvent";
            this.itmDeleteEvent.Size = new System.Drawing.Size(147, 22);
            this.itmDeleteEvent.Text = "Delete Event";
            this.itmDeleteEvent.Click += new System.EventHandler(this.DeleteReminder);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(183, 6);
            // 
            // signOutToolStripMenuItem
            // 
            this.signOutToolStripMenuItem.Name = "signOutToolStripMenuItem";
            this.signOutToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.signOutToolStripMenuItem.Text = "Sign &Out";
            this.signOutToolStripMenuItem.Click += new System.EventHandler(this.SignOut_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitApplication);
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmStatusBar,
            this.toolStripSeparator2,
            this.itmSmallIcons,
            this.itmTile,
            this.itmList,
            this.itmDetails,
            this.toolStripSeparator4,
            this.itmViewRemainder,
            this.itmUserPanel,
            this.toolStripSeparator6,
            this.itmRefresh});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(41, 20);
            this.viewMenu.Text = "&View";
            // 
            // itmStatusBar
            // 
            this.itmStatusBar.Checked = true;
            this.itmStatusBar.CheckOnClick = true;
            this.itmStatusBar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itmStatusBar.Name = "itmStatusBar";
            this.itmStatusBar.Size = new System.Drawing.Size(147, 22);
            this.itmStatusBar.Text = "&Status Bar";
            this.itmStatusBar.Click += new System.EventHandler(this.ShowHideStatus_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(144, 6);
            // 
            // itmSmallIcons
            // 
            this.itmSmallIcons.Name = "itmSmallIcons";
            this.itmSmallIcons.Size = new System.Drawing.Size(147, 22);
            this.itmSmallIcons.Text = "Icons";
            this.itmSmallIcons.Click += new System.EventHandler(this.ViewAsSmallIcons);
            // 
            // itmTile
            // 
            this.itmTile.Name = "itmTile";
            this.itmTile.Size = new System.Drawing.Size(147, 22);
            this.itmTile.Text = "Tile";
            this.itmTile.Click += new System.EventHandler(this.ViewAsTile);
            // 
            // itmList
            // 
            this.itmList.Name = "itmList";
            this.itmList.Size = new System.Drawing.Size(147, 22);
            this.itmList.Text = "List";
            this.itmList.Click += new System.EventHandler(this.ViewAsList);
            // 
            // itmDetails
            // 
            this.itmDetails.Checked = true;
            this.itmDetails.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itmDetails.Name = "itmDetails";
            this.itmDetails.Size = new System.Drawing.Size(147, 22);
            this.itmDetails.Text = "Details";
            this.itmDetails.Click += new System.EventHandler(this.ViewAsDetails);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(144, 6);
            // 
            // itmViewRemainder
            // 
            this.itmViewRemainder.Name = "itmViewRemainder";
            this.itmViewRemainder.Size = new System.Drawing.Size(147, 22);
            this.itmViewRemainder.Text = "Remainder";
            this.itmViewRemainder.Click += new System.EventHandler(this.ViewRemainder);
            // 
            // itmUserPanel
            // 
            this.itmUserPanel.Checked = true;
            this.itmUserPanel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itmUserPanel.Name = "itmUserPanel";
            this.itmUserPanel.Size = new System.Drawing.Size(147, 22);
            this.itmUserPanel.Text = "Selection Bar";
            this.itmUserPanel.Click += new System.EventHandler(this.ShowHideUsersPanel);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(144, 6);
            // 
            // itmRefresh
            // 
            this.itmRefresh.Name = "itmRefresh";
            this.itmRefresh.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.itmRefresh.Size = new System.Drawing.Size(147, 22);
            this.itmRefresh.Text = "Refresh";
            this.itmRefresh.Click += new System.EventHandler(this.RefreshGrid);
            // 
            // toolsMenu
            // 
            this.toolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userAccountToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.toolStripSeparator1,
            this.itmSettings});
            this.toolsMenu.Name = "toolsMenu";
            this.toolsMenu.Size = new System.Drawing.Size(44, 20);
            this.toolsMenu.Text = "&Tools";
            // 
            // userAccountToolStripMenuItem
            // 
            this.userAccountToolStripMenuItem.Name = "userAccountToolStripMenuItem";
            this.userAccountToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.userAccountToolStripMenuItem.Text = "User Account";
            this.userAccountToolStripMenuItem.Click += new System.EventHandler(this.UserAccount_Clicked);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.UpdatePassword);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(168, 6);
            // 
            // itmSettings
            // 
            this.itmSettings.Name = "itmSettings";
            this.itmSettings.Size = new System.Drawing.Size(171, 22);
            this.itmSettings.Text = "Settings";
            this.itmSettings.Click += new System.EventHandler(this.UpdateSettings);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(40, 20);
            this.helpMenu.Text = "&Help";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.contentsToolStripMenuItem.Text = "&Contents";
            this.contentsToolStripMenuItem.Click += new System.EventHandler(this.Help_Requested);
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.indexToolStripMenuItem.Text = "&Index";
            this.indexToolStripMenuItem.Click += new System.EventHandler(this.Help_Requested);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.searchToolStripMenuItem.Text = "&Search";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.Help_Requested);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(170, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.aboutToolStripMenuItem.Text = "&About ...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.AboutAddressBook);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblConnectionStatus});
            this.statusStrip.Location = new System.Drawing.Point(0, 479);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(857, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // lblConnectionStatus
            // 
            this.lblConnectionStatus.Name = "lblConnectionStatus";
            this.lblConnectionStatus.Size = new System.Drawing.Size(59, 17);
            this.lblConnectionStatus.Text = "Connected";
            // 
            // trayContextMenu
            // 
            this.trayContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itmContacts,
            this.toolStripSeparator9,
            this.itmLogin,
            this.itmLogout,
            this.toolStripSeparator10,
            this.itmExit});
            this.trayContextMenu.Name = "ContextMenu";
            this.trayContextMenu.Size = new System.Drawing.Size(129, 104);
            this.trayContextMenu.Text = "Menu";
            // 
            // itmContacts
            // 
            this.itmContacts.Name = "itmContacts";
            this.itmContacts.Size = new System.Drawing.Size(128, 22);
            this.itmContacts.Text = "Contacts";
            this.itmContacts.Click += new System.EventHandler(this.ShowContacts);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(125, 6);
            // 
            // itmLogin
            // 
            this.itmLogin.Name = "itmLogin";
            this.itmLogin.Size = new System.Drawing.Size(128, 22);
            this.itmLogin.Text = "Login";
            this.itmLogin.Click += new System.EventHandler(this.ShowLoginForm);
            // 
            // itmLogout
            // 
            this.itmLogout.Name = "itmLogout";
            this.itmLogout.Size = new System.Drawing.Size(128, 22);
            this.itmLogout.Text = "Logout";
            this.itmLogout.Click += new System.EventHandler(this.SignOut_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(125, 6);
            // 
            // itmExit
            // 
            this.itmExit.Name = "itmExit";
            this.itmExit.Size = new System.Drawing.Size(128, 22);
            this.itmExit.Text = "Exit";
            this.itmExit.Click += new System.EventHandler(this.ExitApplication);
            // 
            // TrayIcon
            // 
            this.TrayIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.TrayIcon.BalloonTipText = "To view your contacts and other details right click and select Login options.";
            this.TrayIcon.BalloonTipTitle = "Address Book v1.2";
            this.TrayIcon.ContextMenuStrip = this.trayContextMenu;
            this.TrayIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("TrayIcon.Icon")));
            this.TrayIcon.Text = "Address Book v1.2";
            this.TrayIcon.Visible = true;
            this.TrayIcon.DoubleClick += new System.EventHandler(this.ShowContacts);
            // 
            // panelLeft
            // 
            this.panelLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelLeft.Controls.Add(this.UserList);
            this.panelLeft.Controls.Add(this.label1);
            this.panelLeft.Controls.Add(this.txtCategory);
            this.panelLeft.Controls.Add(this.btnHeader);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 24);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(189, 455);
            this.panelLeft.TabIndex = 0;
            // 
            // UserList
            // 
            this.UserList.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.UserList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UserList.ImageIndex = 1;
            this.UserList.ImageList = this.ImageList1;
            this.UserList.Location = new System.Drawing.Point(0, 25);
            this.UserList.Name = "UserList";
            this.UserList.SelectedImageIndex = 1;
            this.UserList.Size = new System.Drawing.Size(185, 229);
            this.UserList.TabIndex = 0;
            this.UserList.DoubleClick += new System.EventHandler(this.ShowUserRelatedContacts);
            // 
            // ImageList1
            // 
            this.ImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList1.ImageStream")));
            this.ImageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList1.Images.SetKeyName(0, "Contact");
            this.ImageList1.Images.SetKeyName(1, "User");
            this.ImageList1.Images.SetKeyName(2, "Folder");
            this.ImageList1.Images.SetKeyName(3, "Cut");
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCategory
            // 
            this.txtCategory.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtCategory.ContextMenuStrip = this.categoryContext;
            this.txtCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtCategory.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCategory.ImageIndex = 2;
            this.txtCategory.ImageList = this.ImageList1;
            this.txtCategory.Location = new System.Drawing.Point(0, 279);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.SelectedImageIndex = 2;
            this.txtCategory.Size = new System.Drawing.Size(185, 172);
            this.txtCategory.TabIndex = 1;
            this.txtCategory.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.txtCategory_DoubleClick);
            this.txtCategory.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.NameChanged);
            // 
            // categoryContext
            // 
            this.categoryContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.editToolStripMenuItem,
            this.removeToolStripMenuItem,
            this.toolStripSeparator12,
            this.itmShowAllContacts,
            this.toolStripSeparator14,
            this.pasteToolStripMenuItem});
            this.categoryContext.Name = "categoryContext";
            this.categoryContext.Size = new System.Drawing.Size(172, 126);
            this.categoryContext.Opening += new System.ComponentModel.CancelEventHandler(this.CategoryContext_Showing);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoryToolStripMenuItem,
            this.contactToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.addToolStripMenuItem.Text = "New";
            // 
            // categoryToolStripMenuItem
            // 
            this.categoryToolStripMenuItem.Name = "categoryToolStripMenuItem";
            this.categoryToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.categoryToolStripMenuItem.Text = "Category";
            this.categoryToolStripMenuItem.Click += new System.EventHandler(this.AddCategory_Clicked);
            // 
            // contactToolStripMenuItem
            // 
            this.contactToolStripMenuItem.Name = "contactToolStripMenuItem";
            this.contactToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.contactToolStripMenuItem.Text = "Contact";
            this.contactToolStripMenuItem.Click += new System.EventHandler(this.NewContactByCategory);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.editToolStripMenuItem.Text = "Rename";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.EditCategory_Click);
            // 
            // removeToolStripMenuItem
            // 
            this.removeToolStripMenuItem.Name = "removeToolStripMenuItem";
            this.removeToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.removeToolStripMenuItem.Text = "Remove";
            this.removeToolStripMenuItem.Click += new System.EventHandler(this.RemoveCategory_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(168, 6);
            // 
            // itmShowAllContacts
            // 
            this.itmShowAllContacts.Name = "itmShowAllContacts";
            this.itmShowAllContacts.Size = new System.Drawing.Size(171, 22);
            this.itmShowAllContacts.Text = "Show All Contacts";
            this.itmShowAllContacts.Click += new System.EventHandler(this.ShowAllContacts_Clicked);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(168, 6);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.PasteContact_Clicked);
            // 
            // btnHeader
            // 
            this.btnHeader.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHeader.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHeader.Location = new System.Drawing.Point(0, 0);
            this.btnHeader.Name = "btnHeader";
            this.btnHeader.Size = new System.Drawing.Size(185, 25);
            this.btnHeader.TabIndex = 0;
            this.btnHeader.Text = "Users";
            this.btnHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelDock
            // 
            this.panelDock.Controls.Add(this.ContactDetails);
            this.panelDock.Controls.Add(this.panelReminder);
            this.panelDock.Controls.Add(this.panel1);
            this.panelDock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDock.Location = new System.Drawing.Point(189, 24);
            this.panelDock.Name = "panelDock";
            this.panelDock.Size = new System.Drawing.Size(668, 455);
            this.panelDock.TabIndex = 5;
            // 
            // ContactDetails
            // 
            this.ContactDetails.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.ContactDetails.BackColor = System.Drawing.SystemColors.Info;
            this.ContactDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.FulLastName,
            this.Mobile,
            this.colOfficePhone,
            this.HomePhone,
            this.DefaultEmail});
            this.ContactDetails.ContextMenuStrip = this.ContextMenu;
            this.ContactDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ContactDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactDetails.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactDetails.FullRowSelect = true;
            this.ContactDetails.GridLines = true;
            this.ContactDetails.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.ContactDetails.HideSelection = false;
            this.ContactDetails.Location = new System.Drawing.Point(0, 29);
            this.ContactDetails.Name = "ContactDetails";
            this.ContactDetails.ShowGroups = false;
            this.ContactDetails.Size = new System.Drawing.Size(668, 227);
            this.ContactDetails.SmallImageList = this.ImageList1;
            this.ContactDetails.TabIndex = 0;
            this.ContactDetails.TileSize = new System.Drawing.Size(250, 80);
            this.ContactDetails.UseCompatibleStateImageBehavior = false;
            this.ContactDetails.View = System.Windows.Forms.View.Details;
            this.ContactDetails.DoubleClick += new System.EventHandler(this.EditContact_Click);
            // 
            // FulLastName
            // 
            this.FulLastName.Text = "Name";
            this.FulLastName.Width = 168;
            // 
            // Mobile
            // 
            this.Mobile.Text = "Mobile Phone";
            this.Mobile.Width = 176;
            // 
            // colOfficePhone
            // 
            this.colOfficePhone.Text = "OfficePhone";
            this.colOfficePhone.Width = 165;
            // 
            // HomePhone
            // 
            this.HomePhone.Text = "Home Phone";
            this.HomePhone.Width = 144;
            // 
            // DefaultEmail
            // 
            this.DefaultEmail.Text = "Default Email";
            this.DefaultEmail.Width = 176;
            // 
            // ContextMenu
            // 
            this.ContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newContactToolStripMenuItem,
            this.deleteContactToolStripMenuItem1,
            this.toolStripSeparator11,
            this.actionsToolStripMenuItem,
            this.propertiesToolStripMenuItem,
            this.toolStripSeparator13,
            this.cutToolStripMenuItem});
            this.ContextMenu.Name = "ContextMenu";
            this.ContextMenu.Size = new System.Drawing.Size(158, 126);
            this.ContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.ContactsContextShown);
            // 
            // newContactToolStripMenuItem
            // 
            this.newContactToolStripMenuItem.Name = "newContactToolStripMenuItem";
            this.newContactToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.newContactToolStripMenuItem.Text = "New Contact";
            this.newContactToolStripMenuItem.Click += new System.EventHandler(this.NewContact_Click);
            // 
            // deleteContactToolStripMenuItem1
            // 
            this.deleteContactToolStripMenuItem1.Name = "deleteContactToolStripMenuItem1";
            this.deleteContactToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.deleteContactToolStripMenuItem1.Text = "Delete Contact";
            this.deleteContactToolStripMenuItem1.Click += new System.EventHandler(this.DeleteContact_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(154, 6);
            // 
            // actionsToolStripMenuItem
            // 
            this.actionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.callToolStripMenuItem,
            this.shareContactToolStripMenuItem});
            this.actionsToolStripMenuItem.Name = "actionsToolStripMenuItem";
            this.actionsToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.actionsToolStripMenuItem.Text = "Actions";
            // 
            // callToolStripMenuItem
            // 
            this.callToolStripMenuItem.Name = "callToolStripMenuItem";
            this.callToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.callToolStripMenuItem.Text = "Call";
            this.callToolStripMenuItem.Click += new System.EventHandler(this.MakeCall);
            // 
            // shareContactToolStripMenuItem
            // 
            this.shareContactToolStripMenuItem.Name = "shareContactToolStripMenuItem";
            this.shareContactToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.shareContactToolStripMenuItem.Text = "Share Contact";
            this.shareContactToolStripMenuItem.Click += new System.EventHandler(this.ShareContacts);
            // 
            // propertiesToolStripMenuItem
            // 
            this.propertiesToolStripMenuItem.Name = "propertiesToolStripMenuItem";
            this.propertiesToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.propertiesToolStripMenuItem.Text = "Properties";
            this.propertiesToolStripMenuItem.Click += new System.EventHandler(this.EditContact_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(154, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.cutToolStripMenuItem.Text = "Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.CutContacts_Clicked);
            // 
            // panelReminder
            // 
            this.panelReminder.Controls.Add(this.ReminderDetails);
            this.panelReminder.Controls.Add(this.lblReminderHeader);
            this.panelReminder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelReminder.Location = new System.Drawing.Point(0, 256);
            this.panelReminder.Name = "panelReminder";
            this.panelReminder.Size = new System.Drawing.Size(668, 199);
            this.panelReminder.TabIndex = 0;
            this.panelReminder.Visible = false;
            // 
            // ReminderDetails
            // 
            this.ReminderDetails.BackColor = System.Drawing.SystemColors.Info;
            this.ReminderDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colID,
            this.colName,
            this.colDate,
            this.colDescription});
            this.ReminderDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReminderDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ReminderDetails.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReminderDetails.FullRowSelect = true;
            this.ReminderDetails.GridLines = true;
            this.ReminderDetails.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.ReminderDetails.HideSelection = false;
            this.ReminderDetails.Location = new System.Drawing.Point(0, 25);
            this.ReminderDetails.MultiSelect = false;
            this.ReminderDetails.Name = "ReminderDetails";
            this.ReminderDetails.Size = new System.Drawing.Size(668, 174);
            this.ReminderDetails.TabIndex = 0;
            this.ReminderDetails.UseCompatibleStateImageBehavior = false;
            this.ReminderDetails.View = System.Windows.Forms.View.Details;
            // 
            // colID
            // 
            this.colID.Text = "";
            this.colID.Width = 0;
            // 
            // colName
            // 
            this.colName.Text = "Name";
            this.colName.Width = 140;
            // 
            // colDate
            // 
            this.colDate.Text = "Date & Time";
            this.colDate.Width = 160;
            // 
            // colDescription
            // 
            this.colDescription.Text = "Description";
            this.colDescription.Width = 360;
            // 
            // lblReminderHeader
            // 
            this.lblReminderHeader.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblReminderHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblReminderHeader.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReminderHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblReminderHeader.Location = new System.Drawing.Point(0, 0);
            this.lblReminderHeader.Name = "lblReminderHeader";
            this.lblReminderHeader.Size = new System.Drawing.Size(668, 25);
            this.lblReminderHeader.TabIndex = 0;
            this.lblReminderHeader.Text = "Reminder";
            this.lblReminderHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtFastSearch);
            this.panel1.Controls.Add(this.lblSearchName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(668, 29);
            this.panel1.TabIndex = 1;
            // 
            // txtFastSearch
            // 
            this.txtFastSearch.Location = new System.Drawing.Point(92, 4);
            this.txtFastSearch.Name = "txtFastSearch";
            this.txtFastSearch.Size = new System.Drawing.Size(226, 20);
            this.txtFastSearch.TabIndex = 0;
            this.txtFastSearch.TextChanged += new System.EventHandler(this.FastSearch);
            // 
            // lblSearchName
            // 
            this.lblSearchName.AutoSize = true;
            this.lblSearchName.Location = new System.Drawing.Point(11, 7);
            this.lblSearchName.Name = "lblSearchName";
            this.lblSearchName.Size = new System.Drawing.Size(75, 13);
            this.lblSearchName.TabIndex = 6;
            this.lblSearchName.Text = "Search Name:";
            // 
            // frmContacts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ClientSize = new System.Drawing.Size(857, 501);
            this.Controls.Add(this.panelDock);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.statusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "frmContacts";
            this.Opacity = 0;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Address Book - [Main Identity]";
            this.Shown += new System.EventHandler(this.Shown_Raised);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.trayContextMenu.ResumeLayout(false);
            this.panelLeft.ResumeLayout(false);
            this.categoryContext.ResumeLayout(false);
            this.panelDock.ResumeLayout(false);
            this.ContextMenu.ResumeLayout(false);
            this.panelReminder.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        System.Windows.Forms.MenuStrip menuStrip;
        System.Windows.Forms.StatusStrip statusStrip;
        System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        System.Windows.Forms.ToolStripStatusLabel lblConnectionStatus;
        System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem menuOptions;
        System.Windows.Forms.ToolStripMenuItem itmNewContact;
        System.Windows.Forms.ToolStripMenuItem itmViewEdit;
        System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem viewMenu;
        System.Windows.Forms.ToolStripMenuItem toolsMenu;
        System.Windows.Forms.ToolStripMenuItem helpMenu;
        System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        System.Windows.Forms.ToolTip ToolTip;
        System.Windows.Forms.ToolStripMenuItem itmStatusBar;
        System.Windows.Forms.ToolStripMenuItem userAccountToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem deleteContactToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem itmTransferData;
        System.Windows.Forms.ToolStripMenuItem signOutToolStripMenuItem;
        System.Windows.Forms.ToolStripMenuItem findPeopleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem itmSmallIcons;
        private System.Windows.Forms.ToolStripMenuItem itmList;
        private System.Windows.Forms.ToolStripMenuItem itmDetails;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem itmRefresh;
        private System.Windows.Forms.ToolStripMenuItem itmTile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem itmSettings;
        private System.Windows.Forms.ToolStripMenuItem itmViewRemainder;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem reminderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itmAddEvent;
        private System.Windows.Forms.ToolStripMenuItem itmDeleteEvent;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ContextMenuStrip trayContextMenu;
        private System.Windows.Forms.ToolStripMenuItem itmContacts;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem itmLogin;
        private System.Windows.Forms.ToolStripMenuItem itmLogout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem itmExit;
        private System.Windows.Forms.NotifyIcon TrayIcon;
        private System.Windows.Forms.Panel panelDock;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.ListView ContactDetails;
        private System.Windows.Forms.ColumnHeader FulLastName;
        private System.Windows.Forms.ColumnHeader Mobile;
        private System.Windows.Forms.ColumnHeader HomePhone;
        private System.Windows.Forms.ColumnHeader DefaultEmail;
        private System.Windows.Forms.Panel panelReminder;
        private System.Windows.Forms.ListView ReminderDetails;
        private System.Windows.Forms.ColumnHeader colID;
        private System.Windows.Forms.ColumnHeader colName;
        private System.Windows.Forms.ColumnHeader colDate;
        private System.Windows.Forms.Label lblReminderHeader;
        private System.Windows.Forms.Label btnHeader;
        private System.Windows.Forms.TreeView UserList;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSearchName;
        private System.Windows.Forms.TextBox txtFastSearch;
        private System.Windows.Forms.ContextMenuStrip ContextMenu;
        private System.Windows.Forms.ToolStripMenuItem newContactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteContactToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem actionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem callToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shareContactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader colDescription;
        private System.Windows.Forms.ToolStripMenuItem itmUserPanel;
        private System.Windows.Forms.ColumnHeader colOfficePhone;
        private System.Windows.Forms.TreeView txtCategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList ImageList1;
        private System.Windows.Forms.ContextMenuStrip categoryContext;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itmShowAllContacts;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem printContactsToolStripMenuItem;
    }
}




using System;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmPrinter : Form
    {
        public frmPrinter()
        {
            InitializeComponent();
        }

        void LoadPrinter(object sender, EventArgs e)
        {
            Program.Connection.CommandText = "select SchemaName from BkfSchemas";
            DataTable DT = new DataTable();
            Program.Connection.FillDataTable(DT, true);
            txtSchemaList.Items.Clear();
            for (int i = 0; i < DT.Rows.Count; i++)
                txtSchemaList.Items.Add(DT.Rows[i][0]);
            txtSchemaList.SelectedIndex = 0;
            lstPrintType.SelectedIndex = 0;
            DT = null;
            DT = new DataTable();

            string CommandText = "select CIdentity, FirstName, MiddleName, LastName, Mobile, HomePhone, OfficePhone, DefaultEmail from ContactsData";

            if (!UserPolicies.IsAdministrator)
                CommandText += " where UserID='" + Converter.Encrypt(UserPolicies.UserID) + "'";
            
            Program.Connection.CommandText = CommandText;

            Program.Connection.FillDataTable(DT, true);

            lstContacts.Items.Clear();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                string[] NewRow = new string[6];
                NewRow[5] = DT.Rows[i][0].ToString();
                try { NewRow[0] = DT.Rows[i][1].ToString(); }
                catch { NewRow[0] = ""; }
                try { NewRow[0] += " " + DT.Rows[i][2].ToString(); }
                catch { }
                try { NewRow[0] += " " + DT.Rows[i][3].ToString(); }
                catch { }
                try { NewRow[1] = DT.Rows[i][4].ToString(); }
                catch { NewRow[1] = ""; }
                try { NewRow[2] = DT.Rows[i][5].ToString(); }
                catch { NewRow[2] = ""; }
                try { NewRow[3] = DT.Rows[i][6].ToString(); }
                catch { NewRow[3] = ""; }
                try { NewRow[4] = DT.Rows[i][7].ToString(); }
                catch { NewRow[4] = ""; }
                lstContacts.Items.Add(new ListViewItem(NewRow));
            }
        }

        void Select_Unselect_All(object sender, EventArgs e)
        {
            foreach (ListViewItem Item in lstContacts.Items)
            {
                Item.Checked = chkSelectAll.Checked;
            }
        }

        void Save(object sender, EventArgs e)
        {
            if (lstContacts.CheckedItems.Count < 1) { MessageBox.Show("Select atleast one contact to generate print file.", "No Data"); return; }
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.DefaultExt = ".html";
            SFD.AddExtension = true;
            SFD.Filter = "Web Page Layout (*.html)|*.html";
            if (SFD.ShowDialog() == DialogResult.Cancel) return;

            Program.Connection.CommandText = "select SchemaSet from BkfSchemas where SchemaName='" + Converter.Encrypt(txtSchemaList.SelectedItem.ToString()) + "'";
            DataTable DT = new DataTable();
            Program.Connection.FillDataTable(DT, false);
            if (DT.Rows.Count == 0) { MessageBox.Show("The selected schema type cannot be found.", "Invalid Schema"); return; }

            StreamWriter SW = new StreamWriter(Application.StartupPath + "\\_DataSch.mdb");
            SW.Write(DT.Rows[0][0].ToString());
            SW.Close(); SW = null;

            DT = new DataTable();
            DT.ReadXmlSchema(Application.StartupPath + "\\_DataSch.mdb");
            File.Delete(Application.StartupPath + "\\_DataSch.mdb");

            string ColNames = DT.Columns[0].ColumnName;

            for (int i = 1; i < DT.Columns.Count; i++)
            {
                ColNames += ", " + DT.Columns[i].ColumnName;
            }

            string IDS = "'" + lstContacts.CheckedItems[0].SubItems[5].Text + "'";

            for (int i = 1; i < lstContacts.CheckedItems.Count; i++)
            {
                IDS += ", '" + lstContacts.CheckedItems[i].SubItems[5].Text + "'";
            }

            Program.Connection.CommandText = "select " + ColNames + " from ContactsData where CIdentity in (" + IDS + ")";

            DT = null;
            DT = new DataTable("Contacts");
            Program.Connection.FillDataTable(DT, true);
            SaveFile(DT, SFD.FileName);
        }

        void SaveFile(DataTable Table, string FileName)
        {
            if (lstPrintType.SelectedIndex == 0)
                SaveFile_RowType(Table, FileName, true);
            else if (lstPrintType.SelectedIndex == 1)
                SaveFile_RowType(Table, FileName, false);
            else if (lstPrintType.SelectedIndex == 2)
                SaveFile_BioData(Table, FileName, true);
            else if (lstPrintType.SelectedIndex == 3)
                SaveFile_BioData(Table, FileName, false);
        }

        void SaveFile_RowType(DataTable Table, string FileName, bool ShowBorder)
        {
            string BorderColor = " bordercolor=\"#FFFFFF\"";
            if (ShowBorder) BorderColor = " bordercolor=\"#000000\"";

            StreamWriter SW = new StreamWriter(FileName);
            SW.Write("<html><title>Address Book :: Contacts</title><body><table border=\"1px\" width=\"100%\">");
            SW.WriteLine("<tr align=\"center\" bgcolor=\"#9999FF\" bordercolor=\"#000000\">");

            foreach (DataColumn Column in Table.Columns)
            {
                SW.Write("<td><b>" + Column.Caption + "</b></td>");
            }
            SW.WriteLine("</tr>");

            foreach (DataRow Row in Table.Rows)
            {
                SW.Write("<tr" + BorderColor + ">");
                for (int i = 0; i < Table.Columns.Count; i++)
                {
                    SW.Write("<td>" + Row[i].ToString() + " &nbsp;</td>");
                }
                SW.WriteLine("</tr>");
            }
            SW.Write("</table></body></html>");
            SW.Close(); SW = null;
        }
        
        void SaveFile_BioData(DataTable Table, string FileName, bool ShowBorder)
        {
            string BorderWidth = "";
            if (ShowBorder) BorderWidth = " border=\"1px\"";

            StreamWriter SW = new StreamWriter(FileName);
            SW.Write("<html><title>Address Book :: Contacts</title><body>");

            foreach (DataRow Row in Table.Rows)
            {
                SW.Write("<table" + BorderWidth + " width=\"100%\">");
                for (int i = 0; i < Table.Columns.Count; i++)
                {
                    SW.Write("<tr><td width=\"262\"><b>" + Table.Columns[i].ColumnName + "</b></td><td>" + Row[i].ToString() + " &nbsp;</td></tr>");
                }
                SW.WriteLine("</table><br><hr><br>");
            }
            SW.Write("</body></html>");
            SW.Close(); SW = null;
        }
    }
}
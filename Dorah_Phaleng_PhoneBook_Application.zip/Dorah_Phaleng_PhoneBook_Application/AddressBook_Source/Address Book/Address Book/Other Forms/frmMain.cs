using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmMain : Form
    {
        Timer MyTimer = new Timer();

        public frmMain()
        {
            InitializeComponent();
            Opacity = 0.9;
            MyTimer.Interval = 3500;
            MyTimer.Tick += new EventHandler(Close);
            MyTimer.Enabled = true;
            System.Drawing.Bitmap Image = (System.Drawing.Bitmap)BackgroundImage;
            Image.MakeTransparent(System.Drawing.Color.FromArgb(0, 255, 0));
        }

        void Close(object sender, EventArgs e)
        {
            Close();
        }
    }
}
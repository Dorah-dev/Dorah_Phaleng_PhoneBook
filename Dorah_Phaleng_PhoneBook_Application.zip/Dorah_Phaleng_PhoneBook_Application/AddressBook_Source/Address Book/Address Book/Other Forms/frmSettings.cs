using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
        }

        void LoadSettings(object sender, EventArgs e)
        {
            if (((ConnectionTypes)DataConnection.ConnectionType) == ConnectionTypes.AccessConnection)
                optAccessDatabase.Checked = true;
            if (((ConnectionTypes)DataConnection.ConnectionType) == ConnectionTypes.MySQLConnection)
                optMySqlConnection.Checked = true;
            else optSQLDatabase.Checked = true;

            Microsoft.Win32.RegistryKey RegKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            if (RegKey.GetValue("AddressBook 1.0", null) != null) optRunatCUser.Checked = true;
            RegKey.Close();

            RegKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            if (RegKey.GetValue("AddressBook 1.0", null) != null) optRunatAUserStartup.Checked = true;
            RegKey.Close();
        }

        void SaveSettings(object sender, EventArgs e)
        {
            try
            {
                Microsoft.Win32.RegistryKey RegKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);

                if (optRunatAUserStartup.Checked)
                {
                    RegKey.SetValue("AddressBook 1.0", Environment.GetCommandLineArgs()[0]);
                    RegKey.Close();
                }
                else
                {
                    RegKey.DeleteValue("AddressBook 1.0", false);
                    RegKey.Close();
                }

                RegKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);

                if (optRunatCUser.Checked)
                {
                    RegKey.SetValue("AddressBook 1.0", Environment.GetCommandLineArgs()[0]);
                    RegKey.Close();
                }
                else
                {
                    RegKey.DeleteValue("AddressBook 1.0", false);
                    RegKey.Close();
                }
                Hide();
                Form DatabaseSettings = null;
                if (optAccessDatabase.Checked) DatabaseSettings = new frmAccessSettings();
                else if (optMySqlConnection.Checked) DatabaseSettings = new frmMySQLSetting();
                else DatabaseSettings = new frmSQLSetting();
                if (DatabaseSettings.ShowDialog() == DialogResult.Cancel) { this.DialogResult = DialogResult.Cancel; Show(); return; }

                Close();
            }
            catch (Exception Ex) { MessageBox.Show("You do not have sufficient rights to perform this action.\n\nError Message:\n" + Ex.Message, "Access Denied"); this.DialogResult = DialogResult.Cancel; }
        }

        void CancelSettings(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        void AllUserStartUp_Checked(object sender, EventArgs e)
        {
            if (optRunatAUserStartup.Checked) optRunatCUser.Checked = optRunatCUser.Enabled = false;
            else optRunatCUser.Enabled = true;
        }
    }
}
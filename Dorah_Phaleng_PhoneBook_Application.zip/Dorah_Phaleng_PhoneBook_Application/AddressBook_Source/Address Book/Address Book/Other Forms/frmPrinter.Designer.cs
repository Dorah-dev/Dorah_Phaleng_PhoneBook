namespace AddressBook
{
    partial class frmPrinter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrinter));
            this.lblHeader = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstPrintType = new System.Windows.Forms.ComboBox();
            this.txtSchemaList = new System.Windows.Forms.ComboBox();
            this.lblPrintingSchema = new System.Windows.Forms.Label();
            this.lstContacts = new System.Windows.Forms.ListView();
            this.colName = new System.Windows.Forms.ColumnHeader();
            this.colMobile = new System.Windows.Forms.ColumnHeader();
            this.colHomePhone = new System.Windows.Forms.ColumnHeader();
            this.colOfficePhone = new System.Windows.Forms.ColumnHeader();
            this.colEmail = new System.Windows.Forms.ColumnHeader();
            this.colID = new System.Windows.Forms.ColumnHeader();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.panelTools = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.panelTools.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.BackColor = System.Drawing.SystemColors.Info;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(638, 23);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Contacts";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1.Location = new System.Drawing.Point(6, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Printing Type";
            // 
            // lstPrintType
            // 
            this.lstPrintType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstPrintType.FormattingEnabled = true;
            this.lstPrintType.Items.AddRange(new object[] {
            "Tabular (With Border)",
            "Tabular (No Border)",
            "Bio-Data (With Border)",
            "Bio-Data (No Border)"});
            this.lstPrintType.Location = new System.Drawing.Point(81, 7);
            this.lstPrintType.Name = "lstPrintType";
            this.lstPrintType.Size = new System.Drawing.Size(179, 21);
            this.lstPrintType.TabIndex = 2;
            // 
            // txtSchemaList
            // 
            this.txtSchemaList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtSchemaList.FormattingEnabled = true;
            this.txtSchemaList.Items.AddRange(new object[] {
            "Tabular",
            "Contact per Page"});
            this.txtSchemaList.Location = new System.Drawing.Point(366, 7);
            this.txtSchemaList.Name = "txtSchemaList";
            this.txtSchemaList.Size = new System.Drawing.Size(179, 21);
            this.txtSchemaList.TabIndex = 4;
            // 
            // lblPrintingSchema
            // 
            this.lblPrintingSchema.AutoSize = true;
            this.lblPrintingSchema.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblPrintingSchema.Location = new System.Drawing.Point(276, 10);
            this.lblPrintingSchema.Name = "lblPrintingSchema";
            this.lblPrintingSchema.Size = new System.Drawing.Size(84, 13);
            this.lblPrintingSchema.TabIndex = 0;
            this.lblPrintingSchema.Text = "Printing Schema";
            // 
            // lstContacts
            // 
            this.lstContacts.CheckBoxes = true;
            this.lstContacts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colName,
            this.colMobile,
            this.colHomePhone,
            this.colOfficePhone,
            this.colEmail,
            this.colID});
            this.lstContacts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstContacts.Location = new System.Drawing.Point(0, 23);
            this.lstContacts.Name = "lstContacts";
            this.lstContacts.Size = new System.Drawing.Size(638, 286);
            this.lstContacts.TabIndex = 5;
            this.lstContacts.UseCompatibleStateImageBehavior = false;
            this.lstContacts.View = System.Windows.Forms.View.Details;
            // 
            // colName
            // 
            this.colName.Text = "Name";
            this.colName.Width = 124;
            // 
            // colMobile
            // 
            this.colMobile.Text = "Mobile";
            this.colMobile.Width = 120;
            // 
            // colHomePhone
            // 
            this.colHomePhone.Text = "Home Phone";
            this.colHomePhone.Width = 139;
            // 
            // colOfficePhone
            // 
            this.colOfficePhone.Text = "Office Phone";
            this.colOfficePhone.Width = 134;
            // 
            // colEmail
            // 
            this.colEmail.Text = "Default Email";
            this.colEmail.Width = 114;
            // 
            // colID
            // 
            this.colID.Text = "";
            this.colID.Width = 0;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.chkSelectAll.Location = new System.Drawing.Point(560, 11);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(70, 17);
            this.chkSelectAll.TabIndex = 2;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = false;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.Select_Unselect_All);
            // 
            // panelTools
            // 
            this.panelTools.AllowDrop = true;
            this.panelTools.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panelTools.Controls.Add(this.lstPrintType);
            this.panelTools.Controls.Add(this.chkSelectAll);
            this.panelTools.Controls.Add(this.label1);
            this.panelTools.Controls.Add(this.txtSchemaList);
            this.panelTools.Controls.Add(this.lblPrintingSchema);
            this.panelTools.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelTools.Location = new System.Drawing.Point(0, 309);
            this.panelTools.Name = "panelTools";
            this.panelTools.Size = new System.Drawing.Size(638, 37);
            this.panelTools.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.Info;
            this.btnSave.Location = new System.Drawing.Point(-1, -1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.Save);
            // 
            // frmPrinter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 346);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lstContacts);
            this.Controls.Add(this.panelTools);
            this.Controls.Add(this.lblHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPrinter";
            this.ShowInTaskbar = false;
            this.Text = "Address Book :: Printing";
            this.Load += new System.EventHandler(this.LoadPrinter);
            this.panelTools.ResumeLayout(false);
            this.panelTools.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox lstPrintType;
        private System.Windows.Forms.ComboBox txtSchemaList;
        private System.Windows.Forms.Label lblPrintingSchema;
        private System.Windows.Forms.ListView lstContacts;
        private System.Windows.Forms.ColumnHeader colID;
        private System.Windows.Forms.ColumnHeader colName;
        private System.Windows.Forms.ColumnHeader colMobile;
        private System.Windows.Forms.ColumnHeader colHomePhone;
        private System.Windows.Forms.ColumnHeader colOfficePhone;
        private System.Windows.Forms.ColumnHeader colEmail;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.Panel panelTools;
        private System.Windows.Forms.Button btnSave;
    }
}
using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmDialer : Form
    {
        string CID;
        Ras.RasConnection Mod;
        Timer Disconnector;

        public frmDialer(string CID)
        {
            InitializeComponent();
            this.CID = CID;
            GetDatas();
            Disconnector = new Timer();
            Disconnector.Interval = 70000;
            Disconnector.Tick += new EventHandler(StopDialing);
        }

        void GetDatas()
        {
            Program.Connection.CommandText = "select * from ContactsData where CIdentity=" + CID;
            System.Data.DataTable Table = new System.Data.DataTable();
            Program.Connection.FillDataTable(Table, true);
            txtName.Text = Table.Rows[0]["Display"].ToString();
            if (Table.Rows[0]["Mobile"].ToString().Trim() != "") lstNumbers.Items.Add(Table.Rows[0]["Mobile"]);
            if (Table.Rows[0]["HomePhone"].ToString().Trim() != "") lstNumbers.Items.Add(Table.Rows[0]["HomePhone"]);
            if (Table.Rows[0]["OfficePhone"].ToString().Trim() != "") lstNumbers.Items.Add(Table.Rows[0]["OfficePhone"]);
            try { lstNumbers.SelectedIndex = 0; }
            catch { }
        }

        void StartDialing(object sender, EventArgs e)
        {
            Mod = new Ras.RasConnection();
            string Numb = txtPrefix.Text.Trim() + lstNumbers.Text;            
            Mod.PhoneNumber = Numb;
            Mod.Dial();
            MessageBox.Show("Dialing " + Numb); 
            btnDisconnect.Enabled = true;
            btnDial.Enabled = false;
            Disconnector.Enabled = true;
            FormClosing += new FormClosingEventHandler(DialerClosing);
        }

        void DialerClosing(object sender, FormClosingEventArgs e)
        {
            btnDisconnect.PerformClick();
        }

        void StopDialing(object sender, EventArgs e)
        {
            Mod.HandUp();
            btnDisconnect.Enabled = false;
            btnDial.Enabled = true;
            FormClosing -= DialerClosing;
            Disconnector.Enabled = false;
        }

        void ViewProperties(object sender, EventArgs e)
        {
            frmNewContact Property = new frmNewContact(false, CID, null);
            Property.ShowDialog();
        }
    }
}
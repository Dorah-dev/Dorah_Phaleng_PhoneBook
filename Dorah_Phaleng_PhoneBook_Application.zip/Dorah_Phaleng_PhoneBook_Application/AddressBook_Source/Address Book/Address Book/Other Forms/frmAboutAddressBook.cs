using System;
using System.Windows.Forms;

namespace AddressBook
{
    partial class frmAboutAddressBook : Form
    {
        public frmAboutAddressBook()
        {
            InitializeComponent();
        }

        void CloseForm(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
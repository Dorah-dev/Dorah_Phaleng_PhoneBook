namespace AddressBook
{
    partial class frmSettings
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSettings));
            this.lblHeader = new System.Windows.Forms.Label();
            this.gbDatabaseType = new System.Windows.Forms.GroupBox();
            this.optSQLDatabase = new System.Windows.Forms.RadioButton();
            this.optAccessDatabase = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.optRunatAUserStartup = new System.Windows.Forms.CheckBox();
            this.optRunatCUser = new System.Windows.Forms.CheckBox();
            this.optMySqlConnection = new System.Windows.Forms.RadioButton();
            this.gbDatabaseType.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.BackColor = System.Drawing.SystemColors.Info;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(358, 18);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Settings";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbDatabaseType
            // 
            this.gbDatabaseType.Controls.Add(this.optMySqlConnection);
            this.gbDatabaseType.Controls.Add(this.optSQLDatabase);
            this.gbDatabaseType.Controls.Add(this.optAccessDatabase);
            this.gbDatabaseType.Location = new System.Drawing.Point(6, 23);
            this.gbDatabaseType.Name = "gbDatabaseType";
            this.gbDatabaseType.Size = new System.Drawing.Size(344, 99);
            this.gbDatabaseType.TabIndex = 0;
            this.gbDatabaseType.TabStop = false;
            this.gbDatabaseType.Text = "Database Types";
            // 
            // optSQLDatabase
            // 
            this.optSQLDatabase.AutoSize = true;
            this.optSQLDatabase.Location = new System.Drawing.Point(179, 28);
            this.optSQLDatabase.Name = "optSQLDatabase";
            this.optSQLDatabase.Size = new System.Drawing.Size(95, 17);
            this.optSQLDatabase.TabIndex = 1;
            this.optSQLDatabase.TabStop = true;
            this.optSQLDatabase.Text = "SQL Database";
            this.optSQLDatabase.UseVisualStyleBackColor = true;
            // 
            // optAccessDatabase
            // 
            this.optAccessDatabase.AutoSize = true;
            this.optAccessDatabase.Location = new System.Drawing.Point(12, 28);
            this.optAccessDatabase.Name = "optAccessDatabase";
            this.optAccessDatabase.Size = new System.Drawing.Size(109, 17);
            this.optAccessDatabase.TabIndex = 0;
            this.optAccessDatabase.TabStop = true;
            this.optAccessDatabase.Text = "Access Database";
            this.optAccessDatabase.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Location = new System.Drawing.Point(179, 177);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.SaveSettings);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(275, 177);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.CancelSettings);
            // 
            // optRunatAUserStartup
            // 
            this.optRunatAUserStartup.AutoSize = true;
            this.optRunatAUserStartup.Location = new System.Drawing.Point(18, 145);
            this.optRunatAUserStartup.Name = "optRunatAUserStartup";
            this.optRunatAUserStartup.Size = new System.Drawing.Size(134, 17);
            this.optRunatAUserStartup.TabIndex = 3;
            this.optRunatAUserStartup.Text = "Run at All User Startup";
            this.optRunatAUserStartup.UseVisualStyleBackColor = true;
            this.optRunatAUserStartup.CheckedChanged += new System.EventHandler(this.AllUserStartUp_Checked);
            // 
            // optRunatCUser
            // 
            this.optRunatCUser.AutoSize = true;
            this.optRunatCUser.Location = new System.Drawing.Point(185, 145);
            this.optRunatCUser.Name = "optRunatCUser";
            this.optRunatCUser.Size = new System.Drawing.Size(155, 17);
            this.optRunatCUser.TabIndex = 4;
            this.optRunatCUser.Text = "Run at Current User startup";
            this.optRunatCUser.UseVisualStyleBackColor = true;
            // 
            // optMySqlConnection
            // 
            this.optMySqlConnection.AutoSize = true;
            this.optMySqlConnection.Location = new System.Drawing.Point(12, 64);
            this.optMySqlConnection.Name = "optMySqlConnection";
            this.optMySqlConnection.Size = new System.Drawing.Size(109, 17);
            this.optMySqlConnection.TabIndex = 2;
            this.optMySqlConnection.TabStop = true;
            this.optMySqlConnection.Text = "MySQL Database";
            this.optMySqlConnection.UseVisualStyleBackColor = true;
            // 
            // frmSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 219);
            this.Controls.Add(this.optRunatCUser);
            this.Controls.Add(this.optRunatAUserStartup);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbDatabaseType);
            this.Controls.Add(this.lblHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSettings";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Address Book - [Database Settings]";
            this.Load += new System.EventHandler(this.LoadSettings);
            this.gbDatabaseType.ResumeLayout(false);
            this.gbDatabaseType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox gbDatabaseType;
        private System.Windows.Forms.RadioButton optSQLDatabase;
        private System.Windows.Forms.RadioButton optAccessDatabase;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.CheckBox optRunatAUserStartup;
        private System.Windows.Forms.CheckBox optRunatCUser;
        private System.Windows.Forms.RadioButton optMySqlConnection;
    }
}
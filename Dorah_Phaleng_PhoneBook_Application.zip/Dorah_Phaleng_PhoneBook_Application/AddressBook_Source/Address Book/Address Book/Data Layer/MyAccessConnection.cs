using System;
using System.Data;
using System.Data.OleDb;
using System.Data.Common;

namespace AddressBook
{
    class MyAccessConnection : DataConnection
    {
        OleDbConnection Connection;
        OleDbCommand Command;
        
        string ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + DataSource + ";Persist Security Info=True;Jet OLEDB:Database Password=" + Password + ";";

        public MyAccessConnection()
        {
            (Command = new OleDbCommand()).Connection = Connection = new OleDbConnection(ConnectionString);
            ConnectionDistructor = new System.Timers.Timer(60000);
            GC.KeepAlive(ConnectionDistructor);
        }

        public override void FillDataTable(DataTable Table, bool Decrypt)
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();
            Status.Text = "1";
            try
            {
                Table.Rows.Clear();
                Table.Columns.Clear();
                new OleDbDataAdapter(Command).Fill(Table);
                //Table.Rows[1].ItemArray;
                if (Decrypt)
                {
                    int StartIndex = 0;
                    try
                    {
                        if (Table.Rows.Count > 0)
                            Converter.Decrypt(Table.Rows[0][0].ToString());
                        if (Table.Rows.Count > 1)
                            Converter.Decrypt(Table.Rows[1][0].ToString());
                    }
                    catch { StartIndex++; }
                    for (int i = StartIndex; i < Table.Columns.Count; i++) for (int j = 0; j < Table.Rows.Count; j++)
                            Table.Rows[j][i] = Converter.Decrypt(Table.Rows[j][i].ToString());
                }
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override object ExecuteNonQuery()
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();
            Status.Text = "1";
            try
            {
                return Command.ExecuteNonQuery();
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override string CommandText
        {
            set
            {
                Command.CommandText = value;
            }
        }

        public override void AddParameter(string Name, object Value)
        {
            AddParameter(Name, Value, true);
        }

        public override void AddParameter(string Name, object Value, bool Encrypt)
        {
            if (Encrypt) Command.Parameters.Add(new OleDbParameter(Name, Converter.Encrypt(Value.ToString())));
            else Command.Parameters.Add(new OleDbParameter(Name, Value));
        }

        public override void Open()
        {
            Connection.Open();
        }

        public override void Close()
        {
            Connection.Close();
        }

        DataTable GetTableList()
        {
            try
            {
                DataTable Table = null;
                // Microsoft Access provider factory            
                DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.OleDb");                

                using (DbConnection connection = factory.CreateConnection())
                {
                    connection.ConnectionString = ConnectionString;
                    // We only want user tables, not system tables
                    string[] restrictions = new string[4];
                    restrictions[3] = "Table";
                    connection.Open();
                    // Get list of user tables
                    Table = connection.GetSchema("Tables", restrictions);
                    return Table;
                }
            }
            catch (Exception Ex) { System.Windows.Forms.MessageBox.Show("Could not connect to database.\n\nReason:\n\n" + Ex.Message); }
            return null;
        }

        public override void InitialiseDatabase()
        {
            DataTable Table = GetTableList();

            bool[] TableCont = new bool[5];
            if(Table != null)
            foreach (DataRow Row in Table.Rows)
            {
                if (Row[2].ToString() == "ContactsData") TableCont[0] = true;
                else if (Row[2].ToString() == "ContactsUserAccount") TableCont[1] = true;
                else if (Row[2].ToString() == "BkfSchemas") TableCont[2] = true;
                else if (Row[2].ToString() == "ContactsCategorys") TableCont[3] = true;
                else if (Row[2].ToString() == "ContactsReminder") TableCont[4] = true;
            }

            if (!TableCont[0])
            {
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\ContactsData.acc");
                Command.CommandText = Sr.ReadToEnd();
                Sr.Close(); Sr = null;
                Command.ExecuteNonQuery();
            }

            if (!TableCont[1])
            {
                Command.CommandText = "create table ContactsUserAccount (UserID counter, AllowLogin text, UserName text, UserPassword text, UserType text, Created text, Modified text, LastLogin text, Status text)";
                Command.ExecuteNonQuery();
            }

            if (!TableCont[2])
            {
                Command.CommandText = "create table BkfSchemas ( SchemaName text, UserID text, SchemaSet memo)";
                Command.ExecuteNonQuery();

                Command.CommandText = "insert into BkfSchemas values('" + Converter.Encrypt("Default Schema (All)") + "','EI', @Schem)";
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\DefaultSchema.xsd");
                AddParameter("@Schem", Sr.ReadToEnd(), false);
                Sr.Close(); Sr = null; Command.ExecuteNonQuery();
            }

            if (!TableCont[3])
            {
                Command.CommandText = "create table ContactsCategorys (CategoryID counter, CategoryName text, CategoryLocation text)";
                Command.ExecuteNonQuery();
            }

            if (!TableCont[4])
            {
                Command.CommandText = "create table ContactsReminder ( ReminderID counter,UserID text,ReminderName text,RemindOn text,Descripption memo )";
                Command.ExecuteNonQuery();
            }
        }
    }
}
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AddressBook
{
    public partial class frmSQLSetting : Form
    {
        SqlConnection ConnectDB;

        public frmSQLSetting()
        {
            InitializeComponent();
            lstAuthenticationType.SelectedIndex = 0;
            if (((ConnectionTypes)DataConnection.ConnectionType) == ConnectionTypes.SQLConnection)
            {
                txtDataSource.Text = DataConnection.DataSource;                
                txtUserName.Text = DataConnection.UserName;
                txtPassword.Text = DataConnection.Password;
                lstAuthenticationType.SelectedIndex = DataConnection.SQLAuthenticationType;
                GetDBNames();
                lstDatabaseList.SelectedItem = DataConnection.Database;
            }
        }

        void Authentication_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAuthenticationType.SelectedIndex == 0)
                txtUserName.Enabled = txtPassword.Enabled = false;
            else txtUserName.Enabled = txtPassword.Enabled = true;
        }

        void GetDBNames(object sender, EventArgs e)
        {
            GetDBNames();
        }

        void GetDBNames()
        {

            lstDatabaseList.Items.Clear();
            ConnectDB = new SqlConnection(GetConnectionString());
            try
            {
                ConnectDB.Open();
            }
            catch (Exception) { return; }
            SqlCommand ExecCmd = new SqlCommand("SELECT NAME FROM SYSDATABASES", ConnectDB);
            SqlDataReader Reader = ExecCmd.ExecuteReader();
            while (Reader.Read())
            {
                lstDatabaseList.Items.Add(Reader.GetString(0));
            }
            ConnectDB.Close();
        }

        string GetConnectionString()
        {
            if (lstAuthenticationType.SelectedIndex == 1)
                return "Data Source=" + txtDataSource.Text + ";Initial Catalog=master;User ID=" + txtUserName.Text + ";Password=" + txtPassword.Text;
            else return "Data Source=" + txtDataSource.Text + ";Initial Catalog=master;Integrated Security=True";
        }

        void SaveChanges(object sender, EventArgs e)
        {
            if (lstDatabaseList.SelectedItem == null) { MessageBox.Show("Please select a valid connection configuration.", "Invalid Connection"); return; }            
            DataConnection.ConnectionType = (int)ConnectionTypes.SQLConnection;
            DataConnection.SQLAuthenticationType = lstAuthenticationType.SelectedIndex;
            DataConnection.DataSource = txtDataSource.Text;
            DataConnection.Database = lstDatabaseList.SelectedItem.ToString();
            DataConnection.UserName = txtUserName.Text;
            DataConnection.Password = txtPassword.Text;
            DataConnection.SaveSettings();
        }

        void ChangesMade(object sender, EventArgs e)
        {
            lstDatabaseList.Items.Clear();
        }

        void Login_Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
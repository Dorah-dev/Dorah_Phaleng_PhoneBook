namespace AddressBook
{
    partial class frmAccessSettings
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblMDBFile = new System.Windows.Forms.Label();
            this.txtMDBFile = new System.Windows.Forms.TextBox();
            this.gbDBSettings = new System.Windows.Forms.GroupBox();
            this.btnTestConnection = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblDefPassword = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbDBSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.BackColor = System.Drawing.SystemColors.Info;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(472, 18);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Settings";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMDBFile
            // 
            this.lblMDBFile.AutoSize = true;
            this.lblMDBFile.Location = new System.Drawing.Point(7, 24);
            this.lblMDBFile.Name = "lblMDBFile";
            this.lblMDBFile.Size = new System.Drawing.Size(50, 13);
            this.lblMDBFile.TabIndex = 0;
            this.lblMDBFile.Text = "MDB File";
            // 
            // txtMDBFile
            // 
            this.txtMDBFile.Location = new System.Drawing.Point(110, 21);
            this.txtMDBFile.Name = "txtMDBFile";
            this.txtMDBFile.Size = new System.Drawing.Size(267, 20);
            this.txtMDBFile.TabIndex = 0;
            // 
            // gbDBSettings
            // 
            this.gbDBSettings.Controls.Add(this.btnTestConnection);
            this.gbDBSettings.Controls.Add(this.btnBrowse);
            this.gbDBSettings.Controls.Add(this.txtPassword);
            this.gbDBSettings.Controls.Add(this.lblDefPassword);
            this.gbDBSettings.Controls.Add(this.txtMDBFile);
            this.gbDBSettings.Controls.Add(this.lblMDBFile);
            this.gbDBSettings.Location = new System.Drawing.Point(12, 26);
            this.gbDBSettings.Name = "gbDBSettings";
            this.gbDBSettings.Size = new System.Drawing.Size(448, 89);
            this.gbDBSettings.TabIndex = 0;
            this.gbDBSettings.TabStop = false;
            this.gbDBSettings.Text = "Database Settings";
            // 
            // btnTestConnection
            // 
            this.btnTestConnection.Location = new System.Drawing.Point(313, 52);
            this.btnTestConnection.Name = "btnTestConnection";
            this.btnTestConnection.Size = new System.Drawing.Size(125, 23);
            this.btnTestConnection.TabIndex = 2;
            this.btnTestConnection.Text = "Test Connection";
            this.btnTestConnection.UseVisualStyleBackColor = true;
            this.btnTestConnection.Click += new System.EventHandler(this.TestConnection);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(383, 19);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(55, 23);
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.OpenMdb);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(110, 54);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(197, 20);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.Text = "********************";
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.Password_Changed);
            // 
            // lblDefPassword
            // 
            this.lblDefPassword.AutoSize = true;
            this.lblDefPassword.Location = new System.Drawing.Point(7, 57);
            this.lblDefPassword.Name = "lblDefPassword";
            this.lblDefPassword.Size = new System.Drawing.Size(90, 13);
            this.lblDefPassword.TabIndex = 0;
            this.lblDefPassword.Text = "Default Password";
            // 
            // btnSave
            // 
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Location = new System.Drawing.Point(282, 123);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.SaveChanges);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(374, 123);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.CancelSettings);
            // 
            // frmAccessSettings
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(472, 154);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbDBSettings);
            this.Controls.Add(this.lblHeader);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAccessSettings";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Address Book - [Access Connection Settings]";
            this.Load += new System.EventHandler(this.LoadDatas);
            this.gbDBSettings.ResumeLayout(false);
            this.gbDBSettings.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblMDBFile;
        private System.Windows.Forms.TextBox txtMDBFile;
        private System.Windows.Forms.GroupBox gbDBSettings;
        private System.Windows.Forms.Button btnTestConnection;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblDefPassword;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}
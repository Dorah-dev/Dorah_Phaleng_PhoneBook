using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace AddressBook
{
    class MySqlConnection : DataConnection
    {
        MySql.Data.MySqlClient.MySqlConnection Connection; MySqlCommand Command;

        public MySqlConnection()
        {
            (Command = new MySqlCommand()).Connection = Connection = new MySql.Data.MySqlClient.MySqlConnection(ConnectionString);
            ConnectionDistructor = new System.Timers.Timer(60000);
            GC.KeepAlive(ConnectionDistructor);
        }

        string ConnectionString
        {
            get
            {
                return String.Format("server={0};user id={1}; password={2}; database={3}; pooling=false", DataSource, UserName, Password, Database);
            }
        }

        public override void FillDataTable(DataTable Table, bool Decrypt)
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();
            Status.Text = "1";
            try
            {
                Table.Rows.Clear();
                Table.Columns.Clear();
                new MySql.Data.MySqlClient.MySqlDataAdapter(Command).Fill(Table);
                if (Decrypt)
                {
                    int StartIndex = 0;
                    try
                    {
                        if (Table.Rows.Count > 0)
                            Converter.Decrypt(Table.Rows[0][0].ToString());
                        if (Table.Rows.Count > 1)
                            Converter.Decrypt(Table.Rows[1][0].ToString());
                    }
                    catch { StartIndex++; }
                    for (int i = StartIndex; i < Table.Columns.Count; i++) for (int j = 0; j < Table.Rows.Count; j++)
                            Table.Rows[j][i] = Converter.Decrypt(Table.Rows[j][i].ToString());
                }
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override object ExecuteNonQuery()
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();            
            Status.Text = "1";
            try
            {
                return Command.ExecuteNonQuery();
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override string CommandText
        {
            set
            {
                Command.CommandText = value;
            }
        }

        public override void AddParameter(string Name, object Value)
        {
            AddParameter(Name, Value, true);
        }

        public override void AddParameter(string Name, object Value, bool Encrypt)
        {
            if (Encrypt) Command.Parameters.Add(new MySqlParameter(Name, Converter.Encrypt(Value.ToString())));
            else Command.Parameters.Add(new MySqlParameter(Name, Value));
        }

        public override void Open()
        {
            Connection.Open();
        }

        public override void Close()
        {
            Connection.Close();
        }

        public override void InitialiseDatabase()
        {
            Command.CommandText = "SHOW TABLES";
            DataTable Table = new DataTable();
            FillDataTable(Table, false);

            bool[] TableCont = new bool[5];

            foreach (DataRow Row in Table.Rows)
            {
                if (Row[0].ToString().ToLower() == "contactsdata") TableCont[0] = true;
                else if (Row[0].ToString().ToLower() == "contactsuseraccount") TableCont[1] = true;
                else if (Row[0].ToString().ToLower() == "bkfschemas") TableCont[2] = true;
                else if (Row[0].ToString().ToLower() == "contactscategorys") TableCont[3] = true;
                else if (Row[0].ToString().ToLower() == "contactsreminder") TableCont[4] = true;
            }

            if (!TableCont[0])
            {
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\ContactsData.sql");
                Command.CommandText = Sr.ReadToEnd().Replace("identity constraint pk_ContactsData_CID", "AUTO_INCREMENT").Replace("varchar(500)", "text(500)").Replace("varchar(600)", "text(600)").Replace("varchar(300)", "text(300)").Replace("varchar(1500)", "text(1500)").Replace("varchar(1000)", "text(1000)");
                Sr.Close(); Sr = null;
                Command.ExecuteNonQuery();
            }

            if (!TableCont[1])
            {
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\ContactsUserAccount.sql");
                Command.CommandText = Sr.ReadToEnd().Replace("identity constraint pk_ContactsUserID", "AUTO_INCREMENT");
                Sr.Close(); Sr = null;
                Command.ExecuteNonQuery();
            }

            if (!TableCont[2])
            {
                Command.CommandText = "create table BkfSchemas (\n SchemaName varchar(150),\n UserID varchar(15),\n SchemaSet text(4000))";
                Command.ExecuteNonQuery();

                Command.CommandText = "insert into Bkfschemas values('" + Converter.Encrypt("Default Schema (All)") + "','EI', @Schem)";
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\DefaultSchema.xsd");
                AddParameter("@Schem", Sr.ReadToEnd(), false);
                Sr.Close(); Sr = null; Command.ExecuteNonQuery();
            }

            if (!TableCont[3])
            {
                Command.CommandText = "create table ContactsCategorys (CategoryID  int AUTO_INCREMENT PRIMARY KEY, CategoryName varchar(250), CategoryLocation varchar(10))";
                Command.ExecuteNonQuery();
            }

            if (!TableCont[4])
            {
                Command.CommandText = "create table ContactsReminder ( ReminderID int AUTO_INCREMENT PRIMARY KEY,UserID varchar(15),ReminderName varchar(150),RemindOn varchar(210),Descripption varchar(300) )";
                Command.ExecuteNonQuery();
            }
        }
    }
}
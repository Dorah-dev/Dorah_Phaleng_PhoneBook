using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmAccessSettings : Form
    {
        string Password;

        public frmAccessSettings()
        {
            InitializeComponent();
        }
        
        void OpenMdb(object sender, EventArgs e)
        {
            OpenFileDialog OFD = new OpenFileDialog();
            OFD.Filter = "Microsoft Office Access Database (*.mdb)|*.mdb";
            OFD.ShowDialog();
            txtMDBFile.Text = OFD.FileName;
        }

        void TestConnection(object sender, EventArgs e)
        {
            if(TestConnection())
            MessageBox.Show("Test Connection Succeeded!", "Connection Opened");
        }

        bool TestConnection()
        {
            if (txtMDBFile.Text.Length == 0) { MessageBox.Show("Select the Microsoft Access Database to store data and then try again."); return false; }
            System.Data.OleDb.OleDbConnection Connection = new System.Data.OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+ txtMDBFile.Text+";Persist Security Info=True;Jet OLEDB:Database Password=" + Password + ";");
            try
            {
                Connection.Open();
                Connection.Close();
                Connection = null;
                return true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Test Connection Failed.Could not connect to specified database.\n\nError Message:\n" + Ex.Message, "Access Denied");
                Connection = null;
                return false;
            }
        }

        void SaveChanges(object sender, EventArgs e)
        {
            if (TestConnection())
            {
                DataConnection.ConnectionType = (int)ConnectionTypes.AccessConnection;
                DataConnection.DataSource = txtMDBFile.Text;
                DataConnection.Password = Password;
                DataConnection.SaveSettings();
                this.Close();
            }
        }

        void Password_Changed(object sender, EventArgs e)
        {
            Password = txtPassword.Text;
        }

        void CancelSettings(object sender, EventArgs e)
        {
            this.Close();
        }

        void LoadDatas(object sender, EventArgs e)
        {
            txtMDBFile.Text = DataConnection.DataSource;
            Password = DataConnection.Password;
        }
    }
}
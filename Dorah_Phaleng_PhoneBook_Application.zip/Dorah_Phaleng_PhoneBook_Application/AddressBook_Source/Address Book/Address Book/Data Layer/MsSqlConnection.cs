using System;
using System.Data;
using System.Data.SqlClient;

namespace AddressBook
{
    class MsSqlConnection : DataConnection
    {
        SqlConnection Connection; SqlCommand Command;

        public MsSqlConnection()
        {
            (Command = new SqlCommand()).Connection = Connection = new SqlConnection(ConnectionString);
            ConnectionDistructor = new System.Timers.Timer(60000);
            GC.KeepAlive(ConnectionDistructor);
        }

        string ConnectionString
        {
            get
            {
                if (SQLAuthenticationType == 0)
                    return "Data Source=" + DataSource + "; Initial Catalog=" + Database + ";Integrated Security=True";
                return "Data Source=" + DataSource + "; Initial Catalog=" + Database + "; User Id=" + UserName + "; Password=" + Password + ";";
            }
        }

        public override void FillDataTable(DataTable Table, bool Decrypt)
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();
            Status.Text = "1";
            try
            {
                Table.Rows.Clear();
                Table.Columns.Clear();
                new SqlDataAdapter(Command).Fill(Table);
                if (Decrypt)
                {
                    int StartIndex = 0;
                    try
                    {
                        if (Table.Rows.Count > 0)
                            Converter.Decrypt(Table.Rows[0][0].ToString());
                        if (Table.Rows.Count > 1)
                            Converter.Decrypt(Table.Rows[1][0].ToString());
                    }
                    catch { StartIndex++; }
                    //Table.Rows[0].ItemArray;
                    if(Table.Rows.Count > 0)
                    for (int i = StartIndex; i < Table.Columns.Count; i++) for (int j = 0; j < Table.Rows.Count; j++)
                            Table.Rows[j][i] = Converter.Decrypt(Table.Rows[j][i].ToString());
                }
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override object ExecuteNonQuery()
        {
            ConnectionDistructor.Enabled = false;
            if (Connection.State == System.Data.ConnectionState.Closed) Connection.Open();
            Status.Text = "1";
            try
            {
                return Command.ExecuteNonQuery();
            }
            catch (Exception Ex) { throw Ex; }
            finally { Command.Parameters.Clear(); ConnectionDistructor.Enabled = true; }
        }

        public override string CommandText
        {
            set
            {
                Command.CommandText = value;
            }
        }

        public override void AddParameter(string Name, object Value)
        {
            AddParameter(Name, Value, true);
        }

        public override void AddParameter(string Name, object Value, bool Encrypt)
        {
            if (Encrypt) Command.Parameters.Add(new SqlParameter(Name, Converter.Encrypt(Value.ToString())));
            else Command.Parameters.Add(new SqlParameter(Name, Value));
        }

        public override void Open()
        {
            Connection.Open();
        }

        public override void Close()
        {
            Connection.Close();
        }

        public override void InitialiseDatabase()
        {
            Command.CommandText = "select Name from sysobjects where type='u' and Name in ('ContactsData','ContactsUserAccount','Schemas','ContactsCategorys', 'ContactsReminder')";
            DataTable Table = new DataTable();
            FillDataTable(Table, false);

            if (Table.Rows.Count == 5) return;

            bool[] TableCont = new bool[5];

            foreach (DataRow Row in Table.Rows)
            {
                if (Row[0].ToString() == "ContactsData") TableCont[0] = true;
                else if (Row[0].ToString() == "ContactsUserAccount") TableCont[1] = true;
                else if (Row[0].ToString() == "BkfSchemas") TableCont[2] = true;
                else if (Row[0].ToString() == "ContactsCategorys") TableCont[3] = true;
                else TableCont[4] = true;
            }

            if (!TableCont[0])
            {
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\ContactsData.sql");
                Command.CommandText = Sr.ReadToEnd();
                Sr.Close(); Sr = null;
                Command.ExecuteNonQuery();
            }

            if (!TableCont[1])
            {
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\ContactsUserAccount.sql");
                Command.CommandText = Sr.ReadToEnd();
                Sr.Close(); Sr = null;
                Command.ExecuteNonQuery();
            }

            if (!TableCont[2])
            {
                Command.CommandText = "create table BkfSchemas ( SchemaName varchar(150), UserID varchar(15), SchemaSet varchar(max))";
                Command.ExecuteNonQuery();

                Command.CommandText = "insert into BkfSchemas values('" + Converter.Encrypt("Default Schema (All)") + "','EI', @Schem)";
                System.IO.StreamReader Sr = new System.IO.StreamReader(System.Windows.Forms.Application.StartupPath + "\\DefaultSchema.xsd");
                AddParameter("@Schem", Sr.ReadToEnd(), false);
                Sr.Close(); Sr = null; Command.ExecuteNonQuery();
            }

            if (!TableCont[3])
            {
                Command.CommandText = "create table ContactsCategorys (CategoryID int identity, CategoryName varchar(250), CategoryLocation varchar(10))";
                Command.ExecuteNonQuery();
            }

            if (!TableCont[4])
            {
                Command.CommandText = "create table ContactsReminder ( ReminderID int identity,UserID varchar(15),ReminderName varchar(150),RemindOn varchar(210),Descripption varchar(300), )";
                Command.ExecuteNonQuery();
            }
        }
    }
}
using System;
using System.IO;
using System.Data;

namespace AddressBook
{
    public enum ConnectionTypes
    {
        AccessConnection,
        SQLConnection,
        MySQLConnection
    }

    class DataConnection
    {
        public System.Timers.Timer ConnectionDistructor;
        public static System.Windows.Forms.TextBox Status = new System.Windows.Forms.TextBox();
        public static string DataSource = "";
        public static string Database = "";
        public static string UserName = "";
        public static string Password = "";
        public static int ConnectionType = -1;
        public static int SQLAuthenticationType;

        public static void SaveSettings()
        {
            StreamWriter SW = new StreamWriter(System.Windows.Forms.Application.StartupPath + "\\Settings.dat");
            SW.Write(Converter.Encrypt(DataSource));
            SW.Write("\n" + Converter.Encrypt(Database));
            SW.Write("\n" + Converter.Encrypt(UserName));
            SW.Write("\n" + Converter.Encrypt(Password));
            SW.Write("\n" + Converter.Encrypt(ConnectionType.ToString()));
            SW.Write("\n" + Converter.Encrypt(SQLAuthenticationType.ToString()));
            SW.Close(); SW = null;
            (Program.Connection = GetConnection()).Open();
            Program.Connection.InitialiseDatabase();
        }

        public static void GetSettings()
        {
            StreamReader SR = new StreamReader("Settings.dat");
            DataSource = Converter.Decrypt(SR.ReadLine());
            Database = Converter.Decrypt(SR.ReadLine());
            UserName = Converter.Decrypt(SR.ReadLine());
            Password = Converter.Decrypt(SR.ReadLine());
            ConnectionType = Convert.ToInt32(Converter.Decrypt(SR.ReadLine()));
            SQLAuthenticationType = Convert.ToInt32(Converter.Decrypt(SR.ReadLine()));
            SR.Close(); SR = null;
        }

        public static DataConnection GetConnection()
        {
            if (((ConnectionTypes)ConnectionType) == ConnectionTypes.AccessConnection)
                return new MyAccessConnection();
            if (((ConnectionTypes)ConnectionType) == ConnectionTypes.MySQLConnection)
                return new MySqlConnection(); return new MsSqlConnection();
        }

        public virtual void AddParameter(string Name, object Value) { }

        public virtual void AddParameter(string Name, object Value, bool Encrypt) { }

        public virtual void FillDataTable(DataTable Table, bool Decrypt) { }

        public virtual string CommandText { set { } }

        public virtual object ExecuteNonQuery()
        {
            return new object();
        }

        public virtual void Open() { }

        public virtual void Close() { }

        public virtual void InitialiseDatabase() { }
    }
}
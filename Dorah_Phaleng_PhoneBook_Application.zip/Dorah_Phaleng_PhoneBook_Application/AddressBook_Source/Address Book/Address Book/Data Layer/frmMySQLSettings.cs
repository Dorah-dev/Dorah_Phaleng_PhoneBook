using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmMySQLSetting : Form
    {
        MySql.Data.MySqlClient.MySqlConnection ConnectDB;

        public frmMySQLSetting()
        {
            InitializeComponent();
            if (((ConnectionTypes)DataConnection.ConnectionType) == ConnectionTypes.MySQLConnection)
            {
                txtDataSource.Text = DataConnection.DataSource;                
                txtUserName.Text = DataConnection.UserName;
                txtPassword.Text = DataConnection.Password;
                GetDBNames();
                lstDatabaseList.SelectedItem = DataConnection.Database;
            }
        }

        void GetDBNames(object sender, EventArgs e)
        {
            GetDBNames();
        }

        void GetDBNames()
        {

            lstDatabaseList.Items.Clear();
            ConnectDB = new MySql.Data.MySqlClient.MySqlConnection(ConnectionString);
            try
            {
                ConnectDB.Open();
            }
            catch (Exception) { return; }
            MySql.Data.MySqlClient.MySqlCommand ExecCmd = new MySql.Data.MySqlClient.MySqlCommand("SHOW DATABASES", ConnectDB);
            MySql.Data.MySqlClient.MySqlDataReader Reader = ExecCmd.ExecuteReader();
            while (Reader.Read())
            {
                lstDatabaseList.Items.Add(Reader.GetString(0));
            }
            ConnectDB.Close();
        }

        string ConnectionString
        {
            get
            {
                return "server=" + txtDataSource.Text + ";Database=MySql;User ID=" + txtUserName.Text + ";pooling=false;Password=" + txtPassword.Text;
            }
        }

        void SaveChanges(object sender, EventArgs e)
        {
            if (lstDatabaseList.SelectedItem == null) { MessageBox.Show("Please select a valid connection configuration.", "Invalid Connection"); return; }
            DataConnection.ConnectionType = (int)ConnectionTypes.MySQLConnection;
            DataConnection.DataSource = txtDataSource.Text;
            DataConnection.Database = lstDatabaseList.SelectedItem.ToString();
            DataConnection.UserName = txtUserName.Text;
            DataConnection.Password = txtPassword.Text;
            DataConnection.SaveSettings();
        }

        void ChangesMade(object sender, EventArgs e)
        {
            lstDatabaseList.Items.Clear();
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
using System;
using System.IO;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmUserAccount : Form
    {
        int[] AccountId;
        public frmUserAccount()
        {
            InitializeComponent();
            UpdateDatas();
        }

        void AddNewUser(object sender, EventArgs e)
        {
            frmAddUser NewUser = new frmAddUser();
            NewUser.ShowDialog();
            lstDatas.Items.Clear();
            UpdateDatas();
        }

        void EditUser(object sender, EventArgs e)
        {
            try
            {
                frmAddUser NewUser = new frmAddUser(Convert.ToString(AccountId[lstDatas.SelectedItems[0].Index]));
                NewUser.ShowDialog();
                UpdateDatas();
            }
            catch { }
        }

        void RemoveUser(object sender, EventArgs e)
        {
            if (lstDatas.SelectedItems.Count == 0) { MessageBox.Show("First select the account to be removed.", "No Selection"); return; }
            DialogResult DR = MessageBox.Show("Are you sure to delete the selected account permenantly?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (DR == DialogResult.No) return;
            string tempUserId;
            try
            {
                tempUserId = Convert.ToString(AccountId[lstDatas.SelectedItems[0].Index]);
            }
            catch { return; }

            if (tempUserId == UserPolicies.UserID) { MessageBox.Show("You cannot delete your own account. Use any other account with administrative rights to do it.", "Access Denied"); return; }

            DialogResult DRe = MessageBox.Show("Do you want to take a backup of all the contacts maintained by the account?", "Confirm Delete", MessageBoxButtons.YesNoCancel);
            if (DRe == DialogResult.Cancel) return;
            if (DRe == DialogResult.Yes)
            {
                frmBackup MyBackup = new frmBackup();
                MyBackup.RetriveSchema("Default Schema (All)");
                MyBackup.UserId = tempUserId;
                MyBackup.RetriveDatas(false);

                SaveFileDialog SFD = new SaveFileDialog();

                SFD.Filter = "AddressBook Backup File (*.cbk)|*.cbk";
                SFD.AddExtension = true;
                SFD.Title = "Save Backup As";
                SFD.DefaultExt = "*.cbk";
                SFD.ShowDialog();

                if (SFD.FileName.Length == 0) return;
                if (!SFD.FileName.EndsWith(".cbk")) SFD.FileName += ".cbk";

                Program.Connection.CommandText = "select * from ContactsUserAccount where UserId=" + tempUserId;
                System.Data.DataTable Table = new System.Data.DataTable();
                Program.Connection.FillDataTable(Table, true);
                if(Table.Rows.Count == 0)
                {
                    MessageBox.Show("Due to some problems Backup cannot be performed.", "Action Cancled");
                    return;
                }

                FileStream FS = new FileStream(SFD.FileName, FileMode.Create, FileAccess.Write);
                StreamWriter SW = new StreamWriter(FS);

                SW.Write(Converter.Encrypt("Backup Version: AddressBook v1.0"));

                    SW.Write("\n" + Converter.Encrypt("1"));
                    SW.Write("\n" + Converter.Encrypt(Table.Rows[0][2].ToString()));
                    SW.Write("\n" + Converter.Encrypt(Table.Rows[0][3].ToString()));
                MyBackup.DT.WriteXml("_Data.mdb");
                StreamReader SR = new StreamReader("_Data.mdb");
                string str = SR.ReadLine();
                while (str != null)
                {
                    SW.Write("\n" + Converter.Encrypt(str));
                    str = SR.ReadLine();
                }
                SR.Close();
                SW.Close();
                FS.Close();

                FileInfo FI = new FileInfo("_Data.mdb");
                FI.Delete(); FI = null;
            }

            Program.Connection.CommandText = "delete from ContactsUserAccount where UserID=" + tempUserId;
            Program.Connection.ExecuteNonQuery();

            Program.Connection.CommandText = "delete from ContactsData where UserID='" + Converter.Encrypt( tempUserId) + "'";
            Program.Connection.ExecuteNonQuery();

            Program.Connection.CommandText = "delete from ContactsReminder where UserID='" + Converter.Encrypt(tempUserId) + "'";
            Program.Connection.ExecuteNonQuery();

            Program.Connection.CommandText = "delete from BkfSchemas where UserID='" + Converter.Encrypt(tempUserId) + "'";
            Program.Connection.ExecuteNonQuery();

            UpdateDatas();
        }

        void CloseAccount(object sender, EventArgs e)
        {
            this.Close();
        }

        void UpdateDatas()
        {
            lstDatas.Items.Clear();
            Program.Connection.CommandText = "select * from ContactsUserAccount";
            System.Data.DataTable tempTable = new System.Data.DataTable();
            Program.Connection.FillDataTable(tempTable, true);

            ListBox LB = new ListBox();
            for (int i = 0; i < tempTable.Rows.Count;i++ )
                {
                    LB.Items.Add(tempTable.Rows[i][0].ToString());
                    string[] NewItem = new string[] { tempTable.Rows[i][2].ToString(), "Administrator" };
                    if (tempTable.Rows[i]["UserType"].ToString() == "1") NewItem[1] = "Limited User";
                    lstDatas.Items.Add(new ListViewItem(NewItem));
                }
            AccountId = new int[LB.Items.Count];
            for (int i = 0; i < LB.Items.Count; i++)
            {
                AccountId[i] = Convert.ToInt32(LB.Items[i].ToString());
            }
        }
    }
}
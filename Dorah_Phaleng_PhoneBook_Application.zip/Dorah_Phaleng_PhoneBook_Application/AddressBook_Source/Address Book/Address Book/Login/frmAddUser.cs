using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmAddUser : Form
    {
        string UserId;
        string PassWd;
        bool PwdChanged = false;
        bool AddNew = false;
        public frmAddUser()
        {
            InitializeComponent();
            txtUserType.SelectedIndex = 0;
            btnSaveChanges.Text = "Add User";
            Header.Text = "Add New User";
            AddNew = true;
            txtCreated.Text = DateTime.Now.ToLongDateString() + "  " + DateTime.Now.ToLongTimeString();
            txtNewPassword.TextChanged += new EventHandler(PwdChanged_Chd);
        }

        public frmAddUser(string UserIndex)
        {
            InitializeComponent();
            Header.Text = "Edit User";
            this.UserId = UserIndex;
            txtUserType.Enabled = UserIndex != UserPolicies.UserID;
            AddNew = false;
            RetriveDatas();
        }

        void RetriveDatas()
        {
            Program.Connection.CommandText = "select * from ContactsUserAccount where UserID=" + UserId;
            System.Data.DataTable Table = new System.Data.DataTable();
            Program.Connection.FillDataTable(Table, true);

            int tempStr = Convert.ToInt32(Table.Rows[0][1]);
            txtAllowLogin.Checked = true;
            if (tempStr == 0) txtAllowLogin.Checked = false;
            txtUserType.SelectedIndex = Convert.ToInt32(Table.Rows[0]["UserType"]);
            txtUserName.Text = Table.Rows[0][2].ToString();;
            PassWd = Table.Rows[0][3].ToString();
            txtNewPassword.Text = txtConfPassword.Text = "***************";
            txtCreated.Text = Table.Rows[0][5].ToString(); ;
            txtNewPassword.TextChanged += new EventHandler(PwdChanged_Chd);
            if ((txtDateModified.Text = Table.Rows[0][6].ToString()) == "")
                txtDateModified.Text = "_____________________________";

            if ((txtLastLogin.Text = Table.Rows[0][7].ToString()) == "")
                txtLastLogin.Text = "_____________________________";
        }

        void AddUserList(object sender, EventArgs e)
        {
            #region Check Accuracy
            if (txtUserName.Text.Trim().Length <= 4)
            {
                MessageBox.Show("The User Name cannot be lesser than 5 chars.", "Update Failed");
                return;
            }
            if (txtNewPassword.Text.Length <= 4)
            {
                MessageBox.Show("The Password cannot be lesser than 5 chars.", "Update Failed");
                return;
            }
            if (txtNewPassword.Text != txtConfPassword.Text)
            {
                MessageBox.Show("The New Password and Conf Password must be the same.", "Update Failed");
                return;
            }

            if(PwdChanged)PassWd = txtNewPassword.Text;
            #endregion

            System.Data.DataTable Table = new System.Data.DataTable();

            if (AddNew)
                Program.Connection.CommandText = "select * from ContactsUserAccount where UserName='" + Converter.Encrypt(txtUserName.Text.ToUpper()) + "'";
            else
                Program.Connection.CommandText = "select * from ContactsUserAccount where UserName='" + Converter.Encrypt(txtUserName.Text.ToUpper()) + "' and UserID not in (" + UserId + ")";

            Program.Connection.FillDataTable(Table, true);

            if (Table.Rows.Count != 0) { MessageBox.Show("The User Name specified already exist. Specify different User Name"); return; }

            if (txtUserType.SelectedIndex != 0)
            {
                Program.Connection.CommandText = "select * from ContactsUserAccount where UserType='" + Converter.Encrypt("0") + "'";
                Program.Connection.FillDataTable(Table, true);
                if (Table.Rows.Count == 0) { MessageBox.Show("Atleast one Administrator account is required. This account must be set as Administrator"); return; }
            }

            if (AddNew) Program.Connection.CommandText = "insert into ContactsUserAccount(AllowLogin,UserName,UserPassword,UserType,Created) values(@AllowLogin,@UserName,@UserPassword,@UserType,@Created)";
            else Program.Connection.CommandText = "update ContactsUserAccount set AllowLogin=@AllowLogin,UserName=@UserName,UserPassword=@UserPassword,UserType=@UserType,Modified=@Modified where UserID=" + UserId;


            string AllowLog = "0";
            if (txtAllowLogin.Checked) AllowLog = "1";
            
            Program.Connection.AddParameter("@AllowLogin", AllowLog);
            Program.Connection.AddParameter("@UserName", txtUserName.Text.ToUpper());
            Program.Connection.AddParameter("@UserPassword", PassWd);
            Program.Connection.AddParameter("@UserType", txtUserType.SelectedIndex.ToString());
            if(AddNew)
                Program.Connection.AddParameter("@Created", txtCreated.Text);
            else
                Program.Connection.AddParameter("@Modified", DateTime.Now.ToLongDateString() + "  " + DateTime.Now.ToLongTimeString());

            Program.Connection.ExecuteNonQuery();
            Close();
        }

        void CloseForm(object sender, EventArgs e)
        {
            this.Close();
        }

        void PwdChanged_Chd(object sender, EventArgs e)
        {
            PwdChanged = true;
        }

        void UserTypeChanged(object sender, EventArgs e)
        {
            if (txtUserType.SelectedIndex == 0) txtAllowLogin.Enabled = false;
            else txtAllowLogin.Enabled = true;
            txtAllowLogin.Checked = true;
        }
    }
}
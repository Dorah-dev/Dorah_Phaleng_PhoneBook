namespace AddressBook
{
    partial class frmAddUser
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddUser));
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblConfPassword = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.txtConfPassword = new System.Windows.Forms.TextBox();
            this.txtUserType = new System.Windows.Forms.ComboBox();
            this.Header = new System.Windows.Forms.Label();
            this.btnSaveChanges = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtAllowLogin = new System.Windows.Forms.CheckBox();
            this.lblCreated = new System.Windows.Forms.Label();
            this.lblModified = new System.Windows.Forms.Label();
            this.lblLastLogin = new System.Windows.Forms.Label();
            this.txtDateModified = new System.Windows.Forms.Label();
            this.txtCreated = new System.Windows.Forms.Label();
            this.txtLastLogin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(4, 44);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(60, 13);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "User Name";
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Location = new System.Drawing.Point(4, 105);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(78, 13);
            this.lblNewPassword.TabIndex = 0;
            this.lblNewPassword.Text = "New Password";
            // 
            // lblConfPassword
            // 
            this.lblConfPassword.AutoSize = true;
            this.lblConfPassword.Location = new System.Drawing.Point(4, 135);
            this.lblConfPassword.Name = "lblConfPassword";
            this.lblConfPassword.Size = new System.Drawing.Size(78, 13);
            this.lblConfPassword.TabIndex = 0;
            this.lblConfPassword.Text = "Conf Password";
            // 
            // lblUserType
            // 
            this.lblUserType.AutoSize = true;
            this.lblUserType.Location = new System.Drawing.Point(4, 74);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(56, 13);
            this.lblUserType.TabIndex = 0;
            this.lblUserType.Text = "User Type";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(89, 41);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(165, 20);
            this.txtUserName.TabIndex = 0;
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(89, 102);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(165, 20);
            this.txtNewPassword.TabIndex = 2;
            this.txtNewPassword.UseSystemPasswordChar = true;
            // 
            // txtConfPassword
            // 
            this.txtConfPassword.Location = new System.Drawing.Point(89, 132);
            this.txtConfPassword.Name = "txtConfPassword";
            this.txtConfPassword.Size = new System.Drawing.Size(165, 20);
            this.txtConfPassword.TabIndex = 3;
            this.txtConfPassword.UseSystemPasswordChar = true;
            // 
            // txtUserType
            // 
            this.txtUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtUserType.FormattingEnabled = true;
            this.txtUserType.Items.AddRange(new object[] {
            "Administrator",
            "Limited User"});
            this.txtUserType.Location = new System.Drawing.Point(89, 71);
            this.txtUserType.Name = "txtUserType";
            this.txtUserType.Size = new System.Drawing.Size(165, 21);
            this.txtUserType.TabIndex = 1;
            this.txtUserType.SelectedIndexChanged += new System.EventHandler(this.UserTypeChanged);
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Header.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Header.Location = new System.Drawing.Point(0, 0);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(603, 26);
            this.Header.TabIndex = 0;
            this.Header.Text = "Add or Edit User";
            this.Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaveChanges
            // 
            this.btnSaveChanges.Location = new System.Drawing.Point(129, 172);
            this.btnSaveChanges.Name = "btnSaveChanges";
            this.btnSaveChanges.Size = new System.Drawing.Size(125, 23);
            this.btnSaveChanges.TabIndex = 5;
            this.btnSaveChanges.Text = "Change";
            this.btnSaveChanges.UseVisualStyleBackColor = true;
            this.btnSaveChanges.Click += new System.EventHandler(this.AddUserList);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(276, 172);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(125, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.CloseForm);
            // 
            // txtAllowLogin
            // 
            this.txtAllowLogin.AutoSize = true;
            this.txtAllowLogin.Checked = true;
            this.txtAllowLogin.CheckState = System.Windows.Forms.CheckState.Checked;
            this.txtAllowLogin.Location = new System.Drawing.Point(276, 134);
            this.txtAllowLogin.Name = "txtAllowLogin";
            this.txtAllowLogin.Size = new System.Drawing.Size(120, 17);
            this.txtAllowLogin.TabIndex = 4;
            this.txtAllowLogin.Text = "Allow User to Login.";
            this.txtAllowLogin.UseVisualStyleBackColor = true;
            // 
            // lblCreated
            // 
            this.lblCreated.AutoSize = true;
            this.lblCreated.Location = new System.Drawing.Point(273, 44);
            this.lblCreated.Name = "lblCreated";
            this.lblCreated.Size = new System.Drawing.Size(44, 13);
            this.lblCreated.TabIndex = 0;
            this.lblCreated.Text = "Created";
            // 
            // lblModified
            // 
            this.lblModified.AutoSize = true;
            this.lblModified.Location = new System.Drawing.Point(273, 74);
            this.lblModified.Name = "lblModified";
            this.lblModified.Size = new System.Drawing.Size(47, 13);
            this.lblModified.TabIndex = 0;
            this.lblModified.Text = "Modified";
            // 
            // lblLastLogin
            // 
            this.lblLastLogin.AutoSize = true;
            this.lblLastLogin.Location = new System.Drawing.Point(273, 105);
            this.lblLastLogin.Name = "lblLastLogin";
            this.lblLastLogin.Size = new System.Drawing.Size(56, 13);
            this.lblLastLogin.TabIndex = 0;
            this.lblLastLogin.Text = "Last Login";
            // 
            // txtDateModified
            // 
            this.txtDateModified.AutoSize = true;
            this.txtDateModified.Location = new System.Drawing.Point(355, 74);
            this.txtDateModified.Name = "txtDateModified";
            this.txtDateModified.Size = new System.Drawing.Size(181, 13);
            this.txtDateModified.TabIndex = 0;
            this.txtDateModified.Text = "_____________________________";
            // 
            // txtCreated
            // 
            this.txtCreated.AutoSize = true;
            this.txtCreated.Location = new System.Drawing.Point(355, 44);
            this.txtCreated.Name = "txtCreated";
            this.txtCreated.Size = new System.Drawing.Size(181, 13);
            this.txtCreated.TabIndex = 0;
            this.txtCreated.Text = "_____________________________";
            // 
            // txtLastLogin
            // 
            this.txtLastLogin.AutoSize = true;
            this.txtLastLogin.Location = new System.Drawing.Point(355, 105);
            this.txtLastLogin.Name = "txtLastLogin";
            this.txtLastLogin.Size = new System.Drawing.Size(181, 13);
            this.txtLastLogin.TabIndex = 0;
            this.txtLastLogin.Text = "_____________________________";
            // 
            // frmAddUser
            // 
            this.AcceptButton = this.btnSaveChanges;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(603, 213);
            this.ControlBox = false;
            this.Controls.Add(this.txtLastLogin);
            this.Controls.Add(this.txtCreated);
            this.Controls.Add(this.txtDateModified);
            this.Controls.Add(this.lblLastLogin);
            this.Controls.Add(this.lblModified);
            this.Controls.Add(this.lblCreated);
            this.Controls.Add(this.txtAllowLogin);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSaveChanges);
            this.Controls.Add(this.Header);
            this.Controls.Add(this.txtUserType);
            this.Controls.Add(this.txtConfPassword);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.lblUserType);
            this.Controls.Add(this.lblConfPassword);
            this.Controls.Add(this.lblNewPassword);
            this.Controls.Add(this.lblUserName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmAddUser";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add User";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblConfPassword;
        private System.Windows.Forms.Label lblUserType;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.TextBox txtConfPassword;
        private System.Windows.Forms.ComboBox txtUserType;
        private System.Windows.Forms.Label Header;
        private System.Windows.Forms.Button btnSaveChanges;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.CheckBox txtAllowLogin;
        private System.Windows.Forms.Label lblCreated;
        private System.Windows.Forms.Label lblModified;
        private System.Windows.Forms.Label lblLastLogin;
        private System.Windows.Forms.Label txtDateModified;
        private System.Windows.Forms.Label txtCreated;
        private System.Windows.Forms.Label txtLastLogin;
    }
}
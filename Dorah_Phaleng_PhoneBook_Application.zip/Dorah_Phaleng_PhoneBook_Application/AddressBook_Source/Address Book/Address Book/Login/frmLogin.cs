using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        void CheckLogin(object sender, EventArgs e)
        {
            if (txtUserName.Text.Length == 0 || txtPassword.Text.Length == 0)
            {
                MessageBox.Show("The User Name and or Password cannot be blank.", "Login Failed");
                return;
            }
            System.Data.DataTable Table = new System.Data.DataTable();
            Program.Connection.CommandText = "select * from ContactsUserAccount where UserName='" + Converter.Encrypt(txtUserName.Text.ToUpper()) + "'";
            Program.Connection.FillDataTable(Table, true);

            if (Table.Rows.Count == 0)
            {
                MessageBox.Show("The specified user cannot be found.");
                return;
            }

            string CUPassword = Table.Rows[0][3].ToString();

            if (CUPassword != txtPassword.Text)
            {
                MessageBox.Show("Invalid Password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UserPolicies.Password = CUPassword;
            if (Table.Rows[0][1].ToString() == "0") { MessageBox.Show("Your account had been disabled by your Administrator.", "Login Failed"); return; }
            if (Table.Rows[0][4].ToString() == "0") UserPolicies.IsAdministrator = true;
            else UserPolicies.IsAdministrator = false;

            UserPolicies.UserName = txtUserName.Text.ToUpper();
            UserPolicies.UserID = Table.Rows[0][0].ToString();
            UserPolicies.IsLoggedIn = true;
            Program.Connection.CommandText = "update ContactsUserAccount set LastLogin='" + Converter.Encrypt(DateTime.Now.ToLongDateString() + "  " + DateTime.Now.ToLongTimeString()) + "', Status='" + Converter.Encrypt("Logged In") + "' where UserID=" + UserPolicies.UserID;
            Program.Connection.ExecuteNonQuery();
            this.Close();
        }

        void ExitApplication(object sender, EventArgs e)
        {
            Close();
        }

        void CheckData(object sender, EventArgs e)
        {
            System.Data.DataTable Table;
        CheckAccountExist:
            Table = new System.Data.DataTable();
            Program.Connection.CommandText = "select * from ContactsUserAccount";
            Program.Connection.FillDataTable(Table, true);

            if (Table.Rows.Count == 0)
            {
                if (MessageBox.Show("You need to add User to login. Do you want to add it now?", "No User Found", MessageBoxButtons.YesNo) == DialogResult.No)
                { MessageBox.Show("Action Cancled... Login Failed."); this.Close(); return; }
                frmUserAccount ShowUserAccount = new frmUserAccount();
                ShowUserAccount.ShowDialog();
                goto CheckAccountExist;
            }
        }
    }
}
namespace AddressBook
{
    partial class frmUserAccount
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUserAccount));
            this.Bt_Add = new System.Windows.Forms.Button();
            this.Bt_Edit = new System.Windows.Forms.Button();
            this.Bt_Remove = new System.Windows.Forms.Button();
            this.Bt_Cancel = new System.Windows.Forms.Button();
            this.lstDatas = new System.Windows.Forms.ListView();
            this.UserName = new System.Windows.Forms.ColumnHeader();
            this.UserType = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // Bt_Add
            // 
            this.Bt_Add.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Bt_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_Add.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Add.Image")));
            this.Bt_Add.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Bt_Add.Location = new System.Drawing.Point(9, 162);
            this.Bt_Add.Name = "Bt_Add";
            this.Bt_Add.Size = new System.Drawing.Size(60, 50);
            this.Bt_Add.TabIndex = 1;
            this.Bt_Add.Text = "Add";
            this.Bt_Add.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Bt_Add.UseVisualStyleBackColor = false;
            this.Bt_Add.Click += new System.EventHandler(this.AddNewUser);
            // 
            // Bt_Edit
            // 
            this.Bt_Edit.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Bt_Edit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bt_Edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_Edit.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Edit.Image")));
            this.Bt_Edit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Bt_Edit.Location = new System.Drawing.Point(112, 162);
            this.Bt_Edit.Name = "Bt_Edit";
            this.Bt_Edit.Size = new System.Drawing.Size(60, 50);
            this.Bt_Edit.TabIndex = 2;
            this.Bt_Edit.Text = "Edit";
            this.Bt_Edit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Bt_Edit.UseVisualStyleBackColor = false;
            this.Bt_Edit.Click += new System.EventHandler(this.EditUser);
            // 
            // Bt_Remove
            // 
            this.Bt_Remove.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Bt_Remove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Bt_Remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_Remove.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Remove.Image")));
            this.Bt_Remove.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Bt_Remove.Location = new System.Drawing.Point(218, 162);
            this.Bt_Remove.Name = "Bt_Remove";
            this.Bt_Remove.Size = new System.Drawing.Size(60, 50);
            this.Bt_Remove.TabIndex = 3;
            this.Bt_Remove.Text = "Remove";
            this.Bt_Remove.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Bt_Remove.UseVisualStyleBackColor = false;
            this.Bt_Remove.Click += new System.EventHandler(this.RemoveUser);
            // 
            // Bt_Cancel
            // 
            this.Bt_Cancel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Bt_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bt_Cancel.Image = ((System.Drawing.Image)(resources.GetObject("Bt_Cancel.Image")));
            this.Bt_Cancel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Bt_Cancel.Location = new System.Drawing.Point(324, 162);
            this.Bt_Cancel.Name = "Bt_Cancel";
            this.Bt_Cancel.Size = new System.Drawing.Size(60, 50);
            this.Bt_Cancel.TabIndex = 5;
            this.Bt_Cancel.Text = "Close";
            this.Bt_Cancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Bt_Cancel.UseVisualStyleBackColor = false;
            this.Bt_Cancel.Click += new System.EventHandler(this.CloseAccount);
            // 
            // lstDatas
            // 
            this.lstDatas.AutoArrange = false;
            this.lstDatas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.UserName,
            this.UserType});
            this.lstDatas.Dock = System.Windows.Forms.DockStyle.Top;
            this.lstDatas.FullRowSelect = true;
            this.lstDatas.GridLines = true;
            this.lstDatas.HideSelection = false;
            this.lstDatas.Location = new System.Drawing.Point(0, 0);
            this.lstDatas.MultiSelect = false;
            this.lstDatas.Name = "lstDatas";
            this.lstDatas.Size = new System.Drawing.Size(393, 147);
            this.lstDatas.TabIndex = 0;
            this.lstDatas.UseCompatibleStateImageBehavior = false;
            this.lstDatas.View = System.Windows.Forms.View.Details;
            // 
            // UserName
            // 
            this.UserName.Text = "UserName";
            this.UserName.Width = 191;
            // 
            // UserType
            // 
            this.UserType.Text = "Account Type";
            this.UserType.Width = 197;
            // 
            // frmUserAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(393, 223);
            this.Controls.Add(this.lstDatas);
            this.Controls.Add(this.Bt_Cancel);
            this.Controls.Add(this.Bt_Remove);
            this.Controls.Add(this.Bt_Edit);
            this.Controls.Add(this.Bt_Add);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmUserAccount";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Account";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Bt_Add;
        private System.Windows.Forms.Button Bt_Edit;
        private System.Windows.Forms.Button Bt_Remove;
        private System.Windows.Forms.Button Bt_Cancel;
        private System.Windows.Forms.ListView lstDatas;
        private System.Windows.Forms.ColumnHeader UserName;
        private System.Windows.Forms.ColumnHeader UserType;
    }
}
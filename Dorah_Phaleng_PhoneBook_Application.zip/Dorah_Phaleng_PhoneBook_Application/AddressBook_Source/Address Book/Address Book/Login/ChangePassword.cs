using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmChangePassword : Form
    {
        public frmChangePassword()
        {            
            InitializeComponent();
        }
       
        private void UpdatePassword(object sender, EventArgs e)
        {
            if (txtNewPassword.Text.Length < 4) { MessageBox.Show("The Length of the password must be atleast in four chars.","Update Failed"); return; }

            if (txtNewPassword.Text != txtConfPassword.Text) { MessageBox.Show("New Password dose not match Confirm Password.", "Update Failed"); return; }

            if (UserPolicies.Password != txtOldPassword.Text)
            {
                MessageBox.Show("Old Password is not valid.","Update Failed");
                return;
            }

            UserPolicies.Password = txtNewPassword.Text;
            Program.Connection.CommandText = "update ContactsUserAccount set UserPassword=@UserPassword where UserID=" + UserPolicies.UserID;
            Program.Connection.AddParameter("@UserPassword", txtNewPassword.Text);
            if (Program.Connection.ExecuteNonQuery().ToString() == "1")
                MessageBox.Show("Password changed successfully.", "Process Completed");
            else MessageBox.Show("Due to some problems your password cannot be changed. Contact your administrator to change it or try again later.", "Update Failed");
            this.Close();
        }

        private void CancelUpdate(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
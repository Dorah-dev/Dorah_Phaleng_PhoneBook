﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Address Book")]
[assembly: AssemblyDescription("Manages your contacts over the Network.")]
[assembly: AssemblyCompany("ExgileIT")]
[assembly: AssemblyProduct("Address Book")]
[assembly: AssemblyCopyright("Copyright © ExgileIT2019")]
[assembly: ComVisible(false)]
[assembly: Guid("a3a7012f-30ea-49ad-999b-824587668a3b")]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]
using System;
using System.IO;
using System.Xml;
using System.Data;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmBackup : Form
    {
        public DataTable DT = new DataTable("Contacts");
        DataTable ED = new DataTable("Contacts");

        bool BackupXmlData = true;
        bool ProtectBkf = false;
        public string UserId = "";
        string Pwd = "";
        string Urn = "";

        public frmBackup()
        {
            InitializeComponent();
            UserId = UserPolicies.UserID;
        }

        public void FormLoaded(object sender, EventArgs e)
        {
            Program.Connection.CommandText = "select SchemaName from BkfSchemas";
            DataTable Table = new DataTable();
            Program.Connection.FillDataTable(Table, true);
            txtSchemaList.Items.Clear();
            for (int i = 0; i<Table.Rows.Count;i++)
                txtSchemaList.Items.Add(Table.Rows[i][0]);

            txtSchemaList.SelectedIndex = 0;
            ED = DT.Clone();
        }

        void SelectUnselectAll(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDatas.Items.Count; i++)
                lstDatas.Items[i].Checked = SelectUnSelectAll.Checked;
        }

        void SaveAsFile(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "XML File (*.xml)|*.xml|AddressBook Backup File (*.cbk)|*.cbk";
            SFD.AddExtension = true;
            SFD.Title = "Save Backup As";
            SFD.DefaultExt = "*.xml";
            SFD.ShowDialog();
            txtSourceFile.Text = SFD.FileName;
            if (txtSourceFile.Text.Length == 0) return;
            if (SFD.FilterIndex == 1)
            {
                if (!txtSourceFile.Text.EndsWith(".xml")) txtSourceFile.Text += ".xml";
                BackupXmlData = true;
                gbPasswordPanel.Enabled = false;
            }
            else
            {
                if (!txtSourceFile.Text.EndsWith(".cbk")) txtSourceFile.Text += ".cbk";
                BackupXmlData = false;
                gbPasswordPanel.Enabled = true;
            }
            btnTransfer.Enabled = true;
        }

        void CancelBackup(object sender, EventArgs e)
        {
            this.Close();
        }

        void BackupModeChanged(object sender, EventArgs e)
        {
            lstDatas.Items.Clear();
            DT.Rows.Clear();

            ProtectBkf = false;
            Pwd = "";
            txtPassword.Text = txtSourceFile.Text = "";
            btnTransfer.Enabled = false;

            if (importData.Checked)
            {
                btnOpen.Enabled = true;
                btnSaveAs.Enabled = false;
            }
            else
            {
                btnOpen.Enabled = false;
                btnSaveAs.Enabled = true;

                RetriveDatas(true);
            }
        }

        public void RetriveDatas(bool AddData)
        {
            string ColNames = DT.Columns[0].ColumnName;

            for (int i = 1; i < DT.Columns.Count; i++)
            {
                ColNames += ", " + DT.Columns[i].ColumnName;
            }
            Program.Connection.CommandText = "select " + ColNames + " from ContactsData where UserID='" + Converter.Encrypt(UserId) + "'";
            DT = null;
            DT = new DataTable("Contacts");
            Program.Connection.FillDataTable(DT, true);

            lstDatas.Items.Clear();
            if (AddData)
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    string[] NewRow = new string[4];
                    try { NewRow[0] = DT.Rows[i]["Display"].ToString(); }
                    catch { NewRow[0] = ""; }
                    try { NewRow[1] = DT.Rows[i]["HomePhone"].ToString(); }
                    catch { NewRow[1] = ""; }
                    try { NewRow[2] = DT.Rows[i]["Mobile"].ToString(); }
                    catch { NewRow[2] = ""; }
                    try { NewRow[3] = DT.Rows[i]["DefaultEmail"].ToString(); }
                    catch { NewRow[3] = ""; }
                    lstDatas.Items.Add(new ListViewItem(NewRow));
                }
        }

        void OpenSourceFile(object sender, EventArgs e)
        {
            #region Select Backup File
            lstDatas.Items.Clear();
            DT.Rows.Clear();

            ProtectBkf = false;
            Pwd = "";
            txtPassword.Text = txtSourceFile.Text = "";
            btnTransfer.Enabled = false;

            OpenFileDialog OFD = new OpenFileDialog();
            OFD.CheckFileExists = true;
            OFD.Filter = "XML File (*.xml)|*.xml|AddressBook Backup File (*.cbk)|*.cbk";
            OFD.DefaultExt = "*.xml";
            OFD.Title = "Select Backup File";
            OFD.ShowDialog();
            if (OFD.FileName == txtSourceFile.Text) return;

            txtSourceFile.Text = OFD.FileName;
            if (txtSourceFile.Text.EndsWith(".xml")) BackupXmlData = true;
            else if (txtSourceFile.Text.EndsWith(".cbk")) BackupXmlData = false;
            else
            {
                MessageBox.Show("The file must be either XML (*.xml) file or AddressBook Backup (*.cbk) file.", "Invalid File Extention");
                return;
            }
            #endregion

            btnTransfer.Enabled = true;

            if (BackupXmlData)
            {
                #region Retrive On XML File
                
                DT = null;
                DT = new DataTable("Contacts");
                XmlReader Reader = null;
                try
                {
                    XmlReaderSettings Settings = new XmlReaderSettings();
                    Settings.IgnoreWhitespace = true;
                    Reader = XmlReader.Create(txtSourceFile.Text, Settings);
                    bool Invalid = false;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "xml") Invalid = true;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "documentelement") Invalid = true;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "contacts") Invalid = true;

                    if (Invalid) { MessageBox.Show("The selected file is not a valid XML file to be retrived.", "Invalid Data"); }

                    string PrevName = "";

                    while (Reader.Read())
                    {
                        if (Reader.Name.ToLower() == PrevName || Reader.Name.Trim() == "") continue;
                        if (Reader.Name.ToLower() == "contacts") break;
                        PrevName = Reader.Name.ToLower();
                        DT.Columns.Add(Reader.Name);
                    }
                }
                catch (Exception Ex) { MessageBox.Show("An error occured while trying to read the backup file.\n\nError Message:\n" + Ex.Message, "Error"); return; }
                finally { Reader.Close(); Reader = null; }

                try
                {
                    DT.ReadXml(txtSourceFile.Text);
                }
                catch (Exception Ex) { MessageBox.Show(Ex.Message); return; }

                if (DT.Columns.IndexOf("Display") == -1)
                {
                    DT.Columns.Add("Display");

                    foreach(DataRow Row in DT.Rows)
                    {
                        string tmpDisplayName = "";

                        if (DT.Columns.IndexOf("FirstName") != -1) { tmpDisplayName = Row["FirstName"].ToString(); }
                        if (DT.Columns.IndexOf("MiddleName") != -1) { tmpDisplayName += " " + Row["MiddleName"].ToString(); }
                        tmpDisplayName = tmpDisplayName.Trim();
                        if (DT.Columns.IndexOf("LastName") != -1) { tmpDisplayName += " " + Row["LastName"].ToString(); }
                        Row["Display"] = tmpDisplayName.Trim();
                    }
                }

                foreach (DataRow NewRow in DT.Rows)
                {
                    string[] Values = new string[4];
                    Values[0] = NewRow["Display"].ToString();

                    if (DT.Columns.IndexOf("HomePhone") != -1) Values[1] = NewRow["HomePhone"].ToString();
                    else Values[1] = "";

                    if (DT.Columns.IndexOf("Mobile") != -1) Values[2] = NewRow["Mobile"].ToString();
                    else Values[2] = "";

                    if (DT.Columns.IndexOf("DefaultEmail") != -1) Values[3] = NewRow["DefaultEmail"].ToString();
                    else Values[3] = "";

                    lstDatas.Items.Add(new ListViewItem(Values));
                }
                #endregion
            }
            else
            {
                #region Retrive from AddressBook Backup
                StreamReader SR = new StreamReader(txtSourceFile.Text);

                lblBackupVersion.Text = Converter.Decrypt(SR.ReadLine());
                string tmpSecStr = Converter.Decrypt(SR.ReadLine());
                if (tmpSecStr == "1")
                {
                    ProtectBkf = true;
                    Urn = SR.ReadLine();
                    Pwd = SR.ReadLine();
                    gbPasswordPanel.Enabled = true;
                }
                else if (tmpSecStr == "0")
                {
                    ProtectBkf = false;
                    Urn = "";
                    Pwd = "";
                    gbPasswordPanel.Enabled = false;
                }
                else
                {
                    MessageBox.Show("The file \"" + txtSourceFile.Text + "\" is not a valid AddressBook Backup file.", "Invalid Backup File");
                    return;
                }

                StreamWriter SW = new StreamWriter(Application.StartupPath + "\\_Data.mdb");
                string str = SR.ReadLine();
                while (str != null)
                {
                    SW.WriteLine(Converter.Decrypt(str));
                    str = SR.ReadLine();
                }

                SW.Close(); SW = null;
                SR.Close(); SR = null;

                DT = null;
                DT = new DataTable("Contacts");
                XmlReader Reader = null;
                try
                {
                    XmlReaderSettings Settings = new XmlReaderSettings();
                    Settings.IgnoreWhitespace = true;
                    Reader = XmlReader.Create(Application.StartupPath + "\\_Data.mdb", Settings);
                    bool Invalid = false;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "xml") Invalid = true;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "documentelement") Invalid = true;

                    Reader.Read();
                    if (Reader.Name.ToLower() != "contacts") Invalid = true;
                    if (Invalid) { MessageBox.Show("The selected file is not a valid Backup file to be retrived.", "Invalid Data"); }
                    string PrevName = "";

                    while (Reader.Read())
                    {
                        if (Reader.Name.ToLower() == PrevName || Reader.Name.Trim() == "") continue;
                        if (Reader.Name.ToLower() == "contacts") break;
                        PrevName = Reader.Name.ToLower();
                        DT.Columns.Add(Reader.Name);
                    }
                }
                catch (Exception Ex) { MessageBox.Show("An error occured while trying to read the backup file.\n\nError Message:\n" + Ex.Message, "Error"); return; }
                finally { Reader.Close(); Reader = null; }

                try
                {
                    DT.ReadXml(Application.StartupPath + "\\_Data.mdb");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); return; }

                File.Delete(Application.StartupPath + "\\_Data.mdb");

                if (DT.Columns.IndexOf("Display") == -1)
                {
                    DT.Columns.Add("Display");

                    foreach (DataRow Row in DT.Rows)
                    {
                        string tmpDisplayName = "";

                        if (DT.Columns.IndexOf("FirstName") != -1) { tmpDisplayName = Row["FirstName"].ToString(); }
                        if (DT.Columns.IndexOf("MiddleName") != -1) { tmpDisplayName += " " + Row["MiddleName"].ToString(); }
                        tmpDisplayName = tmpDisplayName.Trim();
                        if (DT.Columns.IndexOf("LastName") != -1) { tmpDisplayName += " " + Row["LastName"].ToString(); }
                        Row["Display"] = tmpDisplayName.Trim();
                    }
                }
                
                if (ProtectBkf) { MessageBox.Show("The selected Backup file was password protected. Enter User Name and Password and click the set button to view the datas.", "Password Requuired"); gbPasswordPanel.Enabled = true; }
                else
                {
                    gbPasswordPanel.Enabled = false;
                    foreach (DataRow NewRow in DT.Rows)
                    {
                        string[] Values = new string[4];
                        Values[0] = NewRow["Display"].ToString();

                        if (DT.Columns.IndexOf("HomePhone") != -1) Values[1] = NewRow["HomePhone"].ToString();
                        else Values[1] = "";

                        if (DT.Columns.IndexOf("Mobile") != -1) Values[2] = NewRow["Mobile"].ToString();
                        else Values[2] = "";

                        if (DT.Columns.IndexOf("DefaultEmail") != -1) Values[3] = NewRow["DefaultEmail"].ToString();
                        else Values[3] = "";

                        lstDatas.Items.Add(new ListViewItem(Values));
                    }
                }
                #endregion
            }
        }

        void TransferData(object sender, EventArgs e)
        {
            ED = null;
            ED = DT.Clone();
            ED.Rows.Clear();

            for (int i = 0; i < lstDatas.CheckedItems.Count; i++)
            {
                ED.Rows.Add(DT.Rows[lstDatas.CheckedItems[i].Index].ItemArray);
            }

            if (importData.Checked)
            {
                string ColNames = "Shared";
                string Params = "'" + Converter.Encrypt("0") + "'";

                ED.Columns.Add("UserID");
                ED.Columns.Add("SDisplay");
                bool ListAdded = false;
                bool HadBoth = false;
                if (ED.Columns.IndexOf("EmailList") != -1 && ED.Columns.IndexOf("DefaultEmail") != -1) HadBoth = true;
                else if (ED.Columns.IndexOf("EmailList") != -1 || ED.Columns.IndexOf("DefaultEmail") != -1)
                {
                    if (ED.Columns.IndexOf("EmailList") == -1) { ED.Columns.Add("EmailList"); ListAdded = true; }
                    else ED.Columns.Add("DefaultEmail");
                }
                
                ED.Columns.Add("SEmailList");

                for (int i = 0; i < ED.Columns.Count; i++)
                {
                    ColNames += ", " + ED.Columns[i].ColumnName;
                    Params += ", @" + ED.Columns[i].ColumnName;
                }

                Program.Connection.CommandText = "insert into ContactsData(Category, " + ColNames + ") values('IFKGH', " + Params + ")";
                
                #region Add Parameters
                foreach (DataRow Row in ED.Rows)
                {
                    Row["UserID"] = UserPolicies.UserID;
                    Row["SDisplay"] = Row["Display"].ToString().ToUpper();

                    if (ED.Columns.IndexOf("EmailList") != -1)
                    {
                        if (!HadBoth)
                            if (ListAdded)
                            {
                                Row["EmailList"] = Row["DefaultEmail"].ToString();
                            }
                            else
                            {
                                TextBox TB = new TextBox();
                                TB.Text = Row["EmailList"].ToString();
                                if (TB.Lines.Length > 0) Row["DefaultEmail"] = TB.Lines[0];
                            }
                        Row["SEmailList"] = Row["EmailList"].ToString().ToUpper();
                    }

                    for (int i = 0; i < ED.Columns.Count; i++)
                    {
                        Program.Connection.AddParameter("@" + ED.Columns[i].ColumnName, Row[i].ToString());
                    }

                    #endregion
                    
                    Program.Connection.ExecuteNonQuery();
                }
                this.Close();
                MessageBox.Show("The backup had been restored.\nPlease refresh the datas to view the backup.", "Action Completed");
            }
            else
            {
                if (BackupXmlData)
                {
                    ED.WriteXml(txtSourceFile.Text);
                }
                else
                {
                    StreamWriter SW = new StreamWriter(txtSourceFile.Text);
                    SW.Write(Converter.Encrypt("Backup Version: AddressBook v1.0"));
                    if (ProtectBkf)
                    {
                        SW.Write("\n" + Converter.Encrypt("1"));
                        SW.Write("\n" + Urn);
                        SW.Write("\n" + Pwd);
                    }
                    else SW.Write("\n" + Converter.Encrypt("0"));
                    ED.WriteXml("_Data.mdb");
                    StreamReader SR = new StreamReader("_Data.mdb");
                    string str;
                    while ((str = SR.ReadLine()) != null)
                    {
                        SW.Write("\n" + Converter.Encrypt(str));
                    }
                    SR.Close();
                    SW.Close();
                    File.Delete("_Data.mdb");
                }
                this.Close();
                MessageBox.Show("The backup had been created.", "Action Completed");
            }
        }

        void GetSetPassword(object sender, EventArgs e)
        {
            if (importData.Checked)
            {
                if (!ProtectBkf) return;
                if (Converter.Decrypt(Urn).ToLower() != txtUserName.Text.ToLower()) { MessageBox.Show("Invalid User Name","Invalid Details"); return; }
                if (Converter.Decrypt(Pwd) != txtPassword.Text) { MessageBox.Show("Invalid Password", "Invalid Details"); return; }

                foreach (DataRow NewRow in DT.Rows)
                {
                    string[] Values = new string[4];
                    Values[0] = NewRow["Display"].ToString();

                    if (DT.Columns.IndexOf("HomePhone") != -1) Values[1] = NewRow["HomePhone"].ToString();
                    else Values[1] = "";

                    if (DT.Columns.IndexOf("Mobile") != -1) Values[2] = NewRow["Mobile"].ToString();
                    else Values[2] = "";

                    if (DT.Columns.IndexOf("DefaultEmail") != -1) Values[3] = NewRow["DefaultEmail"].ToString();
                    else Values[3] = "";

                    lstDatas.Items.Add(new ListViewItem(Values));
                }

                ProtectBkf = false;
                Urn = "";
                Pwd = "";
            }
            else
            {
                ProtectBkf = true;
                Urn = Converter.Encrypt(txtUserName.Text);
                Pwd = Converter.Encrypt(txtPassword.Text);
            }
        }

        void CancelCredentials(object sender, EventArgs e)
        {
            if (exportData.Checked)
            {
                ProtectBkf = false;
                Urn = "";
                Pwd = "";
            }
            else
            {
                MessageBox.Show("Enter the valid User Name and Password and click Set to view the data.");
            }
        }

        void Edit(object sender, EventArgs e)
        {
            frmSchemas NewSchemas = new frmSchemas();
            NewSchemas.ShowDialog();
            FormLoaded(sender, e);
        }

        void SchemaChanged(object sender, EventArgs e)
        {
            RetriveSchema(txtSchemaList.SelectedItem.ToString());
            if (!importData.Checked) RetriveDatas(true);
        }

        public void RetriveSchema(string SchemaName)
        {
            Program.Connection.CommandText = "select SchemaSet from BkfSchemas where SchemaName='" + Converter.Encrypt(SchemaName) + "'";

            DataTable Table = new DataTable();
            Program.Connection.FillDataTable(Table, false);

            DT = null; ED = null;
            DT = new DataTable("Contacts");

            StreamWriter SchemaWriter = new StreamWriter(Application.StartupPath + "\\_DataS.mdb");

            SchemaWriter.Write(Table.Rows[0][0]);

            SchemaWriter.Close(); SchemaWriter = null;

            DT.ReadXmlSchema(Application.StartupPath + "\\_DataS.mdb");
            ED = DT.Clone();
            File.Delete(Application.StartupPath + "\\_DataS.mdb");
        }
    }
}
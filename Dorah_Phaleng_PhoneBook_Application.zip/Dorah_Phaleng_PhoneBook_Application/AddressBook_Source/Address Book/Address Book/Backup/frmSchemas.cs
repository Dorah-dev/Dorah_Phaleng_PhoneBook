using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmSchemas : Form
    {
        string[] IteMiddleNames = new string[] { "FirstName", "MiddleName", "LastName", "Display", "Title", "NickName", "DefaultEmail", "EmailList", "HomeAddress", "HomeCity", "HomeState", "HomeZipCode", "HomeCountry", "HomePhone", "HomeFax", "Mobile", "HomeWebPage", "Company", "OfficeAddress", "OfficeCity", "OfficeState", "OfficeZipCode", "OfficeCountry", "JobTitle", "Department", "Office", "OfficePhone", "OfficeFax", "Pager", "IP", "OfficeWebPage", "Spouse", "ChildNames", "Gender", "Birthday", "Anniversary", "OtherNotes" };
        bool[] AllowEdit;
        bool EditingSchema;

        int SC = 0;
        DataTable DT;

        public frmSchemas()
        {
            InitializeComponent();
            RetriveSchemaNames();
        }

        void RetriveSchemaNames()
        {
            SC = 0;
            txtSchemaName.Items.Clear();
            AllowEdit = null;
            Program.Connection.CommandText = "select SchemaName,UserID from BkfSchemas";
            DT = new DataTable();
            Program.Connection.FillDataTable(DT, false);

            AllowEdit = new bool[DT.Rows.Count + 1];

            // Decrypt only first two cols
            for (int i = 0; i < 2; i++) for (int j = 0; j < DT.Rows.Count; j++)
                    DT.Rows[j][i] = Converter.Decrypt(DT.Rows[j][i].ToString());

            for (int i = 0; i < DT.Rows.Count; i++)
            {
                txtSchemaName.Items.Add(DT.Rows[i][0]);
                AllowEdit[SC] = UserPolicies.UserID == DT.Rows[i][1].ToString();
                SC++;
            }
            txtSchemaName.Items.Add("< Create New Schema >");
        }

        void EditSelected(object sender, EventArgs e)
        {
            txtNewName.Enabled = btnSave.Enabled = EditingSchema = true;
            btnRemove.Enabled = false;
        }

        void SaveSchema(object sender, EventArgs e)
        {
            if (!lstSelectedList.Items.Contains(IteMiddleNames[0]) && !lstSelectedList.Items.Contains(IteMiddleNames[1]) && !lstSelectedList.Items.Contains(IteMiddleNames[2]) && !lstSelectedList.Items.Contains(IteMiddleNames[3]))
            {
                MessageBox.Show("Atleast any one of the below items must be added to the schema to make the backup valid.\n\nFirstName (or) MiddleName (or) LastName (or) FulLastName", "Action Cancled");
                return;
            }

            DT = null;
            DT = new DataTable("Contacts");

            foreach (string itm in lstSelectedList.Items)
            {
                DT.Columns.Add(itm);
            }

            DT.WriteXmlSchema(Application.StartupPath + "\\_DataS.mdb");
            
            StreamReader SR = new StreamReader(Application.StartupPath + "\\_DataS.mdb");

            Program.Connection.CommandText = "insert into BkfSchemas values(@SchemaName,@UserID,@SchemaSet)";

            if (EditingSchema) Program.Connection.CommandText = "update BkfSchemas set SchemaName=@SchemaName, SchemaSet=@SchemaSet where SchemaName='" + Converter.Encrypt(txtSchemaName.SelectedItem.ToString()) + "'";
            
            Program.Connection.AddParameter("@SchemaName", txtNewName.Text);
            Program.Connection.AddParameter("@UserID", UserPolicies.UserID);
            Program.Connection.AddParameter("@SchemaSet", SR.ReadToEnd(), false);
            bool exit = false;
            try
            {
                MessageBox.Show(Program.Connection.ExecuteNonQuery().ToString() + " Schema had been added to the collection", "Action Completed");
                exit = true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show("This schema couldnot be added to the collection.\n\nError Message:\n" + Ex.Message, "Action Cancled");
            }

            SR.Close();
            SR = null;

            File.Delete(Application.StartupPath + "\\_DataS.mdb");

            btnEdit.Enabled = btnRemove.Enabled = AllowEdit[txtSchemaName.SelectedIndex];
            btnSave.Enabled = txtNewName.Enabled = EditingSchema = false;
            if (exit) Close();
        }

        void AddSelected(object sender, EventArgs e)
        {
            if (lstTotalList.SelectedIndex == -1) return;
            int selInd = lstTotalList.SelectedIndex;
            lstSelectedList.Items.Add(lstTotalList.Items[lstTotalList.SelectedIndex].ToString());
            lstTotalList.Items.RemoveAt(lstTotalList.SelectedIndex);

            if (lstTotalList.Items.Count > 0)
            {
                if (lstTotalList.Items.Count > selInd) lstTotalList.SelectedIndex = selInd;
                else lstTotalList.SelectedIndex = lstTotalList.Items.Count - 1;
            }
        }

        void RemoveSelected(object sender, EventArgs e)
        {
            if (lstSelectedList.SelectedIndex == -1) return;
            int selInd = lstSelectedList.SelectedIndex;
            lstTotalList.Items.Add(lstSelectedList.Items[lstSelectedList.SelectedIndex].ToString());
            lstSelectedList.Items.RemoveAt(lstSelectedList.SelectedIndex);

            if (lstSelectedList.Items.Count > 0)
            {
                if (lstSelectedList.Items.Count > selInd) lstSelectedList.SelectedIndex = selInd;
                else lstSelectedList.SelectedIndex = lstSelectedList.Items.Count - 1;
            }
        }

        void AddAll(object sender, EventArgs e)
        {
            foreach (string i in lstTotalList.Items)
            {
                lstSelectedList.Items.Add(i);
            }
            lstTotalList.Items.Clear();
        }

        void RemoveAll(object sender, EventArgs e)
        {
            foreach (string i in lstSelectedList.Items)
            {
                lstTotalList.Items.Add(i);
            }
            lstSelectedList.Items.Clear();
        }

        void MoveUp(object sender, EventArgs e)
        {
            int a = lstSelectedList.SelectedIndex;
            if (a == -1) return;
            string Item = lstSelectedList.Items[a].ToString();
            lstSelectedList.Items.RemoveAt(a);
            lstSelectedList.Items.Insert(a - 1, Item);
            lstSelectedList.SelectedIndex = a - 1;
        }

        void SchemaSelectionChanged(object sender, EventArgs e)
        {
            btnEdit.Enabled = btnRemove.Enabled = AllowEdit[txtSchemaName.SelectedIndex];

            txtNewName.Text = txtSchemaName.SelectedItem.ToString();
            lstSelectedList.Items.Clear(); lstTotalList.Items.Clear();
            if (txtSchemaName.SelectedIndex == SC)
            {
                txtNewName.Text = "New Schema " + DateTime.Now.ToShortDateString();
                lstTotalList.Items.AddRange(IteMiddleNames);
                btnSave.Enabled = txtNewName.Enabled = true;
                return;
            }
            Program.Connection.CommandText = "select SchemaSet from BkfSchemas where SchemaName='" + Converter.Encrypt(txtSchemaName.SelectedItem.ToString()) + "'";
            DataTable Table = new DataTable();
            Program.Connection.FillDataTable(Table, false);
            StreamWriter SW = new StreamWriter("_DataS.mdb");

            SW.Write(Table.Rows[0][0].ToString());
            SW.Close();
            Table = null;
            DT = null;
            DT = new DataTable();
            DT.ReadXmlSchema("_DataS.mdb");

            File.Delete("_DataS.mdb");

            for (int i = 0; i < DT.Columns.Count; i++)
            {
                lstSelectedList.Items.Add(DT.Columns[i].ColumnName);
            }

            for (int i = 0; i < IteMiddleNames.Length; i++)
            {
                if (!lstSelectedList.Items.Contains(IteMiddleNames[i])) lstTotalList.Items.Add(IteMiddleNames[i]);
            }
            DT = null;

            btnSave.Enabled = txtNewName.Enabled = EditingSchema = false;
        }

        void RemoveSchema(object sender, EventArgs e)
        {
            if (MessageBox.Show("If you remove this schema you will not be able to restore the backup created using this schema unless you create it again.\n\nAre you sure to remove the schema named " + txtSchemaName.SelectedItem.ToString() + " permenantly?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.No) return;
            Program.Connection.CommandText = "delete from BkfSchemas where SchemaName='" + Converter.Encrypt(txtSchemaName.SelectedItem.ToString()) + "'";
            Program.Connection.ExecuteNonQuery();

            RetriveSchemaNames();
        }
    }
}
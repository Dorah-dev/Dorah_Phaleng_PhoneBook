namespace AddressBook
{
    partial class frmBackup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBackup));
            this.lblHeader = new System.Windows.Forms.Label();
            this.gbBkfMode = new System.Windows.Forms.GroupBox();
            this.exportData = new System.Windows.Forms.RadioButton();
            this.importData = new System.Windows.Forms.RadioButton();
            this.gbBkfSource = new System.Windows.Forms.GroupBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.txtSourceFile = new System.Windows.Forms.TextBox();
            this.lblSource = new System.Windows.Forms.Label();
            this.SelectUnSelectAll = new System.Windows.Forms.CheckBox();
            this.gbDataSelection = new System.Windows.Forms.GroupBox();
            this.lstDatas = new System.Windows.Forms.ListView();
            this.FulLastName = new System.Windows.Forms.ColumnHeader();
            this.HomePhone = new System.Windows.Forms.ColumnHeader();
            this.Mobile = new System.Windows.Forms.ColumnHeader();
            this.DefaultEmail = new System.Windows.Forms.ColumnHeader();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.gbPasswordPanel = new System.Windows.Forms.GroupBox();
            this.btnCancelCred = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSet = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblSetPassword = new System.Windows.Forms.Label();
            this.lblBackupVersion = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnEditSchema = new System.Windows.Forms.Button();
            this.txtSchemaList = new System.Windows.Forms.ComboBox();
            this.lblSchemaName = new System.Windows.Forms.Label();
            this.gbBkfMode.SuspendLayout();
            this.gbBkfSource.SuspendLayout();
            this.gbDataSelection.SuspendLayout();
            this.gbPasswordPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.BackColor = System.Drawing.SystemColors.Info;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(575, 22);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Backup";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbBkfMode
            // 
            this.gbBkfMode.Controls.Add(this.exportData);
            this.gbBkfMode.Controls.Add(this.importData);
            this.gbBkfMode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gbBkfMode.Location = new System.Drawing.Point(10, 25);
            this.gbBkfMode.Name = "gbBkfMode";
            this.gbBkfMode.Size = new System.Drawing.Size(105, 82);
            this.gbBkfMode.TabIndex = 0;
            this.gbBkfMode.TabStop = false;
            this.gbBkfMode.Text = "Backup Mode";
            // 
            // exportData
            // 
            this.exportData.AutoSize = true;
            this.exportData.Location = new System.Drawing.Point(12, 51);
            this.exportData.Name = "exportData";
            this.exportData.Size = new System.Drawing.Size(81, 17);
            this.exportData.TabIndex = 1;
            this.exportData.Text = "Export Data";
            this.exportData.UseVisualStyleBackColor = true;
            this.exportData.CheckedChanged += new System.EventHandler(this.BackupModeChanged);
            // 
            // importData
            // 
            this.importData.AutoSize = true;
            this.importData.Checked = true;
            this.importData.Location = new System.Drawing.Point(12, 22);
            this.importData.Name = "importData";
            this.importData.Size = new System.Drawing.Size(80, 17);
            this.importData.TabIndex = 0;
            this.importData.TabStop = true;
            this.importData.Text = "Import Data";
            this.importData.UseVisualStyleBackColor = true;
            // 
            // gbBkfSource
            // 
            this.gbBkfSource.Controls.Add(this.btnOpen);
            this.gbBkfSource.Controls.Add(this.btnSaveAs);
            this.gbBkfSource.Controls.Add(this.txtSourceFile);
            this.gbBkfSource.Controls.Add(this.lblSource);
            this.gbBkfSource.Controls.Add(this.SelectUnSelectAll);
            this.gbBkfSource.Location = new System.Drawing.Point(121, 25);
            this.gbBkfSource.Name = "gbBkfSource";
            this.gbBkfSource.Size = new System.Drawing.Size(442, 82);
            this.gbBkfSource.TabIndex = 1;
            this.gbBkfSource.TabStop = false;
            this.gbBkfSource.Text = "Backup Source";
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(275, 48);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.OpenSourceFile);
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.Enabled = false;
            this.btnSaveAs.Location = new System.Drawing.Point(356, 48);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(75, 23);
            this.btnSaveAs.TabIndex = 2;
            this.btnSaveAs.Text = "Save As";
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.SaveAsFile);
            // 
            // txtSourceFile
            // 
            this.txtSourceFile.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtSourceFile.Location = new System.Drawing.Point(59, 21);
            this.txtSourceFile.Name = "txtSourceFile";
            this.txtSourceFile.ReadOnly = true;
            this.txtSourceFile.Size = new System.Drawing.Size(372, 20);
            this.txtSourceFile.TabIndex = 0;
            // 
            // lblSource
            // 
            this.lblSource.AutoSize = true;
            this.lblSource.Location = new System.Drawing.Point(12, 24);
            this.lblSource.Name = "lblSource";
            this.lblSource.Size = new System.Drawing.Size(41, 13);
            this.lblSource.TabIndex = 0;
            this.lblSource.Text = "Source";
            // 
            // SelectUnSelectAll
            // 
            this.SelectUnSelectAll.AutoSize = true;
            this.SelectUnSelectAll.Location = new System.Drawing.Point(15, 52);
            this.SelectUnSelectAll.Name = "SelectUnSelectAll";
            this.SelectUnSelectAll.Size = new System.Drawing.Size(154, 17);
            this.SelectUnSelectAll.TabIndex = 6;
            this.SelectUnSelectAll.Text = "Select / Unselect All Datas";
            this.SelectUnSelectAll.UseVisualStyleBackColor = true;
            this.SelectUnSelectAll.CheckedChanged += new System.EventHandler(this.SelectUnselectAll);
            // 
            // gbDataSelection
            // 
            this.gbDataSelection.Controls.Add(this.lstDatas);
            this.gbDataSelection.Location = new System.Drawing.Point(10, 233);
            this.gbDataSelection.Name = "gbDataSelection";
            this.gbDataSelection.Size = new System.Drawing.Size(553, 206);
            this.gbDataSelection.TabIndex = 4;
            this.gbDataSelection.TabStop = false;
            this.gbDataSelection.Text = "Data to Transfer";
            // 
            // lstDatas
            // 
            this.lstDatas.CheckBoxes = true;
            this.lstDatas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.FulLastName,
            this.HomePhone,
            this.Mobile,
            this.DefaultEmail});
            this.lstDatas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstDatas.FullRowSelect = true;
            this.lstDatas.GridLines = true;
            this.lstDatas.Location = new System.Drawing.Point(3, 16);
            this.lstDatas.MultiSelect = false;
            this.lstDatas.Name = "lstDatas";
            this.lstDatas.Size = new System.Drawing.Size(547, 187);
            this.lstDatas.TabIndex = 0;
            this.lstDatas.UseCompatibleStateImageBehavior = false;
            this.lstDatas.View = System.Windows.Forms.View.Details;
            // 
            // FulLastName
            // 
            this.FulLastName.Text = "Full Name";
            this.FulLastName.Width = 136;
            // 
            // HomePhone
            // 
            this.HomePhone.Text = "Home Phone";
            this.HomePhone.Width = 130;
            // 
            // Mobile
            // 
            this.Mobile.Text = "Mobile";
            this.Mobile.Width = 146;
            // 
            // DefaultEmail
            // 
            this.DefaultEmail.Text = "Default Email";
            this.DefaultEmail.Width = 131;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(407, 453);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.CancelBackup);
            // 
            // btnTransfer
            // 
            this.btnTransfer.Enabled = false;
            this.btnTransfer.Location = new System.Drawing.Point(488, 453);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(75, 23);
            this.btnTransfer.TabIndex = 10;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.TransferData);
            // 
            // gbPasswordPanel
            // 
            this.gbPasswordPanel.Controls.Add(this.btnCancelCred);
            this.gbPasswordPanel.Controls.Add(this.txtUserName);
            this.gbPasswordPanel.Controls.Add(this.label2);
            this.gbPasswordPanel.Controls.Add(this.btnSet);
            this.gbPasswordPanel.Controls.Add(this.txtPassword);
            this.gbPasswordPanel.Controls.Add(this.lblSetPassword);
            this.gbPasswordPanel.Enabled = false;
            this.gbPasswordPanel.Location = new System.Drawing.Point(10, 178);
            this.gbPasswordPanel.Name = "gbPasswordPanel";
            this.gbPasswordPanel.Size = new System.Drawing.Size(553, 49);
            this.gbPasswordPanel.TabIndex = 3;
            this.gbPasswordPanel.TabStop = false;
            this.gbPasswordPanel.Text = "Security Settings";
            // 
            // btnCancelCred
            // 
            this.btnCancelCred.Location = new System.Drawing.Point(478, 18);
            this.btnCancelCred.Name = "btnCancelCred";
            this.btnCancelCred.Size = new System.Drawing.Size(64, 23);
            this.btnCancelCred.TabIndex = 4;
            this.btnCancelCred.Text = "Cancel";
            this.btnCancelCred.UseVisualStyleBackColor = true;
            this.btnCancelCred.Click += new System.EventHandler(this.CancelCredentials);
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtUserName.Location = new System.Drawing.Point(75, 20);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(114, 20);
            this.txtUserName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "User Name";
            // 
            // btnSet
            // 
            this.btnSet.Location = new System.Drawing.Point(408, 18);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(64, 23);
            this.btnSet.TabIndex = 3;
            this.btnSet.Text = "Set";
            this.btnSet.UseVisualStyleBackColor = true;
            this.btnSet.Click += new System.EventHandler(this.GetSetPassword);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtPassword.Location = new System.Drawing.Point(288, 20);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(114, 20);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // lblSetPassword
            // 
            this.lblSetPassword.AutoSize = true;
            this.lblSetPassword.Location = new System.Drawing.Point(229, 23);
            this.lblSetPassword.Name = "lblSetPassword";
            this.lblSetPassword.Size = new System.Drawing.Size(53, 13);
            this.lblSetPassword.TabIndex = 0;
            this.lblSetPassword.Text = "Password";
            // 
            // lblBackupVersion
            // 
            this.lblBackupVersion.AutoSize = true;
            this.lblBackupVersion.Location = new System.Drawing.Point(7, 458);
            this.lblBackupVersion.Name = "lblBackupVersion";
            this.lblBackupVersion.Size = new System.Drawing.Size(82, 13);
            this.lblBackupVersion.TabIndex = 0;
            this.lblBackupVersion.Text = "Backup Version";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEditSchema);
            this.groupBox1.Controls.Add(this.txtSchemaList);
            this.groupBox1.Controls.Add(this.lblSchemaName);
            this.groupBox1.Location = new System.Drawing.Point(10, 117);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 55);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Backup Data Schema";
            // 
            // btnEditSchema
            // 
            this.btnEditSchema.Location = new System.Drawing.Point(467, 18);
            this.btnEditSchema.Name = "btnEditSchema";
            this.btnEditSchema.Size = new System.Drawing.Size(75, 23);
            this.btnEditSchema.TabIndex = 2;
            this.btnEditSchema.Text = "Edit";
            this.btnEditSchema.UseVisualStyleBackColor = true;
            this.btnEditSchema.Click += new System.EventHandler(this.Edit);
            // 
            // txtSchemaList
            // 
            this.txtSchemaList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtSchemaList.FormattingEnabled = true;
            this.txtSchemaList.Location = new System.Drawing.Point(95, 20);
            this.txtSchemaList.Name = "txtSchemaList";
            this.txtSchemaList.Size = new System.Drawing.Size(366, 21);
            this.txtSchemaList.TabIndex = 1;
            this.txtSchemaList.SelectedIndexChanged += new System.EventHandler(this.SchemaChanged);
            // 
            // lblSchemaName
            // 
            this.lblSchemaName.AutoSize = true;
            this.lblSchemaName.Location = new System.Drawing.Point(9, 23);
            this.lblSchemaName.Name = "lblSchemaName";
            this.lblSchemaName.Size = new System.Drawing.Size(80, 13);
            this.lblSchemaName.TabIndex = 0;
            this.lblSchemaName.Text = "Schema Name:";
            // 
            // frmBackup
            // 
            this.AcceptButton = this.btnTransfer;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(575, 486);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblBackupVersion);
            this.Controls.Add(this.gbPasswordPanel);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.gbDataSelection);
            this.Controls.Add(this.gbBkfSource);
            this.Controls.Add(this.gbBkfMode);
            this.Controls.Add(this.lblHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBackup";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AddressBook :: [Backup Wizzard]";
            this.Load += new System.EventHandler(this.FormLoaded);
            this.gbBkfMode.ResumeLayout(false);
            this.gbBkfMode.PerformLayout();
            this.gbBkfSource.ResumeLayout(false);
            this.gbBkfSource.PerformLayout();
            this.gbDataSelection.ResumeLayout(false);
            this.gbPasswordPanel.ResumeLayout(false);
            this.gbPasswordPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox gbBkfMode;
        private System.Windows.Forms.GroupBox gbBkfSource;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Label lblSource;
        private System.Windows.Forms.GroupBox gbDataSelection;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox gbPasswordPanel;
        private System.Windows.Forms.Button btnSet;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblSetPassword;
        private System.Windows.Forms.CheckBox SelectUnSelectAll;
        private System.Windows.Forms.ColumnHeader FulLastName;
        private System.Windows.Forms.ColumnHeader DefaultEmail;
        private System.Windows.Forms.ColumnHeader HomePhone;
        private System.Windows.Forms.ColumnHeader Mobile;
        private System.Windows.Forms.Label lblBackupVersion;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCancelCred;
        public System.Windows.Forms.RadioButton exportData;
        public System.Windows.Forms.RadioButton importData;
        public System.Windows.Forms.TextBox txtSourceFile;
        public System.Windows.Forms.Button btnTransfer;
        public System.Windows.Forms.ListView lstDatas;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox txtSchemaList;
        private System.Windows.Forms.Label lblSchemaName;
        private System.Windows.Forms.Button btnEditSchema;
    }
}
namespace AddressBook
{
    class UserPolicies
    {
        public static string UserName;
        public static string UserID;
        public static string Password;
        public static bool IsAdministrator;
        public static bool IsLoggedIn;        
    }
}

using System;
using System.Windows.Forms;

namespace AddressBook
{
    static class Program
    {
        public static DataConnection Connection;

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                DataConnection.GetSettings();
            }
            catch
            {
                if (MessageBox.Show("The database connections had not been configured. Do you want to configure it now?", "Address Book", MessageBoxButtons.YesNo) == DialogResult.No) return;
                if (new frmSettings().ShowDialog() == DialogResult.Cancel) return;
                MessageBox.Show("Now the application will restart to apply the settings.", "Address Book");
                Application.Restart();
                return;
            }
            try
            {
                (Connection = DataConnection.GetConnection()).Open();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Could not access the database. This application needs to exit.\n\nError Message:\n" + Ex.Message, "Connection Error");
                return;
            }

            Application.Run(new frmMain());
            Application.Run(new frmContacts());
        }

        public static bool ValidateEmail(string Email)
        {
            if ((Email.IndexOf('@') != Email.LastIndexOf('@')) || Email.IndexOf('@') == -1) return false;

            if (Email[Email.IndexOf('@') + 1] == '.') return false;

            if ((Email.LastIndexOf(".") == Email.Length - 1) || Email.LastIndexOf(".") == -1) return false;

            if (Email.Contains(" ") || Email.Contains("\\") || Email.Contains("/") || Email.Contains("*") || Email.Contains(";")) return false;

            return true;
        }

        public static bool HasChars(string Value)
        {
            foreach (char c in Value)
            {
                if ((int)c < 48 || (int)c > 57) return true;                
            }
            return false;
        }
    }
}
create table ContactsUserAccount
(
UserID int identity constraint pk_ContactsUserID primary key,
AllowLogin varchar(4),
UserName varchar(150),
UserPassword varchar(150),
UserType varchar(4),
Created varchar(150),
Modified varchar(150),
LastLogin varchar(150),
Status varchar(32)
)
namespace AddressBook
{
    class Converter
    {
        public static string Encrypt(string StringData)
        {
            if (StringData == "") return "";
            string Encrypted = null;
            foreach (char c in StringData)
            {
                string tmp1 = System.Convert.ToInt32(c).ToString();

                foreach (char d in tmp1)
                {
                    Encrypted += ((char)(d + 17)).ToString();
                }
                Encrypted += "K";
            }
            return Encrypted.Remove(Encrypted.Length - 1); ;
        }

        public static string Decrypt(string EncryptedData)
        {
            EncryptedData = EncryptedData.Trim().Replace("  ", " ").Replace(" ","KDCK");
            if (EncryptedData == "") return "";
            if (EncryptedData == null) return null;
            string[] Chars = EncryptedData.Split((char)75);
            string Data = null;
            foreach (string word in Chars)
            {
                string tmp = null;
                foreach (char c in word)
                {                    
                    tmp += (char)(c - 17);
                }
                Data += (char)System.Convert.ToInt32(tmp);
            }
            return Data;
        }
    }
}

create table ContactsReminder
(
ReminderID int identity,
UserID varchar(15),
ReminderName varchar(150),
RemindOn varchar(210),
Descripption varchar(300),
)
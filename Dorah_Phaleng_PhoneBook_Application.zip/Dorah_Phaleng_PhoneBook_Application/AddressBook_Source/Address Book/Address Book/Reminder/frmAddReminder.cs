using System;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class frmAddReminder : Form
    {
        public frmAddReminder()
        {
            InitializeComponent();
            txtFormat.SelectedIndex = 0;
            txtDate.MinDate = DateTime.Now;
        }

        void SaveReminder(object sender, EventArgs e)
        {
            if (txtName.Text.Trim().Length == 0 && txtDescription.Text.Trim().Length == 0)
            { MessageBox.Show("Either Name or Description is must to add a reminder.", "Invalid Data"); return; }
            try
            {
                if (Convert.ToInt32(txtHour.Text.Trim()) > 12 || Convert.ToInt32(txtHour.Text.Trim()) < 1 || Convert.ToInt32(txtMins.Text.Trim()) > 59 || Convert.ToInt32(txtMins.Text.Trim()) < 1)
                { MessageBox.Show("The time entered is invalid.", "Invalid Time"); return; }
            }
            catch (FormatException) { MessageBox.Show("Hour and Minute cannot contain chars other than numbers.", "Invalid Data"); return; }

            Program.Connection.CommandText = "insert into ContactsReminder(UserID, ReminderName, RemindOn, Descripption)"
                + " values(@UserID, @ReminderName, @RemindOn, @Descripption)";
            Program.Connection.AddParameter("@UserID", UserPolicies.UserID);
            Program.Connection.AddParameter("@ReminderName", txtName.Text);
            Program.Connection.AddParameter("@RemindOn", txtDate.Value.ToString("dddd, MMMM dd yyyy  ") + txtHour.Text.Trim() + ":" + txtMins.Text.Trim() + " " + txtFormat.SelectedItem.ToString());
            Program.Connection.AddParameter("@Descripption", txtDescription.Text);
            Program.Connection.ExecuteNonQuery();
            Close();
        }

        void CloseForm(object sender, EventArgs e)
        {
            Close();
        }
    }
}